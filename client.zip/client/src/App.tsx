import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Login from "./pages/AdminLogin";
import NotFound from "./pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import Navbar from "./components/NavbarMain";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import Rooms from "./pages/Rooms";
import RoomDetail from "./pages/RoomDetail";
import Facilities from "./pages/Facilities";
import Gallery from "./pages/Gallery";
import Booking from "./pages/Booking";
import BookingRequestStatus from "./pages/BookingRequestStatus";
import ActualBookingConfirmation from "./pages/BookingConfirmation";
import CustomerAccount from "./pages/CustomerAccountPortal";
import Contact from "./pages/Contact";
import MyBookings from "./pages/MyBookingsPortal";
import ResetCustomerPassword from "./pages/ResetCustomerPassword";
import CustomerReviews from "./pages/CustomerReviews";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsConditions from "./pages/TermsConditions";
import AdminDashboard from "./pages/admin/Dashboard";
import AdminBookings from "./pages/admin/BookingsOperations";
import AdminContent from "./pages/admin/ContentManager";
import AdminRooms from "./pages/admin/RoomsInventory";
import AdminInquiries from "./pages/admin/Inquiries";
import AdminSettings from "./pages/admin/SettingsPanel";
import { useAuth } from "./_core/hooks/useAuth";
import { useEffect } from "react";

function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}

function AdminGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  const isAdmin = !!user && user.role === "admin";

  useEffect(() => {
    if (loading) return;
    if (!isAdmin) setLocation("/login");
  }, [loading, isAdmin, setLocation]);

  if (loading) return null;
  if (!isAdmin) return null;

  return <>{children}</>;
}

function Router() {
  return (
    <Switch>
      {/* صفحات عامة */}
      <Route path="/" component={() => <PublicLayout><Home /></PublicLayout>} />
      <Route path="/rooms" component={() => <PublicLayout><Rooms /></PublicLayout>} />
      <Route path="/rooms/:id" component={() => <PublicLayout><RoomDetail /></PublicLayout>} />
      <Route path="/facilities" component={() => <PublicLayout><Facilities /></PublicLayout>} />
      <Route path="/gallery" component={() => <PublicLayout><Gallery /></PublicLayout>} />
      <Route path="/booking" component={() => <PublicLayout><Booking /></PublicLayout>} />
      <Route path="/booking/confirmation" component={() => <PublicLayout><ActualBookingConfirmation /></PublicLayout>} />
      <Route path="/booking/status" component={() => <PublicLayout><BookingRequestStatus /></PublicLayout>} />
      <Route path="/account" component={() => <CustomerAccount />} />
      <Route path="/account/reset" component={() => <ResetCustomerPassword />} />
      <Route path="/my-bookings" component={() => <MyBookings />} />
      <Route path="/reviews" component={() => <CustomerReviews />} />
      <Route path="/contact" component={() => <PublicLayout><Contact /></PublicLayout>} />
      <Route path="/privacy" component={() => <PublicLayout><PrivacyPolicy /></PublicLayout>} />
      <Route path="/terms" component={() => <PublicLayout><TermsConditions /></PublicLayout>} />

      {/* صفحة تسجيل الدخول */}
      <Route path="/login" component={Login} />

      {/* Admin routes (Guarded) */}
      <Route path="/admin" component={() => <AdminGuard><AdminDashboard /></AdminGuard>} />
      <Route path="/admin/bookings" component={() => <AdminGuard><AdminBookings /></AdminGuard>} />
      <Route path="/admin/content" component={() => <AdminGuard><AdminContent /></AdminGuard>} />
      <Route path="/admin/rooms" component={() => <AdminGuard><AdminRooms /></AdminGuard>} />
      <Route path="/admin/inquiries" component={() => <AdminGuard><AdminInquiries /></AdminGuard>} />
      <Route path="/admin/settings" component={() => <AdminGuard><AdminSettings /></AdminGuard>} />

      {/* آخر شيء: 404 */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <LanguageProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
