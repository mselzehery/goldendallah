export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

export const getLoginUrl = () => {
  // ✅ بدلاً من بناء رابط معقد لـ Portal خارجي، وجه المستخدم لصفحة اللوجن المحلية
  // ده هيخلي هوك الـ useAuth لما يلاقيك مش مسجل، يرميك على صفحة اللوجن اللي فيها الـ Key
  try {
    return `${window.location.origin}/login`;
  } catch (e) {
    // احتياطاً لو حصل أي خطأ في الـ origin
    return "/login";
  }
};