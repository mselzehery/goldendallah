import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Globe, Phone } from "lucide-react";
import { useLang } from "@/contexts/LanguageContext";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";

export default function Navbar() {
  const { lang, setLang, t } = useLang();
  const { user, isAuthenticated, logout } = useAuth({ redirectOnUnauthenticated: false });
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();
  const { data: hotelSettings } = trpc.hotel.useQuery();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/", label: t("الرئيسية", "Home") },
    { href: "/rooms", label: t("الغرف", "Rooms") },
    { href: "/facilities", label: t("المرافق", "Facilities") },
    { href: "/gallery", label: t("المعرض", "Gallery") },
    { href: "/contact", label: t("تواصل معنا", "Contact") },
  ];

  const isHome = location === "/";
  const isTransparent = isHome && !scrolled;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isTransparent
          ? "bg-transparent"
          : "bg-white/95 backdrop-blur-md shadow-lg border-b border-amber-100"
      }`}
    >
      {/* Top bar */}
      <div
        className={`transition-all duration-500 ${
          isTransparent ? "bg-black/20" : "bg-[#780000]"
        } py-1.5`}
      >
        <div className="container flex items-center justify-between text-xs">
          <div className="flex items-center gap-4 text-white/90">
            <span className="flex items-center gap-1">
              <Phone className="w-3 h-3" />
              {hotelSettings?.supportPhone || "966163269881+"}
            </span>
            <span>|</span>
            <span>{hotelSettings?.supportEmail || "saadsalem@goldendalahotel.com"}</span>
          </div>
          <button
            onClick={() => setLang(lang === "ar" ? "en" : "ar")}
            className="flex items-center gap-1 text-white/90 hover:text-white transition-colors"
          >
            <Globe className="w-3 h-3" />
            <span>{lang === "ar" ? "English" : "عربي"}</span>
          </button>
        </div>
      </div>

      {/* Main nav */}
      <div className="container">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="relative">
       <div
  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 overflow-hidden ${
    isTransparent 
      ? "bg-[#780000] shadow-lg" // الحالة الأولى: فوق (الخلفية حمراء)
      : "bg-white"               // الحالة الثانية: نزل تحت (الخلفية بيضاء)
  }`}
>
  <img 
    src="/logo.png.png" 
    alt="Logo" 
    className={`w-9 h-9 transition-all duration-300 ${
      isTransparent 
        ? "brightness-0 invert" // يخلي اللوجو أبيض تماماً لو كان أصله غامق
        : "brightness-100"      // يرجع اللوجو لألوانه الطبيعية (أو العكس حسب رغبتك)
    }`}
    style={{ padding: '6px' }} // إضافة مسافة بسيطة عشان اللوجو ما يلمس الأطراف
  />
</div>
            </div>
            <div>
              <div
                className={`font-bold text-lg leading-tight transition-colors ${
                  isTransparent ? "text-white" : "text-[#780000]"
                }`}
                style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}
              >
                {t(hotelSettings?.hotelNameAr || "جولدن دلة", hotelSettings?.hotelNameEn || "Golden Dalah")}
              </div>
              <div
                className={`text-xs tracking-widest uppercase transition-colors ${
                  isTransparent ? "text-amber-300" : "text-amber-600"
                }`}
              >
                
              </div>
            </div>
          </Link>

          {/* Desktop nav links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={`px-4 py-2 text-sm font-medium rounded-md transition-all duration-200 relative group ${
                  location === link.href
                    ? isTransparent
                      ? "text-amber-300"
                      : "text-[#780000]"
                    : isTransparent
                    ? "text-white/90 hover:text-white"
                    : "text-gray-700 hover:text-[#780000]"
                }`}
              >
                {link.label}
                <span
                  className={`absolute bottom-0 left-1/2 -translate-x-1/2 h-0.5 bg-amber-400 transition-all duration-300 ${
                    location === link.href ? "w-4/5" : "w-0 group-hover:w-4/5"
                  }`}
                />
              </Link>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:flex items-center gap-3">
            {isAuthenticated && user?.role === "user" ? (
              <Link href="/my-bookings">
                <Button
                  variant="outline"
                  className={`text-sm font-semibold px-5 py-2 rounded-full transition-all duration-300 ${
                    isTransparent
                      ? "border-white text-white hover:bg-white hover:text-[#780000]"
                      : "border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white"
                  }`}
                >
                  {t("حجوزاتي", "My Bookings")}
                </Button>
              </Link>
            ) : (
              <Link href="/account">
                <Button
                  variant="outline"
                  className={`text-sm font-semibold px-5 py-2 rounded-full transition-all duration-300 ${
                    isTransparent
                      ? "border-white text-white hover:bg-white hover:text-[#780000]"
                      : "border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white"
                  }`}
                >
                  {t("حسابي", "My Account")}
                </Button>
              </Link>
            )}
            <Link href="/booking">
              <Button
                className={`text-sm font-semibold px-6 py-2 rounded-full transition-all duration-300 ${
                  isTransparent
                    ? "bg-amber-500 hover:bg-amber-400 text-white border-0"
                    : "bg-[#780000] hover:bg-[#600000] text-white border-0"
                }`}
              >
                {t("احجز الآن", "Book Now")}
              </Button>
            </Link>
            {isAuthenticated && user?.role === "user" ? (
              <>
                <Link href="/my-bookings" onClick={() => setIsOpen(false)} className="px-4 py-3 text-sm font-medium rounded-md text-gray-700 hover:bg-gray-50 hover:text-[#780000]">
                  {t("حجوزاتي", "My Bookings")}
                </Link>
                <button
                  onClick={async () => {
                    await logout();
                    setIsOpen(false);
                    window.location.href = "/";
                  }}
                  className="w-full text-start px-4 py-3 text-sm font-medium rounded-md text-red-700 hover:bg-red-50"
                >
                  {t("تسجيل الخروج", "Logout")}
                </button>
              </>
            ) : (
              <Link href="/account" onClick={() => setIsOpen(false)} className="px-4 py-3 text-sm font-medium rounded-md text-gray-700 hover:bg-gray-50 hover:text-[#780000]">
                {t("حسابي", "My Account")}
              </Link>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className={`md:hidden p-2 rounded-md transition-colors ${
              isTransparent ? "text-white" : "text-[#780000]"
            }`}
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 shadow-xl">
          <div className="container py-4 flex flex-col gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className={`px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  location === link.href
                    ? "bg-[#780000]/10 text-[#780000]"
                    : "text-gray-700 hover:bg-gray-50 hover:text-[#780000]"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <Link href="/booking" onClick={() => setIsOpen(false)}>
              <Button className="w-full mt-2 bg-[#780000] hover:bg-[#600000] text-white">
                {t("احجز الآن", "Book Now")}
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
