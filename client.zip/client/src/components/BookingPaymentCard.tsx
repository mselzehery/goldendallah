import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { AlertCircle, CheckCircle2, CreditCard, Loader2, Wallet } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/contexts/LanguageContext";

type Props = {
  refCode: string;
};

type StatusMeta = {
  labelAr: string;
  labelEn: string;
  className: string;
};

const statusMeta: Record<string, StatusMeta> = {
  pending: { labelAr: "بانتظار الدفع", labelEn: "Pending Payment", className: "bg-amber-100 text-amber-700" },
  processing: { labelAr: "قيد المعالجة", labelEn: "Processing", className: "bg-blue-100 text-blue-700" },
  paid: { labelAr: "مدفوع", labelEn: "Paid", className: "bg-emerald-100 text-emerald-700" },
  failed: { labelAr: "فشل الدفع", labelEn: "Payment Failed", className: "bg-red-100 text-red-700" },
  cancelled: { labelAr: "أُلغي", labelEn: "Cancelled", className: "bg-gray-100 text-gray-600" },
  refunded: { labelAr: "مسترد", labelEn: "Refunded", className: "bg-purple-100 text-purple-700" },
};

export default function BookingPaymentCard({ refCode }: Props) {
  const { t, lang } = useLang();
  const utils = trpc.useUtils();
  const paymentMethods = trpc.payments.methods.useQuery();
  const bookingPayment = trpc.payments.getBookingPayment.useQuery(
    { ref: refCode },
    { enabled: !!refCode }
  );

  const preparePayment = trpc.payments.prepareBookingPayment.useMutation({
    onSuccess: async (result) => {
      await bookingPayment.refetch();
      await utils.payments.getBookingPayment.invalidate({ ref: refCode });

      if (result.checkoutUrl) {
        window.location.href = result.checkoutUrl;
        return;
      }

      toast.success(
        t(
          "تم تجهيز عملية الدفع. سيظهر رابط Paymob هنا بمجرد اكتمال الربط.",
          "Payment process is prepared. A Paymob link will appear once the connection is ready."
        )
      );
    },
    onError: (error) => {
      toast.error(error.message || t("تعذر تجهيز عملية الدفع الآن", "Unable to prepare payment right now"));
    },
  });

  const payment = bookingPayment.data?.payment;
  const paymentStatusMeta = payment ? statusMeta[payment.status] ?? statusMeta.pending : null;
  const statusInfo = paymentStatusMeta
    ? {
        label: lang === "ar" ? paymentStatusMeta.labelAr : paymentStatusMeta.labelEn,
        className: paymentStatusMeta.className,
      }
    : null;

  return (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-8 text-start">
      <div className="flex items-start justify-between gap-4 mb-5">
        <div>
          <h3 className="font-semibold text-gray-800 mb-1">{t("الدفع الإلكتروني للحجز", "Booking Payment")}</h3>
          <p className="text-sm text-gray-500">
            {t(
              "يمكن للعميل إكمال الدفع مباشرة بعد تأكيد الحجز عبر Paymob وطرق الدفع الشائعة في السعودية.",
              "Customers can complete payment immediately after confirming the booking via Paymob and popular payment methods in Saudi Arabia."
            )}
          </p>
        </div>
        {statusInfo ? (
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusInfo.className}`}>
            {statusInfo.label}
          </span>
        ) : null}
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        {(paymentMethods.data?.methods ?? []).map((method) => (
          <div key={method.key} className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-gray-50 px-3 py-2 text-sm text-gray-700">
            {method.category === "wallet" ? <Wallet className="w-4 h-4 text-emerald-600" /> : <CreditCard className="w-4 h-4 text-[#780000]" />}
            <span>{lang === "ar" ? method.labelAr : method.labelEn}</span>
          </div>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 gap-3 text-sm mb-5">
        <div className="rounded-xl bg-[#faf8f5] p-4">
          <span className="text-gray-400 block mb-1">{t("المبلغ المطلوب", "Amount Due")}</span>
          <span className="font-bold text-[#780000]">
            {parseFloat(String(bookingPayment.data?.amount ?? 0)).toLocaleString()} {t("ريال", "SAR")}
          </span>
        </div>
        <div className="rounded-xl bg-[#faf8f5] p-4">
          <span className="text-gray-400 block mb-1">{t("مرجع الدفع", "Payment Reference")}</span>
          <span className="font-medium" dir="ltr">
            {payment?.merchantOrderId || t("سيُنشأ عند الضغط على الدفع", "Will be generated when pressing pay")}
          </span>
        </div>
      </div>

      {payment?.status === "paid" ? (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          {t("تم تسجيل السداد على هذا الحجز بنجاح.", "Payment has been successfully recorded for this booking.")}
        </div>
      ) : (
        <div className="space-y-3">
          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-700 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 mt-0.5" />
            <span>
              {t(
                "يمكنك الدفع الآن أو لاحقًا. الضغط على زر الدفع ينشئ عملية سداد مرتبطة بالحجز فقط.",
                "You can pay now or later. Pressing the pay button will create a payment transaction linked only to the booking."
              )}
            </span>
          </div>
          <Button
            onClick={() => preparePayment.mutate({ ref: refCode })}
            disabled={preparePayment.isPending || !refCode}
            className="bg-[#780000] hover:bg-[#600000] text-white rounded-full px-8"
          >
            {preparePayment.isPending ? (
              <>
                <Loader2 className="w-4 h-4 ms-2 animate-spin" />
                {t("جارٍ تجهيز الدفع", "Preparing payment")}
              </>
            ) : (
              <>
                <CreditCard className="w-4 h-4 ms-2" />
                {t("ادفع الآن عبر Paymob", "Pay now via Paymob")}
              </>
            )}
          </Button>
        </div>
      )}
    </div>
  );
}
