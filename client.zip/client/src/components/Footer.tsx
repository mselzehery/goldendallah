﻿import { Link } from "wouter";
import { MapPin, Phone, Mail, MessageCircle, Instagram, Music, Facebook } from "lucide-react";
import { useLang } from "@/contexts/LanguageContext";
import { trpc } from "@/lib/trpc";

export default function Footer() {
  const { t } = useLang();
  const { data: hotelSettings } = trpc.hotel.useQuery();

  return (
    <footer className="bg-[#1a0000] text-white">
      <div className="h-1 bg-gradient-to-r from-transparent via-amber-500 to-transparent" />

      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center overflow-hidden">
                <img src="/logo.png.png" alt="Logo" className="w-10 h-10" />
              </div>
              <div>
                <div className="text-white font-bold text-xl" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                  {t(hotelSettings?.hotelNameAr || "جولدن دلة", hotelSettings?.hotelNameEn || "Golden Dalah")}
                </div>
                {/* <div className="text-amber-400 text-xs tracking-widest uppercase">{t("فندق فاخر", "Luxury Hotel")}</div> */}
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              {t(
                "نقدم لضيوفنا تجربة إقامة استثنائية تجمع بين الفخامة والراحة والخدمة الراقية في قلب القصيم.",
                "We offer our guests an exceptional stay combining luxury and comfort in the heart of Al Qassim."
              )}
            </p>
            <div className="flex gap-3">
              {[
                { icon: Instagram, href: "https://www.instagram.com/goldendallah9?igsh=MWxxZXNyZ250a3V4eQ%3D%3D" },
                { icon: Music, href: "https://www.tiktok.com/@golden.dallah" },
                { icon: Facebook, href: "https://www.facebook.com/share/1EK6hu3Rsv/" },
                { icon: MessageCircle, href: hotelSettings?.whatsappNumber ? `https://wa.me/${hotelSettings.whatsappNumber.replace(/[^0-9]/g, "")}` : "https://wa.me/966163269881" },
              ].map(({ icon: Icon, href }, i) => (
                <a key={i} href={href} className="w-9 h-9 rounded-full bg-white/10 hover:bg-amber-500 flex items-center justify-center transition-colors">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-amber-400 font-semibold mb-5 text-sm uppercase tracking-wider">{t("روابط سريعة", "Quick Links")}</h4>
            <ul className="space-y-3">
              {[
                { href: "/", label: t("الرئيسية", "Home") },
                { href: "/rooms", label: t("الغرف والأجنحة", "Rooms & Suites") },
                { href: "/facilities", label: t("المرافق والخدمات", "Facilities") },
                { href: "/gallery", label: t("معرض الصور", "Photo Gallery") },
                { href: "/booking", label: t("احجز الآن", "Book Now") },
                { href: "/contact", label: t("تواصل معنا", "Contact Us") },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-gray-400 hover:text-amber-400 text-sm transition-colors flex items-center gap-2 group">
                    <span className="w-1 h-1 rounded-full bg-amber-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-amber-400 font-semibold mb-5 text-sm uppercase tracking-wider">{t("خدماتنا", "Our Services")}</h4>
            <ul className="space-y-3">
              {[
                t("واي فاي مجاني", "Free WiFi"),
                t("استقبال على مدار الساعة", "24/7 Reception"),
                t("مواقف سيارات", "Parking"),
                t("حامل الأحقاب", "Luggage Service"),
                t("خدمة الغرف", "Room Service")
  ,
              ].map((service) => (
                <li key={service} className="text-gray-400 text-sm flex items-center gap-2">
                  <span className="w-1 h-1 rounded-full bg-amber-500" />
                  {service}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-amber-400 font-semibold mb-5 text-sm uppercase tracking-wider">{t("تواصل معنا", "Contact Us")}</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-gray-400 text-sm">
                <MapPin className="w-4 h-4 text-amber-500 mt-0.5 shrink-0" />
                <span>
                  {t(hotelSettings?.addressAr || "حي الريان، القصيم، المملكة العربية السعودية", hotelSettings?.addressEn || "Al Rayyan District, Al Qassim, Saudi Arabia")}
                </span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <span dir="ltr">{hotelSettings?.supportPhone || "+966163269881"}</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Mail className="w-4 h-4 text-amber-500 shrink-0" />
                <span>{hotelSettings?.supportEmail || "saad.salem@goldendalahotel.com"}</span>
              </li>
              <li className="flex items-center gap-3 text-gray-400 text-sm">
                <Phone className="w-4 h-4 text-amber-500 shrink-0" />
                <span dir="ltr">{hotelSettings?.whatsappNumber || "+966552633372"}</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-gray-500">
          <span>
© 2026 {t("شركة عبدالرحمن الجابري التقنية. جميع الحقوق محفوظة.", "Abdulrahman Al-Jabri Tech. All rights reserved.")}
          </span>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-amber-400 transition-colors">{t("الخصوصية", "Privacy")}</Link>
            <Link href="/terms" className="hover:text-amber-400 transition-colors">{t("السياسة", "Policy")}</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
