import { useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";

const PAGE_HEADER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/lobby3_7229ee0e.jpg";

const categoryLabels: Record<string, { ar: string; en: string }> = {
  all: { ar: "الكل", en: "All" },
  lobby: { ar: "اللوبي", en: "Lobby" },
  rooms: { ar: "الغرف", en: "Rooms" },
  dining: { ar: "كوفي شوب", en: "COFFEE SHOP" },
  // pool: { ar: "المسبح", en: "Pool" },
  // spa: { ar: "السبا", en: "Spa" },
    // events: { ar: "الفعاليات", en: "Events" },
// تم إخفاءها لعدم وجود صور كافية في هذه التصنيفات
  exterior: { ar: "الخارج", en: "Exterior" },
};

export default function Gallery() {
  const { t, lang, isRTL } = useLang();
  const [category, setCategory] = useState("all");
  const [lightbox, setLightbox] = useState<{ index: number; images: string[] } | null>(null);

  const { data: images, isLoading } = trpc.gallery.list.useQuery({ category });

  const openLightbox = (index: number) => {
    if (!images) return;
    setLightbox({ index, images: images.map((i) => i.imageUrl) });
  };

  const closeLightbox = () => setLightbox(null);

  const prevImage = () => {
    if (!lightbox) return;
    setLightbox({ ...lightbox, index: (lightbox.index - 1 + lightbox.images.length) % lightbox.images.length });
  };

  const nextImage = () => {
    if (!lightbox) return;
    setLightbox({ ...lightbox, index: (lightbox.index + 1) % lightbox.images.length });
  };

  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <div className="relative h-64 md:h-80 overflow-hidden">
        <img src={PAGE_HEADER_IMG} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center pt-16">
          <p className="text-amber-300 text-sm tracking-widest uppercase mb-2">{t("استكشف", "Explore")}</p>
          <h1 className="text-3xl md:text-5xl font-bold" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
            {t("معرض الصور", "Photo Gallery")}
          </h1>
          <div className="flex items-center gap-3 mt-3">
            <div className="h-px w-12 bg-amber-400" />
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <div className="h-px w-12 bg-amber-400" />
          </div>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="bg-white border-b border-gray-100 sticky top-[88px] z-30 shadow-sm">
        <div className="container">
          <div className="flex gap-1 py-3 overflow-x-auto">
            {Object.entries(categoryLabels).map(([key, labels]) => (
              <button
                key={key}
                onClick={() => setCategory(key)}
                className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                  category === key
                    ? "bg-[#780000] text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                {lang === "ar" ? labels.ar : labels.en}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Gallery Grid */}
      <section className="py-16 bg-[#faf8f5]">
        <div className="container">
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="rounded-xl bg-gray-200 animate-pulse aspect-square" />
              ))}
            </div>
          ) : images && images.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {images.map((img, index) => (
                <div
                  key={img.id}
                  onClick={() => openLightbox(index)}
                  className="relative group cursor-pointer rounded-xl overflow-hidden aspect-square luxury-card"
                >
                  <img
                    src={img.imageUrl}
                    alt={lang === "ar" ? img.titleAr || "" : img.titleEn || ""}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-white text-center px-4">
                      <div className="w-10 h-10 border-2 border-white rounded-full flex items-center justify-center mx-auto mb-2">
                        <span className="text-lg">+</span>
                      </div>
                      <p className="text-sm font-medium">
                        {lang === "ar" ? img.titleAr : img.titleEn}
                      </p>
                    </div>
                  </div>
                  <div className="absolute bottom-0 start-0 end-0 p-3 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="text-white text-xs">
                      {lang === "ar" ? categoryLabels[img.category]?.ar : categoryLabels[img.category]?.en}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20 text-gray-500">
              {t("لا توجد صور في هذا التصنيف", "No images in this category")}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-4 end-4 w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors z-10"
          >
            <X className="w-5 h-5" />
          </button>

          <button
            onClick={(e) => { e.stopPropagation(); prevImage(); }}
            className="absolute start-4 w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors z-10"
          >
            {isRTL ? <ChevronRight className="w-6 h-6" /> : <ChevronLeft className="w-6 h-6" />}
          </button>

          <img
            src={lightbox.images[lightbox.index]}
            alt=""
            className="max-w-[90vw] max-h-[85vh] object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />

          <button
            onClick={(e) => { e.stopPropagation(); nextImage(); }}
            className="absolute end-4 w-12 h-12 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center text-white transition-colors z-10"
          >
            {isRTL ? <ChevronLeft className="w-6 h-6" /> : <ChevronRight className="w-6 h-6" />}
          </button>

          <div className="absolute bottom-4 text-white/60 text-sm">
            {lightbox.index + 1} / {lightbox.images.length}
          </div>
        </div>
      )}
    </div>
  );
}
