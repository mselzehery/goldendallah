import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { BellRing, CalendarDays, KeyRound, LogOut, Mail, Phone, UserRound } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

type BookingStatus = "pending" | "confirmed" | "cancelled" | "completed";

type BookingRow = {
  id: number;
  bookingRef: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string | null;
  guestNationality: string | null;
  checkIn: Date;
  checkOut: Date;
  adults: number;
  children: number;
  totalNights: number;
  totalPrice: string;
  status: BookingStatus;
  specialRequests: string | null;
  roomNameAr: string | null;
  roomNameEn: string | null;
  roomImageUrl: string | null;
  roomType: string | null;
};

type NotificationRow = {
  id: number;
  title: string;
  message: string;
  type: string;
  isRead: boolean;
  createdAt: Date;
};

export default function MyBookingsPortal() {
  const { user, isAuthenticated, loading, logout } = useAuth({ redirectOnUnauthenticated: false });
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const { data: bookings, isLoading } = trpc.bookings.mine.useQuery(undefined, {
    enabled: !!isAuthenticated && user?.role === "user",
  });

  const { data: notifications } = trpc.bookings.notifications.useQuery(undefined, {
    enabled: !!isAuthenticated && user?.role === "user",
  });

  const markNotificationsRead = trpc.bookings.markNotificationsRead.useMutation({
    onSuccess: async () => {
      await utils.bookings.notifications.invalidate();
    },
  });

  const changePassword = trpc.auth.customerChangePassword.useMutation({
    onSuccess: () => {
      toast.success("تم تغيير كلمة المرور");
      setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (!loading && (!isAuthenticated || user?.role !== "user")) {
      navigate("/account");
    }
  }, [loading, isAuthenticated, navigate, user]);

  useEffect(() => {
    if ((notifications ?? []).some((item) => !item.isRead) && !markNotificationsRead.isPending) {
      void markNotificationsRead.mutateAsync();
    }
  }, [notifications, markNotificationsRead]);

  if (!loading && (!isAuthenticated || user?.role !== "user")) {
    return null;
  }

  const statusStyles: Record<BookingStatus, string> = {
    pending: "bg-amber-100 text-amber-700",
    confirmed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    completed: "bg-blue-100 text-blue-700",
  };

  const statusLabels: Record<BookingStatus, string> = {
    pending: "قيد المراجعة",
    confirmed: "مؤكد",
    cancelled: "ملغي",
    completed: "مكتمل",
  };

  async function handleChangePassword() {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("تأكيد كلمة المرور غير مطابق");
      return;
    }

    await changePassword.mutateAsync({
      currentPassword: passwordForm.currentPassword,
      newPassword: passwordForm.newPassword,
    });
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] px-4 py-12" dir="rtl">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-8 flex flex-col lg:flex-row gap-6 justify-between">
          <div>
            <p className="text-sm text-gray-500 mb-2">مرحبًا بك</p>
            <h1 className="text-3xl font-bold text-[#780000] mb-3">{user?.name || "ضيف جولدن دلة"}</h1>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              <span className="inline-flex items-center gap-2">
                <Mail className="w-4 h-4 text-[#780000]" />
                {user?.email}
              </span>
              <span className="inline-flex items-center gap-2">
                <UserRound className="w-4 h-4 text-[#780000]" />
                حساب ضيف
              </span>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Button variant="outline" className="rounded-full" onClick={() => navigate("/booking")}>
              حجز جديد
            </Button>
            <Button
              className="rounded-full bg-[#780000] hover:bg-[#600000] text-white"
              onClick={async () => {
                await logout();
                navigate("/");
              }}
            >
              <LogOut className="w-4 h-4 ms-2" />
              تسجيل الخروج
            </Button>
          </div>
        </div>

        {(notifications ?? []).length > 0 ? (
          <section className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
            <div className="flex items-center gap-2 mb-4">
              <BellRing className="w-5 h-5 text-[#780000]" />
              <h2 className="text-xl font-bold text-[#780000]">إشعارات الحساب والحجز</h2>
            </div>
            <div className="grid gap-3">
              {(notifications as NotificationRow[]).slice(0, 5).map((item) => (
                <div key={item.id} className={`rounded-2xl border p-4 ${item.isRead ? "border-gray-200 bg-gray-50" : "border-[#e8c8c8] bg-[#fff8f8]"}`}>
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                    <p className="font-semibold text-[#780000]">{item.title}</p>
                    <span className="text-xs text-gray-500">
                      {new Date(item.createdAt).toLocaleString("ar-SA")}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{item.message}</p>
                </div>
              ))}
            </div>
          </section>
        ) : null}

        <div className="grid lg:grid-cols-[2fr,1fr] gap-6">
          <section className="space-y-4">
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-[#780000]">حجوزاتي</h2>
                <span className="text-sm text-gray-500">{bookings?.length ?? 0} حجز</span>
              </div>

              <div className="space-y-4">
                {isLoading ? (
                  <div className="py-12 text-center">
                    <div className="w-8 h-8 border-2 border-[#780000] border-t-transparent rounded-full animate-spin mx-auto" />
                  </div>
                ) : (bookings ?? []).length > 0 ? (
                  (bookings as BookingRow[]).map((booking) => (
                    <div key={booking.id} className="rounded-2xl border border-gray-100 overflow-hidden">
                      <div className="grid md:grid-cols-[220px,1fr]">
                        <div className="h-48 md:h-full bg-gray-100">
                          {booking.roomImageUrl ? (
                            <img src={booking.roomImageUrl} alt="" className="w-full h-full object-cover" />
                          ) : null}
                        </div>
                        <div className="p-5 space-y-4">
                          <div className="flex flex-wrap items-center justify-between gap-3">
                            <div>
                              <p className="text-xs text-gray-400 mb-1">رقم الحجز</p>
                              <p className="font-mono text-[#780000]" dir="ltr">{booking.bookingRef}</p>
                            </div>
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusStyles[booking.status]}`}>
                              {statusLabels[booking.status]}
                            </span>
                          </div>

                          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600">
                            <div>
                              <p className="text-xs text-gray-400 mb-1">الغرفة</p>
                              <p className="font-semibold text-gray-800">{booking.roomNameAr || booking.roomNameEn || "غرفة"}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-400 mb-1">الإجمالي</p>
                              <p className="font-semibold text-[#780000]">{parseFloat(String(booking.totalPrice)).toLocaleString()} ريال</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-400 mb-1">الوصول</p>
                              <p dir="ltr">{new Date(booking.checkIn).toLocaleDateString("ar-SA")}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-400 mb-1">المغادرة</p>
                              <p dir="ltr">{new Date(booking.checkOut).toLocaleDateString("ar-SA")}</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-400 mb-1">الضيوف</p>
                              <p>{booking.adults} بالغ / {booking.children} طفل</p>
                            </div>
                            <div>
                              <p className="text-xs text-gray-400 mb-1">عدد الليالي</p>
                              <p>{booking.totalNights} ليلة</p>
                            </div>
                          </div>

                          {booking.guestPhone ? (
                            <div className="text-sm">
                              <a
                                href={`https://wa.me/${booking.guestPhone.replace(/\D/g, "")}`}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-2 text-green-700"
                              >
                                <Phone className="w-4 h-4" />
                                <span dir="ltr">{booking.guestPhone}</span>
                              </a>
                            </div>
                          ) : null}

                          {booking.specialRequests ? (
                            <div className="rounded-2xl bg-gray-50 p-4 text-sm text-gray-600">
                              <p className="text-xs text-gray-400 mb-1">طلبات خاصة</p>
                              <p>{booking.specialRequests}</p>
                            </div>
                          ) : null}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-12 text-center text-gray-400">
                    <CalendarDays className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>لا توجد حجوزات مرتبطة بهذا الحساب حتى الآن.</p>
                  </div>
                )}
              </div>
            </div>
          </section>

          <aside className="space-y-6">
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6">
              <h2 className="text-lg font-bold text-[#780000] mb-4">أمان الحساب</h2>
              <div className="space-y-4">
                <div>
                  <Label className="mb-2 block">كلمة المرور الحالية</Label>
                  <Input type="password" value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })} />
                </div>
                <div>
                  <Label className="mb-2 block">كلمة المرور الجديدة</Label>
                  <Input type="password" value={passwordForm.newPassword} onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })} />
                </div>
                <div>
                  <Label className="mb-2 block">تأكيد كلمة المرور</Label>
                  <Input type="password" value={passwordForm.confirmPassword} onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })} />
                </div>
                <Button className="w-full bg-[#780000] hover:bg-[#600000] text-white rounded-full" onClick={() => void handleChangePassword()}>
                  <KeyRound className="w-4 h-4 ms-2" />
                  تغيير كلمة المرور
                </Button>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
