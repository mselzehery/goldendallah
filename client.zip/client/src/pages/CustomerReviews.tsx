import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Star, Calendar, User, MessageSquare } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function CustomerReviews() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState("write");
  const [rating, setRating] = useState(5);
  const [review, setReview] = useState({
    guestName: "",
    roomType: "",
    stayDate: "",
    reviewText: "",
  });

  const createReview = trpc.reviews.create.useMutation({
    onSuccess: () => {
      toast.success(t("تم إرسال تقييمك بنجاح! شكراً لك.", "Review submitted successfully! Thank you."));
      setReview({
        guestName: "",
        roomType: "",
        stayDate: "",
        reviewText: "",
      });
      setRating(5);
    },
    onError: () => {
      toast.error(t("فشل إرسال التقييم. حاول مرة أخرى.", "Failed to submit review. Please try again."));
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!review.guestName || !review.reviewText || rating < 1) {
      toast.error(t("يرجى ملء جميع الحقول المطلوبة", "Please fill all required fields"));
      return;
    }

    createReview.mutate({
      guestName: review.guestName,
      guestRoleAr: "نزيل",
      guestRoleEn: "Guest",
      reviewTextAr: review.reviewText,
      reviewTextEn: review.reviewText,
      rating: rating,
      sortOrder: 0,
      isActive: true,
      avatarImageUrl: undefined,
    });
  };

  const existingReviews = trpc.reviews.list.useQuery();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {t("آراء العملاء", "Customer Reviews")}
          </h1>
          <p className="text-lg text-gray-600">
            {t("نحن نقدر رأيك - شارك تجربتك معنا", "We value your feedback - Share your experience with us")}
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="write" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              {t("كتابة تقييم", "Write Review")}
            </TabsTrigger>
            <TabsTrigger value="view" className="flex items-center gap-2">
              <Star className="h-4 w-4" />
              {t("عرض التقييمات", "View Reviews")}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="write" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  {t("كتابة تقييم جديد", "Write New Review")}
                </CardTitle>
                <CardDescription>
                  {t("شاركنا رأيك في إقامتك في فندق جولدن دلة", "Share your feedback about your stay at Golden Dallah Hotel")}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="guestName">
                        {t("الاسم الكامل", "Full Name")}
                      </Label>
                      <Input
                        id="guestName"
                        type="text"
                        value={review.guestName}
                        onChange={(e) => setReview({ ...review, guestName: e.target.value })}
                        placeholder={t("أدخل اسمك الكامل", "Enter your full name")}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="stayDate">
                        {t("تاريخ الإقامة", "Stay Date")}
                      </Label>
                      <Input
                        id="stayDate"
                        type="date"
                        value={review.stayDate}
                        onChange={(e) => setReview({ ...review, stayDate: e.target.value })}
                        max={new Date().toISOString().split('T')[0]}
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="roomType">
                      {t("نوع الغرفة", "Room Type")}
                    </Label>
                    <Input
                      id="roomType"
                      type="text"
                      value={review.roomType}
                      onChange={(e) => setReview({ ...review, roomType: e.target.value })}
                      placeholder={t("مثال: جناح ديلوكس", "Example: Deluxe Suite")}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="rating">
                      {t("التقييم", "Rating")}
                    </Label>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            type="button"
                            onClick={() => setRating(star)}
                            className="p-1 hover:bg-gray-100 transition-colors"
                          >
                            <Star
                              className={`h-6 w-6 ${
                                star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {rating}/5 {t("نجوم", "stars")}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reviewText">
                      {t("التقييم", "Review")}
                    </Label>
                    <Textarea
                      id="reviewText"
                      value={review.reviewText}
                      onChange={(e) => setReview({ ...review, reviewText: e.target.value })}
                      placeholder={t("اكتب هنا تجربتك معنا...", "Write your experience with us here...")}
                      rows={4}
                      required
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full bg-[#780000] hover:bg-[#600000] text-white"
                    disabled={createReview.isPending}
                  >
                    {createReview.isPending 
                      ? t("جاري الإرسال...", "Sending...") 
                      : t("إرسال التقييم", "Submit Review")
                    }
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="view" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {existingReviews.data?.map((review: any) => (
                <Card key={review.id} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-start space-y-4">
                      <div className="flex-shrink-0">
                        {review.avatarImageUrl ? (
                          <img
                            src={review.avatarImageUrl}
                            alt={review.guestName}
                            className="h-12 w-12 rounded-full object-cover"
                          />
                        ) : (
                          <div className="h-12 w-12 rounded-full bg-[#780000] flex items-center justify-center">
                            <User className="h-6 w-6 text-white" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold text-gray-900">
                            {review.guestName}
                          </h3>
                          <Badge variant="secondary" className="text-xs">
                            {review.roleAr || review.roleEn}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-4 w-4 ${
                                  star <= review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <span className="ml-2 text-sm text-gray-600">
                            {review.rating}/5 {t("نجوم", "stars")}
                          </span>
                        </div>
                        
                        {review.stayDate && (
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Calendar className="h-4 w-4" />
                            {new Date(review.stayDate).toLocaleDateString('ar-SA')}
                          </div>
                        )}
                        
                        <p className="text-gray-700 leading-relaxed">
                          {review.reviewTextAr || review.reviewTextEn}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {existingReviews.data?.length === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    {t("لا توجد تقييمات بعد", "No reviews yet")}
                  </h3>
                  <p className="text-gray-600">
                    {t("كن أول من يشارك رأيه!", "Be the first to share your feedback!")}
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
