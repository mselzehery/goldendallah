import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

export default function AdminLogin() {
  const { user, loading, isAuthenticated } = useAuth({ redirectOnUnauthenticated: false });
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const utils = trpc.useUtils();

  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: async () => {
      setErrorMessage("");
      await utils.auth.me.invalidate();
      window.location.replace("/admin");
    },
    onError: (error) => {
      setErrorMessage(error.message || "فشل تسجيل الدخول");
    },
  });

  useEffect(() => {
    if (!loading && isAuthenticated && user?.role === "admin") {
      window.location.replace("/admin");
    }
  }, [isAuthenticated, loading, user]);

  async function handleLogin() {
    const trimmedUsername = username.trim();
    if (!trimmedUsername || !password.trim()) {
      setErrorMessage("يرجى إدخال اسم المستخدم وكلمة المرور");
      return;
    }

    setErrorMessage("");
    await loginMutation.mutateAsync({
      username: trimmedUsername,
      password,
    });
  }

  if (loading && !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-12 h-12 animate-spin text-[#780000]" />
      </div>
    );
  }

  const isSubmitting = loginMutation.isPending;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-white to-gray-100 px-4 font-sans" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-[#780000] mb-4 shadow-xl">
            <span className="text-amber-400 font-bold text-4xl">G</span>
          </div>
          <h1 className="text-3xl font-bold text-[#780000] mb-2">جولدن دلة</h1>
          <p className="text-gray-500 font-medium">دخول لوحة الإدارة</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-[#780000]"></div>

          <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">تسجيل الدخول</h2>
          <p className="text-gray-500 text-center mb-8 text-sm">
            استخدم اسم المستخدم وكلمة المرور للوصول إلى لوحة التحكم
          </p>

          <div className="space-y-5">
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void handleLogin()}
              placeholder="اسم المستخدم"
              className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#780000] outline-none transition-all text-center"
              autoComplete="username"
              disabled={isSubmitting}
            />

            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void handleLogin()}
              placeholder="كلمة المرور"
              className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#780000] outline-none transition-all text-center font-mono"
              autoComplete="current-password"
              disabled={isSubmitting}
            />

            {errorMessage ? (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 text-center">
                {errorMessage}
              </div>
            ) : null}

            <Button
              onClick={() => void handleLogin()}
              disabled={!username.trim() || !password.trim() || isSubmitting}
              className="w-full bg-[#780000] hover:bg-[#5a0000] text-white py-7 text-lg rounded-2xl font-bold shadow-lg transition-all active:scale-95"
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="animate-spin" />
                  <span>جارٍ التحقق...</span>
                </div>
              ) : "دخول النظام"}
            </Button>
          </div>

          <div className="my-8 flex items-center gap-3">
            <div className="flex-1 h-px bg-gray-200"></div>
            <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Golden Dallah</span>
            <div className="flex-1 h-px bg-gray-200"></div>
          </div>

          <Button
            variant="ghost"
            onClick={() => (window.location.href = "/")}
            className="w-full py-4 text-gray-500 hover:text-[#780000] hover:bg-red-50 rounded-xl transition-colors"
          >
            العودة للموقع الرئيسي
          </Button>
        </div>
      </div>
    </div>
  );
}
