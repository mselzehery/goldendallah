import { useState } from "react";
import { Link, useParams } from "wouter";
import { Users, Maximize2, BedDouble, Check, ArrowRight, ArrowLeft, ChevronLeft, ChevronRight, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";
import { getAmenityLabelsForLang } from "@/lib/roomAmenities";

export default function RoomDetail() {
  const { t, lang, isRTL } = useLang();
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || "0");
  const { data: room, isLoading } = trpc.rooms.byId.useQuery({ id });
  const [activeImg, setActiveImg] = useState(0);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!room) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center pt-20 text-center">
        <h2 className="text-2xl font-bold text-[#780000] mb-4">{t("الغرفة غير موجودة", "Room not found")}</h2>
        <Link href="/rooms"><Button className="bg-[#780000] text-white">{t("العودة للغرف", "Back to Rooms")}</Button></Link>
      </div>
    );
  }

  // ✅ دالة آمنة لتحويل الـ JSON أو النص العادي لمصفوفة
  const safeParse = (data: string | null | undefined): string[] => {
    if (!data) return [];
    try {
      const parsed = JSON.parse(data);
      return Array.isArray(parsed) ? parsed : [String(parsed)];
    } catch (e) {
      // إذا فشل الـ JSON، نقسم النص بناءً على الفواصل العربية أو الإنجليزية
      return data.split(/[،,]+/).map(item => item.trim()).filter(Boolean);
    }
  };

  const images = room.images ? safeParse(room.images) : room.imageUrl ? [room.imageUrl] : [];
  const amenities = getAmenityLabelsForLang(room.amenities, lang);

  const typeLabels: Record<string, string> = {
    "standard": t("غرفة قياسية", "Standard Room"),
    "deluxe": t("غرفة ديلوكس", "Deluxe Room"),
    "suite": t("جناح ملكي", "Royal Suite"),
    "presidential": t("جناح رئاسي", "Presidential Suite"),
    "junior-suite": t("جناح جونيور", "Junior Suite"),
    "studio": t("إستديو", "Studio"),
    "family-suite": t("جناح عائلي", "Family Suite"),
    "accessible": t("غرف لذوي الإحتياجات", "Accessible Room"),
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] pt-20">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100 py-3">
        <div className="container flex items-center gap-2 text-sm text-gray-500">
          <Link href="/" className="hover:text-[#780000]">{t("الرئيسية", "Home")}</Link>
          <span>/</span>
          <Link href="/rooms" className="hover:text-[#780000]">{t("الغرف", "Rooms")}</Link>
          <span>/</span>
          <span className="text-[#780000]">{lang === "ar" ? room.nameAr : room.nameEn}</span>
        </div>
      </div>

      <div className="container py-10">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Left: Images & Details */}
          <div className="lg:col-span-2">
            {/* Main image */}
            <div className="relative rounded-2xl overflow-hidden h-80 md:h-[450px] mb-4 group">
              {images.length > 0 ? (
                <>
                  <img src={images[activeImg]} alt="" className="w-full h-full object-cover" />
                  {images.length > 1 && (
                    <>
                      <button
                        onClick={() => setActiveImg((p) => (p - 1 + images.length) % images.length)}
                        className="absolute start-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        {isRTL ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
                      </button>
                      <button
                        onClick={() => setActiveImg((p) => (p + 1) % images.length)}
                        className="absolute end-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/80 hover:bg-white rounded-full flex items-center justify-center shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        {isRTL ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                      </button>
                    </>
                  )}
                </>
              ) : (
                <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                  <BedDouble className="w-16 h-16 text-gray-400" />
                </div>
              )}
            </div>
            {/* Thumbnails */}
            {images.length > 1 && (
              <div className="flex gap-3 mb-8">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImg(i)}
                    className={`w-20 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                      i === activeImg ? "border-[#780000]" : "border-transparent"
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Room info */}
            <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <span className="bg-[#780000]/10 text-[#780000] text-xs px-3 py-1 rounded-full font-medium">
                    {typeLabels[room.type] || room.type}
                  </span>
                  <h1
                    className="text-3xl font-bold text-[#780000] mt-3"
                    style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}
                  >
                    {lang === "ar" ? room.nameAr : room.nameEn}
                  </h1>
                </div>
              </div>

              <div className="flex flex-wrap gap-6 text-sm text-gray-600 mb-6 pb-6 border-b border-gray-100">
                <span className="flex items-center gap-2"><BedDouble className="w-4 h-4 text-[#780000]" />{room.inventoryCount || 1} {t("وحدة متاحة من هذا النوع", "units of this type")}</span>
                <span className="flex items-center gap-2"><Users className="w-4 h-4 text-[#780000]" />{room.capacity} {t("أشخاص", "guests")}</span>
                {room.size && <span className="flex items-center gap-2"><Maximize2 className="w-4 h-4 text-[#780000]" />{room.size} {t("م²", "sqm")}</span>}
                {room.floor && <span className="flex items-center gap-2"><BedDouble className="w-4 h-4 text-[#780000]" />{t("الطابق", "Floor")} {room.floor}</span>}
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-bold text-gray-800 mb-3">{t("عن الغرفة", "About the Room")}</h3>
                <p className="text-gray-600 leading-relaxed">
                  {lang === "ar" ? room.descriptionAr : room.descriptionEn}
                </p>
              </div>

              {amenities.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-gray-800 mb-4">{t("المرافق والخدمات", "Amenities & Services")}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {amenities.map((a, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="w-4 h-4 text-amber-500 shrink-0" />
                        {a}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right: Booking card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 p-7 sticky top-24">
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-[#780000]">
                  {parseFloat(String(room.pricePerNight)).toLocaleString()}
                </div>
                <div className="text-gray-500 text-sm">{t("ريال سعودي / ليلة", "SAR / night")}</div>
              </div>

              <div className="space-y-3 mb-6 text-sm text-gray-600">
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span>{t("النوع", "Type")}</span>
                  <span className="font-medium text-[#780000]">{typeLabels[room.type] || room.type}</span>
                </div>
                {/* <div className="flex justify-between py-2 border-b border-gray-100">
                  <span>{t("عدد الوحدات", "Inventory")}</span>
                  <span className="font-medium">{room.inventoryCount || 1}</span>
                </div> */}
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span>{t("السعة", "Capacity")}</span>
                  <span className="font-medium">{room.capacity} {t("أشخاص", "guests")}</span>
                </div>
                {room.size && (
                  <div className="flex justify-between py-2 border-b border-gray-100">
                    <span>{t("المساحة", "Size")}</span>
                    <span className="font-medium">{room.size} {t("م²", "sqm")}</span>
                  </div>
                )}
                <div className="flex justify-between py-2 border-b border-gray-100">
                  <span>{t("الحالة", "Status")}</span>
                  <span className={`font-medium ${room.isAvailable ? "text-green-600" : "text-red-600"}`}>
                    {room.isAvailable ? t("متاحة", "Available") : t("محجوزة", "Booked")}
                  </span>
                </div>
              </div>

              {room.isAvailable ? (
                <Link href={`/booking?roomId=${room.id}`}>
                  <Button className="w-full bg-[#780000] hover:bg-[#600000] text-white py-3 rounded-full font-semibold text-base shadow-md transition-all">
                    {t("احجز هذه الغرفة الآن", "Book This Room Now")}
                    {isRTL ? <ArrowLeft className="w-4 h-4 ms-2" /> : <ArrowRight className="w-4 h-4 ms-2" />}
                  </Button>
                </Link>
              ) : (
                <Button disabled className="w-full bg-gray-400 text-white py-3 rounded-full font-semibold text-base cursor-not-allowed">
                  {t("غير متاحة حالياً", "Not Available")}
                </Button>
              )}

              <p className="text-center text-xs text-gray-400 mt-4">
                {t("إلغاء مجاني خلال 24 ساعة من الحجز", "Free cancellation within 24 hours")}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
