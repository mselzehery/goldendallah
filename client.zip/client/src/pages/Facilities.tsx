import { Star } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";
import { resolveFacilityIcon } from "@/lib/facilityIcons";

const PAGE_HEADER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/spa2_0415bd18.jpg";

const categoryLabels: Record<string, { ar: string; en: string }> = {
  all: { ar: "الكل", en: "All" },
  dining: { ar: "المطاعم", en: "Dining" },
  wellness: { ar: "الصحة والعافية", en: "Wellness" },
  recreation: { ar: "الترفيه", en: "Recreation" },
  business: { ar: "الأعمال", en: "Business" },
  services: { ar: "الخدمات", en: "Services" },
};

export default function Facilities() {
  const { t, lang } = useLang();
  const { data: facilities, isLoading } = trpc.facilities.list.useQuery();

  const grouped = facilities?.reduce(
    (acc, f) => {
      if (!acc[f.category]) acc[f.category] = [];
      acc[f.category].push(f);
      return acc;
    },
    {} as Record<string, typeof facilities>
  );

  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <div className="relative h-64 md:h-80 overflow-hidden">
        <img src={PAGE_HEADER_IMG} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center pt-16">
          <p className="text-amber-300 text-sm tracking-widest uppercase mb-2">{t("استمتع بـ", "Enjoy Our")}</p>
          <h1 className="text-3xl md:text-5xl font-bold" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
            {t("المرافق والخدمات", "Facilities & Services")}
          </h1>
          <div className="flex items-center gap-3 mt-3">
            <div className="h-px w-12 bg-amber-400" />
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <div className="h-px w-12 bg-amber-400" />
          </div>
        </div>
      </div>

      {/* Intro */}
      <section className="py-16 bg-white">
        <div className="container text-center max-w-3xl mx-auto">
          <p className="text-amber-600 text-sm tracking-widest uppercase font-medium mb-3">{t("تجربة متكاملة", "Complete Experience")}</p>
          <h2 className="section-title mb-4">{t("كل ما تحتاجه في مكان واحد", "Everything You Need in One Place")}</h2>
          <div className="flex justify-center items-center gap-4 mb-6">
            <div className="h-px w-16 bg-amber-400" />
            <div className="w-2 h-2 rounded-full bg-[#780000]" />
            <div className="h-px w-16 bg-amber-400" />
          </div>
          <p className="text-gray-500 leading-relaxed">
            {t(
              "يوفر فندق جولدن دلة مجموعة شاملة من المرافق والخدمات الفاخرة لضمان تجربة إقامة لا تُنسى لكل ضيف.",
              "Golden Dalah Hotel offers a comprehensive range of luxury facilities and services to ensure an unforgettable stay for every guest."
            )}
          </p>
        </div>
      </section>

      {/* Facilities by category */}
      <section className="pb-20 bg-[#faf8f5]">
        <div className="container">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
                <div key={i} className="rounded-2xl bg-gray-200 animate-pulse h-48" />
              ))}
            </div>
          ) : grouped ? (
            Object.entries(grouped).map(([category, items]) => (
              <div key={category} className="mb-14">
                <div className="flex items-center gap-4 mb-8">
                  <h3 className="text-2xl font-bold text-[#780000]" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                    {lang === "ar" ? categoryLabels[category]?.ar : categoryLabels[category]?.en}
                  </h3>
                  <div className="flex-1 h-px bg-gradient-to-r from-amber-400 to-transparent" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {items?.map((facility) => {
                    const Icon = resolveFacilityIcon(facility.icon, facility.category) || Star;
                    return (
                      <div key={facility.id} className="luxury-card bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 group">
                        {facility.imageUrl ? (
                          <div className="relative h-40 overflow-hidden">
                            <img
                              src={facility.imageUrl}
                              alt={lang === "ar" ? facility.nameAr : facility.nameEn}
                              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                            <div className="absolute bottom-3 start-3 w-10 h-10 bg-amber-500 rounded-full flex items-center justify-center">
                              <Icon className="w-5 h-5 text-white" />
                            </div>
                          </div>
                        ) : (
                          <div className="h-24 bg-gradient-to-br from-[#780000]/10 to-amber-50 flex items-center justify-center">
                            <div className="w-16 h-16 bg-[#780000] rounded-full flex items-center justify-center">
                              <Icon className="w-8 h-8 text-white" />
                            </div>
                          </div>
                        )}
                        <div className="p-5">
                          <h4 className="font-bold text-[#780000] mb-2" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                            {lang === "ar" ? facility.nameAr : facility.nameEn}
                          </h4>
                          <p className="text-gray-500 text-xs leading-relaxed">
                            {lang === "ar" ? facility.descriptionAr : facility.descriptionEn}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))
          ) : null}
        </div>
      </section>
    </div>
  );
}
