﻿import { useLang } from "@/contexts/LanguageContext";

export default function TermsConditions() {
  const { t, isRTL } = useLang();

  return (
    <div className="bg-[#faf8f5] py-16">
      <div className="container max-w-4xl">
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 md:p-10" dir={isRTL ? "rtl" : "ltr"}>
          <h1 className="text-3xl font-bold text-[#780000] mb-4">{t("الشروط والأحكام", "Terms & Conditions")}</h1>
          <div className="space-y-5 text-gray-700 leading-8">
            <p>{t("استخدام هذا الموقع أو إنشاء حجز يعني الموافقة على شروط الفندق وسياساته التشغيلية.", "Using this website or making a booking means agreeing to the hotel's terms and operating policies.")}</p>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("تأكيد الحجز", "Booking Confirmation")}</h2>
              <p>{t("يتم تأكيد الحجز مباشرة داخل النظام عند اكتمال بيانات الطلب وتوفر الوحدة المطلوبة خلال الفترة المختارة.", "The booking is confirmed directly in the system when the request data is complete and the requested unit is available during the selected period.")}</p>
            </section>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("الأسعار والمدفوعات", "Prices and Payments")}</h2>
              <p>{t("الأسعار المعروضة تخضع للتحديث حسب الإتاحة والسياسة التجارية، وقد يتطلب بعض الحجوزات سدادًا إلكترونيًا لإكمال العملية.", "The displayed prices are subject to updates based on availability and commercial policy, and some bookings may require electronic payment to complete the process.")}</p>
            </section>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("التعديل والإلغاء", "Modification and Cancellation")}</h2>
              <p>{t("التعديل أو الإلغاء يخضعان لسياسة الفندق والحالة الزمنية للحجز وأي التزامات دفع مرتبطة به.", "Modification or cancellation is subject to the hotel's policy, the booking's time status, and any payment obligations associated with it.")}</p>
            </section>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("مسؤولية البيانات", "Data Responsibility")}</h2>
              <p>{t("يتحمل العميل مسؤولية صحة بياناته المدخلة، وخاصة الاسم وبيانات التواصل وتواريخ الوصول والمغادرة.", "The client is responsible for the accuracy of their entered data, especially the name, contact information, and arrival and departure dates.")}</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
