﻿import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { KeyRound, Mail, ShieldCheck, UserRound, Cake, Phone } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function CustomerAccountPortal() {
  const { user, isAuthenticated, loading } = useAuth({ redirectOnUnauthenticated: false });
  const utils = trpc.useUtils();
  const [, navigate] = useLocation();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ 
    name: "", 
    email: "", 
    password: "",
    dateOfBirth: "",
    phone: ""
  });
  const [forgotEmail, setForgotEmail] = useState("");
  const [emailWasSent, setEmailWasSent] = useState(false);

  const customerLogin = trpc.auth.customerLogin.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      toast.success("تم تسجيل الدخول بنجاح");
      navigate("/my-bookings");
    },
    onError: (error) => toast.error(error.message),
  });

  const customerRegister = trpc.auth.customerRegister.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      toast.success("تم إنشاء الحساب بنجاح");
      navigate("/my-bookings");
    },
    onError: (error) => toast.error(error.message),
  });

  const requestPasswordReset = trpc.auth.requestCustomerPasswordReset.useMutation({
    onSuccess: (result) => {
      setEmailWasSent(Boolean(result.emailSent));
      toast.success(result.message);
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (!loading && isAuthenticated && user?.role === "user") {
      navigate("/my-bookings");
    }
  }, [loading, isAuthenticated, navigate, user]);

  if (!loading && isAuthenticated && user?.role === "user") {
    return null;
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center px-4 py-16" dir="rtl">
      <div className="w-full max-w-5xl grid lg:grid-cols-2 gap-8">
        <div className="bg-[#1a0000] text-white rounded-3xl p-10 shadow-2xl">
          <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mb-6">
            <ShieldCheck className="w-8 h-8 text-amber-300" />
          </div>
          <h1 className="text-4xl font-bold mb-4">حساب الضيف</h1>
          <p className="text-white/80 leading-8 mb-8">
            أنشئ حسابك لمتابعة الحجوزات والإشعارات واستعادة كلمة المرور بطريقة آمنة عبر البريد الإلكتروني.
          </p>
          <div className="space-y-4 text-sm text-white/80">
            <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4">متابعة كل حجوزاتك من مكان واحد</div>
            <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4">تنبيهات عند تأكيد الحجز أو تحديث حالته</div>
            <div className="rounded-2xl border border-white/10 bg-white/5 px-4 py-4">استعادة كلمة المرور برابط مؤقت يرسل إلى البريد فقط</div>
          </div>
        </div>

        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
          <div className="flex bg-gray-100 rounded-full p-1 mb-8">
            <button className={`flex-1 rounded-full py-3 text-sm font-semibold transition-colors ${mode === "login" ? "bg-[#780000] text-white" : "text-gray-600"}`} onClick={() => setMode("login")}>تسجيل الدخول</button>
            <button className={`flex-1 rounded-full py-3 text-sm font-semibold transition-colors ${mode === "register" ? "bg-[#780000] text-white" : "text-gray-600"}`} onClick={() => setMode("register")}>إنشاء حساب</button>
          </div>

          {mode === "login" ? (
            <div className="space-y-5">
              <div>
                <Label className="mb-2 block">البريد الإلكتروني</Label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input dir="ltr" className="pe-10" value={loginForm.email} onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })} />
                </div>
              </div>
              <div>
                <Label className="mb-2 block">كلمة المرور</Label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input type="password" className="pe-10" value={loginForm.password} onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })} />
                </div>
              </div>
              <Button className="w-full bg-[#780000] hover:bg-[#600000] text-white rounded-full py-6" disabled={customerLogin.isPending} onClick={() => customerLogin.mutate(loginForm)}>تسجيل الدخول</Button>

              <div className="rounded-2xl bg-[#faf8f5] border border-[#eadfd7] p-4 space-y-3">
                <p className="text-sm font-semibold text-[#780000]">نسيت كلمة المرور؟</p>
                <Input dir="ltr" value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} placeholder="name@example.com" />
                <Button type="button" variant="outline" className="w-full rounded-full" disabled={requestPasswordReset.isPending} onClick={() => requestPasswordReset.mutate({ email: forgotEmail || loginForm.email })}>إرسال رابط الاستعادة</Button>

                <p className="text-xs text-gray-500">
                  {emailWasSent
                    ? "تم إرسال رابط الاستعادة إلى البريد الإلكتروني المرتبط بالحساب."
                    : "سيصل رابط الاستعادة إلى البريد الإلكتروني المرتبط بالحساب عند طلبه."}
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              <div>
                <Label className="mb-2 block">الاسم الكامل</Label>
                <div className="relative">
                  <UserRound className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input className="pe-10" value={registerForm.name} onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })} />
                </div>
              </div>
              <div>
                <Label className="mb-2 block">البريد الإلكتروني</Label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input dir="ltr" className="pe-10" value={registerForm.email} onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })} />
                </div>
              </div>
              <div>
                <Label className="mb-2 block">كلمة المرور</Label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input type="password" className="pe-10" value={registerForm.password} onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })} />
                </div>
              </div>
              <div>
                <Label className="mb-2 block">تاريخ الميلاد</Label>
                <div className="relative">
                  <Cake className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input 
                    type="date" 
                    className="pe-10" 
                    value={registerForm.dateOfBirth} 
                    onChange={(e) => setRegisterForm({ ...registerForm, dateOfBirth: e.target.value })} 
                    max={new Date().toISOString().split('T')[0]}
                  />
                </div>
              </div>
              <div>
                <Label className="mb-2 block">رقم الهاتف (اختياري)</Label>
                <div className="relative">
                  <Phone className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input 
                    type="tel" 
                    className="pe-10" 
                    value={registerForm.phone} 
                    onChange={(e) => setRegisterForm({ ...registerForm, phone: e.target.value })} 
                    placeholder="+966 50 123 4567"
                  />
                </div>
              </div>
              <Button className="w-full bg-[#780000] hover:bg-[#600000] text-white rounded-full py-6" disabled={customerRegister.isPending} onClick={() => customerRegister.mutate(registerForm)}>إنشاء حساب</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
