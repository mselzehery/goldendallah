﻿import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { KeyRound, ShieldCheck } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function ResetCustomerPassword() {
  const [, navigate] = useLocation();
  const search = typeof window !== "undefined" ? window.location.search : "";
  const token = useMemo(() => new URLSearchParams(search).get("token") || "", [search]);
  const [form, setForm] = useState({ newPassword: "", confirmPassword: "" });

  const beginReset = trpc.auth.beginCustomerPasswordReset.useMutation({
    onSuccess: () => {
      window.history.replaceState({}, "", window.location.pathname);
    },
    onError: (error) => toast.error(error.message),
  });

  const resetPassword = trpc.auth.resetCustomerPassword.useMutation({
    onSuccess: () => {
      toast.success("تم تحديث كلمة المرور بنجاح");
      navigate("/account");
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (!token) return;
    beginReset.mutate({ token });
  }, [token]);

  async function handleSubmit() {
    if (token && !beginReset.isSuccess) {
      toast.error("جارٍ تأمين جلسة إعادة تعيين كلمة المرور");
      return;
    }

    if (!token && !beginReset.isSuccess) {
      toast.error("رابط الاستعادة غير صالح");
      return;
    }

    if (form.newPassword !== form.confirmPassword) {
      toast.error("تأكيد كلمة المرور غير مطابق");
      return;
    }

    await resetPassword.mutateAsync({
      newPassword: form.newPassword,
    });
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center px-4 py-16" dir="rtl">
      <div className="w-full max-w-xl bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
        <div className="w-16 h-16 rounded-full bg-[#780000]/10 flex items-center justify-center mb-6 mx-auto">
          <ShieldCheck className="w-8 h-8 text-[#780000]" />
        </div>
        <h1 className="text-3xl font-bold text-center text-[#780000] mb-3">استعادة كلمة المرور</h1>
        <p className="text-center text-gray-500 mb-8">
          أدخل كلمة المرور الجديدة لحسابك. هذا الرابط مؤقت ويُستخدم مرة واحدة فقط.
        </p>

        <div className="space-y-5">
          <div>
            <Label className="mb-2 block">كلمة المرور الجديدة</Label>
            <div className="relative">
              <KeyRound className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input
                type="password"
                className="pe-10"
                value={form.newPassword}
                onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
              />
            </div>
          </div>

          <div>
            <Label className="mb-2 block">تأكيد كلمة المرور</Label>
            <div className="relative">
              <KeyRound className="w-4 h-4 absolute end-4 top-1/2 -translate-y-1/2 text-gray-400" />
              <Input
                type="password"
                className="pe-10"
                value={form.confirmPassword}
                onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
              />
            </div>
          </div>

          <Button
            className="w-full bg-[#780000] hover:bg-[#600000] text-white rounded-full py-6"
            disabled={resetPassword.isPending || beginReset.isPending}
            onClick={() => void handleSubmit()}
          >
            حفظ كلمة المرور الجديدة
          </Button>
        </div>
      </div>
    </div>
  );
}
