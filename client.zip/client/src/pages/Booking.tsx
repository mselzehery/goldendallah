import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Calendar, Users, BedDouble, ArrowRight, ArrowLeft, Check, CreditCard, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { getAmenityLabelsForLang } from "@/lib/roomAmenities";

const PAGE_HEADER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/room-suite_7f006131.jpg";

function getTodayStr() {
  return new Date().toISOString().split("T")[0];
}

function getTomorrowStr() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().split("T")[0];
}

export default function Booking() {
  const { t, lang, isRTL } = useLang();
  const { user } = useAuth({ redirectOnUnauthenticated: false });
  const [, navigate] = useLocation();

  // Parse roomId from URL
  const urlParams = new URLSearchParams(window.location.search);
  const preselectedRoomId = urlParams.get("roomId") ? parseInt(urlParams.get("roomId")!) : undefined;

  const { data: rooms } = trpc.rooms.list.useQuery();
  const { data: paymentMethods } = trpc.payments.methods.useQuery();

  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    roomId: preselectedRoomId || 0,
    checkIn: getTodayStr(),
    checkOut: getTomorrowStr(),
    adults: 1,
    children: 0,
    guestName: "",
    guestEmail: "",
    guestPhone: "",
    guestNationality: "",
    specialRequests: "",
  });

  useEffect(() => {
    if (user?.role !== "user") return;

    setForm((current) => ({
      ...current,
      guestName: current.guestName || user.name || "",
      guestEmail: current.guestEmail || user.email || "",
    }));
  }, [user]);

  const selectedRoom = rooms?.find((r) => r.id === form.roomId);
  const selectedRoomAmenities = selectedRoom ? getAmenityLabelsForLang(selectedRoom.amenities, lang) : [];
  const normalizedGuestName = form.guestName.trim();
  const normalizedGuestEmail = form.guestEmail.trim();
  const nights = form.checkIn && form.checkOut
    ? Math.max(0, Math.ceil((new Date(form.checkOut).getTime() - new Date(form.checkIn).getTime()) / (1000 * 60 * 60 * 24)))
    : 0;
const totalPrice = selectedRoom ? parseFloat(String(selectedRoom.pricePerNight)) * nights : 0;

  const { data: isAvailable, error: availabilityError, isError: hasAvailabilityError } = trpc.bookings.checkAvailability.useQuery(
    { roomId: form.roomId, checkIn: form.checkIn, checkOut: form.checkOut },
    { enabled: !!form.roomId && !!form.checkIn && !!form.checkOut && nights > 0 }
  );

  const createBooking = trpc.bookings.create.useMutation({
    onSuccess: (data) => {
      toast.success(t(`تم إنشاء الحجز بنجاح! رقم الحجز: ${data.bookingRef}`, `Booking created successfully! Ref: ${data.bookingRef}`));
      if (typeof window !== "undefined") {
        window.sessionStorage.setItem(`booking_access_${data.bookingRef}`, data.bookingAccessToken);
      }
      navigate(`/booking/confirmation?ref=${encodeURIComponent(data.bookingRef)}`);
    },
    onError: (err) => {
      toast.error(err.message || t("حدث خطأ في الحجز", "Booking error occurred"));
    },
  });

  const handleSubmit = () => {
    if (normalizedGuestName.length < 2 || !normalizedGuestEmail) {
      toast.error(t("يرجى ملء جميع الحقول المطلوبة", "Please fill all required fields"));
      return;
    }
    createBooking.mutate({
      roomId: form.roomId,
      guestName: normalizedGuestName,
      guestEmail: normalizedGuestEmail,
      guestPhone: form.guestPhone.trim(),
      guestNationality: form.guestNationality.trim(),
      checkIn: new Date(form.checkIn).toISOString(),
      checkOut: new Date(form.checkOut).toISOString(),
      adults: form.adults,
      children: form.children,
      specialRequests: form.specialRequests.trim(),
    });
  };

const typeLabels: Record<string, string> = {
    studio: t("إستديو", "Studio"),
    "junior-suite": t("جناح جونيور", "Junior Suite"),
    "family-suite": t("جناح عائلي", "Family Suite"),
    accessible: t("غرف لذوي الإحتياجات", "Accessible Room"),
  };

  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <div className="relative h-48 md:h-64 overflow-hidden">
        <img src={PAGE_HEADER_IMG} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center pt-16">
          <h1 className="text-3xl md:text-4xl font-bold" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
            {t("احجز إقامتك", "Book Your Stay")}
          </h1>
        </div>
      </div>

      {/* Steps indicator */}
      <div className="bg-white border-b border-gray-100 py-4">
        <div className="container">
          <div className="flex items-center justify-center gap-2">
            {[
              { n: 1, label: t("اختر الغرفة", "Select Room") },
              { n: 2, label: t("التفاصيل", "Details") },
              { n: 3, label: t("التأكيد", "Confirm") },
            ].map(({ n, label }, i) => (
              <div key={n} className="flex items-center gap-2">
                <div className={`flex items-center gap-2 ${step >= n ? "text-[#780000]" : "text-gray-400"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-colors ${
                    step > n ? "bg-[#780000] border-[#780000] text-white" :
                    step === n ? "border-[#780000] text-[#780000]" :
                    "border-gray-300 text-gray-400"
                  }`}>
                    {step > n ? <Check className="w-4 h-4" /> : n}
                  </div>
                  <span className="text-sm font-medium hidden sm:block">{label}</span>
                </div>
                {i < 2 && <div className={`w-12 h-px ${step > n ? "bg-[#780000]" : "bg-gray-200"}`} />}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="py-10 bg-[#faf8f5]">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main form */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 mb-6">
                <div className="flex items-center gap-3 mb-3">
                  <CreditCard className="w-5 h-5 text-[#780000]" />
                  <h2 className="font-bold text-[#780000]">{t("وسائل الدفع المتاحة", "Available Payment Methods")}</h2>
                </div>
                {/* Payment methods temporarily hidden - uncomment when Paymob integration is active
                <div className="flex flex-wrap gap-2">
                  {(paymentMethods?.methods ?? []).map((method) => (
                    <div key={method.key} className="inline-flex items-center gap-2 rounded-full border border-gray-200 bg-gray-50 px-4 py-2 text-sm text-gray-700">
                      {method.category === "wallet" ? <Wallet className="w-4 h-4 text-emerald-600" /> : <CreditCard className="w-4 h-4 text-[#780000]" />}
                      <span>{lang === "ar" ? method.labelAr : method.labelEn}</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-3">
                  {t("التكامل الجاري في المشروع مهيأ لطرق الدفع الشائعة في السعودية مثل مدى وstc pay والبطاقات البنكية.", "The current integration is prepared for common Saudi payment methods such as mada, stc pay, and bank cards.")}
                </p>
                */}
                <p className="text-sm text-gray-500">الدفع عند الوصول متاح حالياً</p>
              </div>

              {/* Step 1: Room & Dates */}
              {step === 1 && (
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                  <h2 className="text-2xl font-bold text-[#780000] mb-6" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                    {t("اختر الغرفة والتواريخ", "Select Room & Dates")}
                  </h2>

                  <div className="space-y-5">
                    <div>
                      <Label className="text-gray-700 mb-1.5 block">{t("الغرفة *", "Room *")}</Label>
                      <Select
                        value={form.roomId ? String(form.roomId) : ""}
                        onValueChange={(v) => setForm({ ...form, roomId: parseInt(v) })}
                      >
                        <SelectTrigger className="border-gray-200">
                          <SelectValue placeholder={t("اختر الغرفة", "Select a room")} />
                        </SelectTrigger>
                        <SelectContent>
                          {rooms?.map((room) => (
                            <SelectItem key={room.id} value={String(room.id)}>
                              {lang === "ar" ? room.nameAr : room.nameEn} — {parseFloat(String(room.pricePerNight)).toLocaleString()} {t("ريال/ليلة", "SAR/night")}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-700 mb-1.5 block flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#780000]" />
                          {t("تاريخ الوصول *", "Check-in *")}
                        </Label>
                        <Input
                          type="date"
                          value={form.checkIn}
                          min={getTodayStr()}
                          onChange={(e) => setForm({ ...form, checkIn: e.target.value })}
                          className="border-gray-200"
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <Label className="text-gray-700 mb-1.5 block flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#780000]" />
                          {t("تاريخ المغادرة *", "Check-out *")}
                        </Label>
                        <Input
                          type="date"
                          value={form.checkOut}
                          min={form.checkIn || getTomorrowStr()}
                          onChange={(e) => setForm({ ...form, checkOut: e.target.value })}
                          className="border-gray-200"
                          dir="ltr"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-700 mb-1.5 block flex items-center gap-2">
                          <Users className="w-4 h-4 text-[#780000]" />
                          {t("البالغون", "Adults")}
                        </Label>
                        <Select value={String(form.adults)} onValueChange={(v) => setForm({ ...form, adults: parseInt(v) })}>
                          <SelectTrigger className="border-gray-200">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[1, 2, 3, 4].map((n) => (
                              <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label className="text-gray-700 mb-1.5 block">{t("الأطفال", "Children")}</Label>
                        <Select value={String(form.children)} onValueChange={(v) => setForm({ ...form, children: parseInt(v) })}>
                          <SelectTrigger className="border-gray-200">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {[0, 1, 2, 3].map((n) => (
                              <SelectItem key={n} value={String(n)}>{n}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {form.roomId > 0 && nights > 0 && (
                      <div className={`p-4 rounded-xl text-sm font-medium ${
                        isAvailable === true ? "bg-green-50 text-green-700 border border-green-200" :
                        isAvailable === false ? "bg-red-50 text-red-700 border border-red-200" :
                        hasAvailabilityError ? "bg-red-50 text-red-700 border border-red-200" :
                        "bg-gray-50 text-gray-500"
                      }`}>
                        {isAvailable === true && `✓ ${t("الغرفة متاحة في هذه التواريخ", "Room is available for these dates")}`}
                        {isAvailable === false && `✗ ${t("الغرفة المختارة غير متاحة في هذه التواريخ", "Selected quantity is not available for these dates")}`}
                        {hasAvailabilityError && (availabilityError?.message || t("تعذر التحقق من التوافر حاليًا", "Could not verify availability right now"))}
                        {isAvailable === undefined && t("جاري التحقق من التوفر...", "Checking availability...")}
                      </div>
                    )}
                  </div>

                  <div className="flex justify-end mt-8">
                    <Button
                      onClick={() => setStep(2)}
                      disabled={!form.roomId || nights < 1 || isAvailable === false || hasAvailabilityError}
                      className="bg-[#780000] hover:bg-[#600000] text-white px-8 rounded-full"
                    >
                      {t("التالي", "Next")}
                      {isRTL ? <ArrowLeft className="w-4 h-4 ms-2" /> : <ArrowRight className="w-4 h-4 ms-2" />}
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 2: Guest Details */}
              {step === 2 && (
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                  <h2 className="text-2xl font-bold text-[#780000] mb-6" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                    {t("بيانات الضيف", "Guest Information")}
                  </h2>
                  <div className="space-y-5">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-700 mb-1.5 block">{t("الاسم الكامل *", "Full Name *")}</Label>
                        <Input
                          value={form.guestName}
                          onChange={(e) => setForm({ ...form, guestName: e.target.value })}
                          placeholder={t("اسمك الكامل", "Your full name")}
                          className="border-gray-200"
                        />
                      </div>
                      <div>
                        <Label className="text-gray-700 mb-1.5 block">{t("البريد الإلكتروني *", "Email *")}</Label>
                        <Input
                          type="email"
                          value={form.guestEmail}
                          onChange={(e) => setForm({ ...form, guestEmail: e.target.value })}
                          placeholder={t("بريدك الإلكتروني", "Your email")}
                          className="border-gray-200"
                          dir="ltr"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-gray-700 mb-1.5 block">{t("رقم الهاتف", "Phone Number")}</Label>
                        <Input
                          value={form.guestPhone}
                          onChange={(e) => setForm({ ...form, guestPhone: e.target.value })}
                          placeholder="+966 5X XXX XXXX"
                          className="border-gray-200"
                          dir="ltr"
                        />
                      </div>
                      <div>
                        <Label className="text-gray-700 mb-1.5 block">{t("الجنسية", "Nationality")}</Label>
                        <Input
                          value={form.guestNationality}
                          onChange={(e) => setForm({ ...form, guestNationality: e.target.value })}
                          placeholder={t("جنسيتك", "Your nationality")}
                          className="border-gray-200"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-gray-700 mb-1.5 block">{t("طلبات خاصة", "Special Requests")}</Label>
                      <Textarea
                        value={form.specialRequests}
                        onChange={(e) => setForm({ ...form, specialRequests: e.target.value })}
                        placeholder={t("أي طلبات خاصة أو ملاحظات...", "Any special requests or notes...")}
                        rows={4}
                        className="border-gray-200 resize-none"
                      />
                    </div>
                  </div>
                  <div className="flex justify-between mt-8">
                    <Button variant="outline" onClick={() => setStep(1)} className="border-gray-300 rounded-full px-6">
                      {isRTL ? <ArrowRight className="w-4 h-4 me-2" /> : <ArrowLeft className="w-4 h-4 me-2" />}
                      {t("السابق", "Back")}
                    </Button>
                    <Button
                      onClick={() => setStep(3)}
                      disabled={normalizedGuestName.length < 2 || !normalizedGuestEmail}
                      className="bg-[#780000] hover:bg-[#600000] text-white px-8 rounded-full"
                    >
                      {t("مراجعة الحجز", "Review Booking")}
                      {isRTL ? <ArrowLeft className="w-4 h-4 ms-2" /> : <ArrowRight className="w-4 h-4 ms-2" />}
                    </Button>
                  </div>
                </div>
              )}

              {/* Step 3: Confirm */}
              {step === 3 && (
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                  <h2 className="text-2xl font-bold text-[#780000] mb-6" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                    {t("مراجعة وتأكيد الحجز", "Review & Confirm Booking")}
                  </h2>
                  <div className="space-y-4 text-sm">
                    <div className="bg-[#faf8f5] rounded-xl p-5">
                      <h3 className="font-semibold text-gray-700 mb-3">{t("تفاصيل الغرفة", "Room Details")}</h3>
                      <div className="grid grid-cols-2 gap-3 text-gray-600">
                        <div><span className="text-gray-400">{t("الغرفة:", "Room:")}</span> <span className="font-medium">{lang === "ar" ? selectedRoom?.nameAr : selectedRoom?.nameEn}</span></div>
                        <div><span className="text-gray-400">{t("النوع:", "Type:")}</span> <span className="font-medium">{typeLabels[selectedRoom?.type || ""]}</span></div>
                        <div><span className="text-gray-400">{t("الوصول:", "Check-in:")}</span> <span className="font-medium" dir="ltr">{form.checkIn}</span></div>
                        <div><span className="text-gray-400">{t("المغادرة:", "Check-out:")}</span> <span className="font-medium" dir="ltr">{form.checkOut}</span></div>
                        <div><span className="text-gray-400">{t("الليالي:", "Nights:")}</span> <span className="font-medium">{nights}</span></div>
                        <div><span className="text-gray-400">{t("الضيوف:", "Guests:")}</span> <span className="font-medium">{form.adults} {t("بالغ", "adults")}{form.children > 0 ? `, ${form.children} ${t("أطفال", "children")}` : ""}</span></div>
                      </div>
                    </div>
                    <div className="bg-[#faf8f5] rounded-xl p-5">
                      <h3 className="font-semibold text-gray-700 mb-3">{t("بيانات الضيف", "Guest Details")}</h3>
                      <div className="grid grid-cols-2 gap-3 text-gray-600">
                        <div><span className="text-gray-400">{t("الاسم:", "Name:")}</span> <span className="font-medium">{form.guestName}</span></div>
                        <div><span className="text-gray-400">{t("البريد:", "Email:")}</span> <span className="font-medium" dir="ltr">{form.guestEmail}</span></div>
                        {form.guestPhone && <div><span className="text-gray-400">{t("الهاتف:", "Phone:")}</span> <span className="font-medium" dir="ltr">{form.guestPhone}</span></div>}
                        {form.guestNationality && <div><span className="text-gray-400">{t("الجنسية:", "Nationality:")}</span> <span className="font-medium">{form.guestNationality}</span></div>}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between mt-8">
                    <Button variant="outline" onClick={() => setStep(2)} className="border-gray-300 rounded-full px-6">
                      {isRTL ? <ArrowRight className="w-4 h-4 me-2" /> : <ArrowLeft className="w-4 h-4 me-2" />}
                      {t("السابق", "Back")}
                    </Button>
                    <Button
                      onClick={handleSubmit}
                      disabled={createBooking.isPending}
                      className="bg-[#780000] hover:bg-[#600000] text-white px-8 rounded-full font-semibold"
                    >
                      {createBooking.isPending ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <>
                          <Check className="w-4 h-4 me-2" />
                          {t("تأكيد الحجز", "Confirm Booking")}
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Summary sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 sticky top-24">
                <h3 className="font-bold text-[#780000] mb-5 text-lg">{t("ملخص الحجز", "Booking Summary")}</h3>
                {selectedRoom ? (
                  <>
                    <div className="relative rounded-xl overflow-hidden h-36 mb-4">
                      <img src={selectedRoom.imageUrl || ""} alt="" className="w-full h-full object-cover" />
                    </div>
                    <h4 className="font-bold text-gray-800 mb-2">{lang === "ar" ? selectedRoom.nameAr : selectedRoom.nameEn}</h4>
                    {selectedRoomAmenities.length > 0 ? (
                      <ul className="mb-4 flex flex-wrap gap-x-3 gap-y-1 text-xs text-gray-600">
                        {selectedRoomAmenities.map((label, i) => (
                          <li key={i} className="flex items-center gap-1">
                            <Check className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                            <span>{label}</span>
                          </li>
                        ))}
                      </ul>
                    ) : null}
                    <div className="space-y-2 text-sm text-gray-600 mb-5">
                      <div className="flex justify-between">
                        <span>{t("سعر الليلة", "Per night")}</span>
                        <span className="font-medium">{parseFloat(String(selectedRoom.pricePerNight)).toLocaleString()} {t("ريال", "SAR")}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>{t("عدد الليالي", "Nights")}</span>
                        <span className="font-medium">{nights}</span>
                      </div>
                      <div className="border-t border-gray-100 pt-2 flex justify-between font-bold text-[#780000] text-base">
                        <span>{t("الإجمالي", "Total")}</span>
                        <span>{totalPrice.toLocaleString()} {t("ريال", "SAR")}</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-gray-400">
                    <BedDouble className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p className="text-sm">{t("اختر غرفة لعرض الملخص", "Select a room to see summary")}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
