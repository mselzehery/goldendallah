// @ts-nocheck
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect, useState } from "react";
import { Loader2 } from "lucide-react";

export default function Login() {
  // 1. تعطيل التوجيه التلقائي لمنع الـ Infinite Loop والـ Crash
  const { user, loading, isAuthenticated } = useAuth({ redirectOnUnauthenticated: false });
  const [, setLocation] = useLocation();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const utils = trpc.useUtils();
  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      window.location.replace("/admin");
    },
    onError: (error) => {
      alert(error.message || "فشل تسجيل الدخول");
      setIsSubmitting(false);
    },
  });

  // 2. التحويل الذكي: لا نتحرك إلا إذا اكتمل التحميل وتأكدنا من الصلاحية
  useEffect(() => {
    if (!loading && isAuthenticated && user?.role === "admin") {
      console.log("✅ المستخدم جاهز، يتم التحويل للوحة التحكم...");
      // تأخير بسيط (نصف ثانية) لضمان استقرار حالة الـ React Hooks
      const timer = setTimeout(() => {
        window.location.replace("/admin");
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [isAuthenticated, user, loading]);

  const handleLogin = async () => {
    const trimmedUsername = username.trim();
    if (!trimmedUsername || !password.trim()) {
      alert("يرجى إدخال مفتاح الإدارة");
      return;
    }

    setIsSubmitting(true);
    // التوجيه لمسار السيرفر لزرع الكوكيز
    await loginMutation.mutateAsync({
      username: trimmedUsername,
      password,
    });
  };

  // حالة التحميل الأولية
  if (loading && !isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-12 h-12 animate-spin text-[#780000]" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-white to-gray-100 px-4 font-sans" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-[#780000] mb-4 shadow-xl">
            <span className="text-amber-400 font-bold text-4xl">G</span>
          </div>
          <h1 className="text-3xl font-bold text-[#780000] mb-2">جولدن دلة</h1>
          <p className="text-gray-500 font-medium">نظام إدارة الفندق الفاخر</p>
        </div>

        <div className="bg-white rounded-3xl shadow-2xl p-8 border border-gray-100 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-[#780000]"></div>
          
          <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center">تسجيل الدخول</h2>
          <p className="text-gray-500 text-center mb-8 text-sm">أدخل مفتاح النظام للوصول للوحة التحكم</p>

          <div className="space-y-5">
            <input
              type="password"
              value={devKey}
              onChange={(e) => setDevKey(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
              placeholder="مفتاح الإدارة (Dev Key)"
              className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-[#780000] outline-none transition-all text-center font-mono"
              disabled={isSubmitting}
            />

            <Button
              onClick={handleLogin}
              disabled={!devKey.trim() || isSubmitting}
              className="w-full bg-[#780000] hover:bg-[#5a0000] text-white py-7 text-lg rounded-2xl font-bold shadow-lg transition-all active:scale-95"
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="animate-spin" />
                  <span>جاري التحقق...</span>
                </div>
              ) : "دخول النظام"}
            </Button>
          </div>

          <div className="my-8 flex items-center gap-3">
            <div className="flex-1 h-px bg-gray-200"></div>
            <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Golden Dallah</span>
            <div className="flex-1 h-px bg-gray-200"></div>
          </div>

          <Button
            variant="ghost"
            onClick={() => (window.location.href = "/")}
            className="w-full py-4 text-gray-500 hover:text-[#780000] hover:bg-red-50 rounded-xl transition-colors"
          >
            العودة للموقع الرئيسي
          </Button>
        </div>
      </div>
    </div>
  );
}
