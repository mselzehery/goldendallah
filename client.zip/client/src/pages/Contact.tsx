import { useState } from "react";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";
import { toast } from "sonner";

const PAGE_HEADER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/exterior_1c33860e.jpg";

export default function Contact() {
  const { t } = useLang();
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });

  const createInquiry = trpc.inquiries.create.useMutation({
    onSuccess: () => {
      toast.success(t("تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.", "Your message has been sent! We'll contact you soon."));
      setForm({ name: "", email: "", phone: "", subject: "", message: "" });
    },
    onError: (err) => {
      toast.error(t("حدث خطأ، يرجى المحاولة مرة أخرى.", "An error occurred, please try again."));
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error(t("يرجى ملء جميع الحقول المطلوبة", "Please fill all required fields"));
      return;
    }
    createInquiry.mutate(form);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: t("العنوان", "Address"),
      value: t("شارع البخاري حي الريان، القصيم، المملكة العربية السعودية", "King Fahd Road, Riyadh, Saudi Arabia"),
    },
    {
      icon: Phone,
      title: t("الهاتف", "Phone"),
      value: "9660163269881+",
    },
    {
      icon: Mail,
      title: t("البريد الإلكتروني", "Email"),
      value: "goldendallah9@gmail.com",
    },
    {
      icon: Clock,
      title: t("ساعات العمل", "Working Hours"),
      value: t("24 ساعة / 7 أيام", "24 Hours / 7 Days"),
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <div className="relative h-64 md:h-80 overflow-hidden">
        <img src={PAGE_HEADER_IMG} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center pt-16">
          <p className="text-amber-300 text-sm tracking-widest uppercase mb-2">{t("نحن هنا لمساعدتك", "We're Here to Help")}</p>
          <h1 className="text-3xl md:text-5xl font-bold" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
            {t("تواصل معنا", "Contact Us")}
          </h1>
          <div className="flex items-center gap-3 mt-3">
            <div className="h-px w-12 bg-amber-400" />
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <div className="h-px w-12 bg-amber-400" />
          </div>
        </div>
      </div>

      {/* Contact info cards */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {contactInfo.map(({ icon: Icon, title, value }) => (
              <div key={title} className="text-center p-6 rounded-2xl bg-[#faf8f5] border border-gray-100 hover:border-amber-200 transition-colors">
                <div className="w-12 h-12 bg-[#780000] rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <h4 className="font-semibold text-[#780000] mb-2 text-sm">{title}</h4>
                <p className="text-gray-600 text-sm">{value}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="section-title mb-2">{t("أرسل لنا رسالة", "Send Us a Message")}</h2>
              <p className="text-gray-500 mb-8 text-sm">
                {t("يسعدنا الرد على استفساراتكم في أقرب وقت ممكن", "We'll be happy to respond to your inquiries as soon as possible")}
              </p>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-700 text-sm mb-1.5 block">{t("الاسم *", "Name *")}</Label>
                    <Input
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder={t("اسمك الكامل", "Your full name")}
                      className="border-gray-200 focus:border-[#780000] focus:ring-[#780000]/20"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-700 text-sm mb-1.5 block">{t("البريد الإلكتروني *", "Email *")}</Label>
                    <Input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder={t("بريدك الإلكتروني", "Your email")}
                      className="border-gray-200 focus:border-[#780000] focus:ring-[#780000]/20"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-gray-700 text-sm mb-1.5 block">{t("رقم الهاتف", "Phone")}</Label>
                    <Input
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder={t("رقم هاتفك", "Your phone number")}
                      className="border-gray-200 focus:border-[#780000] focus:ring-[#780000]/20"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-700 text-sm mb-1.5 block">{t("الموضوع", "Subject")}</Label>
                    <Input
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      placeholder={t("موضوع رسالتك", "Message subject")}
                      className="border-gray-200 focus:border-[#780000] focus:ring-[#780000]/20"
                    />
                  </div>
                </div>
                <div>
                  <Label className="text-gray-700 text-sm mb-1.5 block">{t("الرسالة *", "Message *")}</Label>
                  <Textarea
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder={t("اكتب رسالتك هنا...", "Write your message here...")}
                    rows={5}
                    className="border-gray-200 focus:border-[#780000] focus:ring-[#780000]/20 resize-none"
                  />
                </div>
                <Button
                  type="submit"
                  disabled={createInquiry.isPending}
                  className="w-full bg-[#780000] hover:bg-[#600000] text-white py-3 rounded-full font-semibold flex items-center justify-center gap-2"
                >
                  {createInquiry.isPending ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      {t("إرسال الرسالة", "Send Message")}
                    </>
                  )}
                </Button>
              </form>
            </div>

            {/* Map placeholder */}
            <div className="rounded-2xl overflow-hidden bg-gray-100 min-h-[400px] flex items-center justify-center border border-gray-200">
              <div className="text-center text-gray-400">
                <MapPin className="w-16 h-16 mx-auto mb-4 text-[#780000]/30" />
                <p className="text-lg font-medium text-gray-500">{t("شارع البخاري حي الريان، القصيم", "King Fahd Road, Riyadh")}</p>
                <p className="text-sm text-gray-400">{t("المملكة العربية السعودية", "Saudi Arabia")}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
