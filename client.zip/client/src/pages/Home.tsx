import { useState } from "react";
import { Link } from "wouter";
import {
  Star,
  Wifi,
  Car,
  BedDouble,
  ArrowRight,
  ArrowLeft,
  ChevronDown,
  Award,
  Clock,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";
import { resolveFacilityIcon } from "@/lib/facilityIcons";

const HERO_IMAGES = [
  "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/lobby2_89c4193c.jpg",
];

function HeroSection() {
  const { t, isRTL } = useLang();
  const [currentSlide, setCurrentSlide] = useState(0);
  const { data: hotelSettings } = trpc.hotel.useQuery();

  return (
    <section className="relative h-screen min-h-[600px] overflow-hidden">
      {HERO_IMAGES.map((img, i) => (
        <div
          key={i}
          className="absolute inset-0 transition-opacity duration-1000"
          style={{ opacity: i === currentSlide ? 1 : 0 }}
        >
          <img src={img} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />
        </div>
      ))}

      <div className="relative z-10 h-full flex flex-col items-center justify-center text-center text-white px-4">
        <div className="flex gap-1 mb-6">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
          ))}
        </div>

        <p className="text-amber-300 text-sm tracking-[0.3em] uppercase mb-4 font-medium">
          {t("مرحبا بكم في", "Welcome to")}
        </p>

        <h1
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
          style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}
        >
          {t(hotelSettings?.hotelNameAr || "فندق جولدن دلة", hotelSettings?.hotelNameEn || "Golden Dalah Hotel")}
        </h1>

        <div className="flex items-center gap-4 mb-6">
          <div className="h-px w-16 bg-amber-400" />
          <p className="text-amber-300 text-sm tracking-widest uppercase">
            {t("فخامة بلا حدود", "Unlimited Luxury")}
          </p>
          <div className="h-px w-16 bg-amber-400" />
        </div>

        <p className="text-white/80 text-lg max-w-2xl mb-10 leading-relaxed">
          {t(
            "اكتشف عالما من الفخامة والأناقة حيث تلتقي الأصالة بالحداثة في تجربة إقامة لا تنسى",
            "Discover a world of luxury and elegance where tradition meets modernity in an unforgettable stay"
          )}
        </p>

        <div className="flex flex-col sm:flex-row gap-4">
          <Link href="/booking">
            <Button className="bg-amber-500 hover:bg-amber-400 text-white border-0 px-8 py-3 text-base font-semibold rounded-full shadow-lg shadow-amber-500/30 transition-all duration-300 hover:scale-105">
              {t("احجز غرفتك الآن", "Book Your Room Now")}
              {isRTL ? <ArrowLeft className="w-4 h-4 ms-2" /> : <ArrowRight className="w-4 h-4 ms-2" />}
            </Button>
          </Link>
          <Link href="/rooms">
            <Button
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-[#780000] px-8 py-3 text-base font-semibold rounded-full bg-transparent transition-all duration-300"
            >
              {t("استكشف الغرف", "Explore Rooms")}
            </Button>
          </Link>
        </div>

        <div className="absolute bottom-24 flex gap-2">
          {HERO_IMAGES.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentSlide(i)}
              className={`transition-all duration-300 rounded-full ${
                i === currentSlide ? "w-8 h-2 bg-amber-400" : "w-2 h-2 bg-white/50"
              }`}
            />
          ))}
        </div>

        <div className="absolute bottom-8 animate-bounce">
          <ChevronDown className="w-6 h-6 text-white/70" />
        </div>
      </div>
    </section>
  );
}

function StatsSection() {
  const { t } = useLang();
  const stats = [
    { icon: BedDouble, value: "42+", label: t("غرفة وجناح", "Rooms & Suites") },
    { icon: Users, value: "100K+", label: t("ضيف سعيد", "Happy Guests") },
    { icon: Award, value: "25+", label: t("جائزة فندقية", "Hotel Awards") },
    { icon: Clock, value: "24/7", label: t("خدمة متواصلة", "Service") },
  ];

  return (
    <section className="bg-[#780000] py-12">
      <div className="container">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map(({ icon: Icon, value, label }) => (
            <div key={label} className="text-center text-white">
              <Icon className="w-8 h-8 text-amber-400 mx-auto mb-3" />
              <div className="text-3xl font-bold text-amber-400 mb-1">{value}</div>
              <div className="text-white/80 text-sm">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FeaturedRoomsSection() {
  const { t, lang, isRTL } = useLang();
  const { data: rooms, isLoading } = trpc.rooms.featured.useQuery();

  const typeLabels: Record<string, string> = {
    "junior-suite": t("جناح جونيور", "Junior Suite"),
    studio: t("استديو", "Studio"),
    "family-suite": t("جناح عائلي", "Family Suite"),
    accessible: t("غرفة لذوي الاحتياجات", "Accessible Room"),
  };

  return (
    <section className="py-20 bg-white">
      <div className="container">
        <div className="text-center mb-14">
          <p className="text-amber-600 text-sm tracking-[0.3em] uppercase font-medium mb-3">
            {t("غرفنا الفاخرة", "Our Luxury Rooms")}
          </p>
          <h2 className="section-title mb-4">{t("اختر غرفتك المثالية", "Choose Your Perfect Room")}</h2>
          <div className="flex justify-center items-center gap-4 mb-4">
            <div className="h-px w-16 bg-amber-400" />
            <div className="w-2 h-2 rounded-full bg-[#780000]" />
            <div className="h-px w-16 bg-amber-400" />
          </div>
          <p className="text-gray-500 max-w-xl mx-auto">
            {t(
              "كل غرفة مصممة بعناية فائقة لتوفير أقصى درجات الراحة والفخامة",
              "Each room is carefully designed to provide the utmost comfort and luxury"
            )}
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="rounded-2xl overflow-hidden bg-gray-100 animate-pulse h-96" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {rooms?.map((room) => (
              <div key={room.id} className="luxury-card rounded-2xl overflow-hidden bg-white shadow-md border border-gray-100 group">
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={room.imageUrl || ""}
                    alt={lang === "ar" ? room.nameAr : room.nameEn}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 start-4">
                    <span className="bg-[#780000] text-white text-xs px-3 py-1 rounded-full font-medium">
                      {typeLabels[room.type] || room.type}
                    </span>
                  </div>
                  <div className="absolute bottom-4 end-4 bg-amber-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                    {parseFloat(String(room.pricePerNight)).toLocaleString()} {t("ريال/ليلة", "SAR/night")}
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-[#780000] mb-2" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                    {lang === "ar" ? room.nameAr : room.nameEn}
                  </h3>
                  <p className="text-gray-500 text-sm mb-4 line-clamp-2">
                    {lang === "ar" ? room.descriptionAr : room.descriptionEn}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex gap-3 text-xs text-gray-500">
                      <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5" />{room.capacity}</span>
                      {room.size ? <span>{room.size} {t("م²", "sqm")}</span> : null}
                    </div>
                    <Link href={`/rooms/${room.id}`}>
                      <Button size="sm" className="bg-[#780000] hover:bg-[#600000] text-white rounded-full text-xs px-4">
                        {t("التفاصيل", "Details")}
                        {isRTL ? <ArrowLeft className="w-3 h-3 ms-1" /> : <ArrowRight className="w-3 h-3 ms-1" />}
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="text-center mt-10">
          <Link href="/rooms">
            <Button variant="outline" className="border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white px-8 rounded-full">
              {t("عرض جميع الغرف", "View All Rooms")}
              {isRTL ? <ArrowLeft className="w-4 h-4 ms-2" /> : <ArrowRight className="w-4 h-4 ms-2" />}
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

function FacilitiesSection() {
  const { t, lang } = useLang();
  const { data: facilitiesData } = trpc.facilities.list.useQuery();
  const fallbackFacilities = [
    {
      category: "dining",
      title: t("مطعم لوفت", "Loft Restaurant"),
      desc: t("أشهى المأكولات العربية والعالمية", "Finest Arabic & international cuisine"),
      img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSFLjGdevyiFd7oN3Zdb4Vlpo1KXAau7HxvPINkoxX2h9KUbQnZEukd51b8uuttJQJ0D7g&usqp=CAU",
    },
    {
      category: "wellness",
      title: t("سبا جولدن دلة", "Golden Dalah Spa"),
      desc: t("علاجات ومساجات استرخائية فاخرة", "Luxury treatments and relaxing massages"),
      img: "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/spa2_0415bd18.jpg",
    },
    {
      category: "recreation",
      title: t("حمام السباحة", "Infinity Pool"),
      desc: t("حمام سباحة بإطلالة بانورامية", "Rooftop pool with panoramic views"),
      img: "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/pool_fae24068.jpg",
    },
  ].map((facility) => ({
    ...facility,
    icon: resolveFacilityIcon(undefined, facility.category),
  }));

  const facilities = facilitiesData?.length
    ? facilitiesData.slice(0, 6).map((facility) => ({
        icon: resolveFacilityIcon(facility.icon, facility.category),
        title: lang === "ar" ? facility.nameAr : facility.nameEn,
        desc: lang === "ar"
          ? facility.descriptionAr || facility.descriptionEn || ""
          : facility.descriptionEn || facility.descriptionAr || "",
        img: facility.imageUrl || "",
      }))
    : fallbackFacilities;

  return (
    <section className="py-20 bg-[#faf8f5]">
      <div className="container">
        <div className="text-center mb-14">
          <p className="text-amber-600 text-sm tracking-[0.3em] uppercase font-medium mb-3">
            {t("مرافقنا الحصرية", "Exclusive Facilities")}
          </p>
          <h2 className="section-title mb-4">{t("خدمات لا مثيل لها", "Unparalleled Services")}</h2>
          <div className="flex justify-center items-center gap-4">
            <div className="h-px w-16 bg-amber-400" />
            <div className="w-2 h-2 rounded-full bg-[#780000]" />
            <div className="h-px w-16 bg-amber-400" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
          {facilities.map(({ icon: Icon, title, desc, img }) => (
            <div key={title} className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
              {img ? (
                <div className="relative h-48 overflow-hidden">
                  <img src={img} alt={title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                  <div className="absolute top-4 right-4">
                    <div className="w-12 h-12 rounded-full bg-amber-500 flex items-center justify-center text-white shadow-lg shadow-amber-500/30">
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-[#fbf3e8] p-8 flex items-center justify-center">
                  <div className="w-16 h-16 rounded-full bg-[#780000] flex items-center justify-center text-white shadow-lg shadow-[#780000]/20">
                    <Icon className="w-6 h-6" />
                  </div>
                </div>
              )}
              <div className="p-6 text-center">
                <h3 className="text-xl font-semibold text-[#780000] mb-2" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>{title}</h3>
                <p className="text-gray-500 text-sm leading-relaxed">{desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link href="/facilities">
            <Button variant="outline" className="border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white px-8 rounded-full">
              {t("استكشف جميع المرافق", "Explore All Facilities")}
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

function AmenitiesSection() {
  const { t } = useLang();
  const amenities = [
    { icon: Wifi, label: t("واي فاي مجاني", "Free WiFi") },
    { icon: Car, label: t("موقف مجاني", "Free Parking") },
    // { icon: UtensilsCrossed, label: t("إفطار مجاني", "Free Breakfast") },
    { icon: Clock, label: t("خدمة 24 ساعة", "24h Service") },
  ];

  return (
    <section className="py-16 bg-white border-y border-gray-100">
      <div className="container">
        <div className="flex flex-wrap items-start justify-between gap-y-10 md:justify-around max-w-5xl mx-auto">
          {amenities.map(({ icon: Icon, label }) => (
            <div key={label} className="flex flex-col items-center gap-3 text-center group">
              <div className="w-14 h-14 rounded-full bg-[#780000]/5 group-hover:bg-[#780000] flex items-center justify-center transition-colors duration-300">
                <Icon className="w-6 h-6 text-[#780000] group-hover:text-white transition-colors duration-300" />
              </div>
              <span className="text-xs text-gray-600 font-medium">{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialsSection() {
  const { t, lang } = useLang();
  const { data: reviews } = trpc.reviews.list.useQuery();

  const testimonials = reviews?.length
    ? reviews.map((review) => ({
        id: review.id,
        name: review.guestName,
        role: lang === "ar"
          ? review.guestRoleAr || review.guestRoleEn || t("ضيف الفندق", "Hotel Guest")
          : review.guestRoleEn || review.guestRoleAr || t("ضيف الفندق", "Hotel Guest"),
        text: lang === "ar"
          ? review.reviewTextAr || review.reviewTextEn || ""
          : review.reviewTextEn || review.reviewTextAr || "",
        rating: review.rating ?? 5,
        avatarImageUrl: review.avatarImageUrl || "",
      }))
    : [
        {
          id: "fallback-1",
          name: t("عبدالله الشمري", "Abdullah Al-Shamri"),
          role: t("عائلة", "Family"),
          text: t("نشكر إدارة الفندق على حسن الضيافة والنظافة الراقية.", "Excellent hospitality and a very clean hotel."),
          rating: 5,
          avatarImageUrl: "",
        },
        {
          id: "fallback-2",
          name: t("أبو عبدالله", "Abo Abdullah"),
          role: t("زائر دائم", "Traveler"),
          text: t("الاستقبال رائع والتعامل محترم للغاية.", "The reception was wonderful and the staff were very respectful."),
          rating: 5,
          avatarImageUrl: "",
        },
        {
          id: "fallback-3",
          name: t("ياسين إسماعيل", "Yasin Ismaiel"),
          role: t("عائلة", "Family"),
          text: t("المكان مرتب ونظيف جدًا والتجربة كانت ممتازة.", "The place is tidy, very clean, and the overall experience was excellent."),
          rating: 5,
          avatarImageUrl: "",
        },
      ];

  return (
    <section className="py-20 bg-maroon-gradient">
      <div className="container">
        <div className="text-center mb-14">
          <p className="text-amber-300 text-sm tracking-[0.3em] uppercase font-medium mb-3">
            {t("آراء ضيوفنا", "Guest Reviews")}
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
            {t("ماذا يقول ضيوفنا", "What Our Guests Say")}
          </h2>
          <div className="flex justify-center items-center gap-4">
            <div className="h-px w-16 bg-amber-400/50" />
            <div className="w-2 h-2 rounded-full bg-amber-400" />
            <div className="h-px w-16 bg-amber-400/50" />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
          {testimonials.map(({ id, name, role, text, rating, avatarImageUrl }) => (
            <div key={id} className="bg-white/10 backdrop-blur-sm rounded-2xl p-7 border border-white/20 hover:bg-white/15 transition-colors">
              <div className="flex gap-1 mb-4">
                {[...Array(rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="text-white/90 text-sm leading-relaxed mb-6 italic">"{text}"</p>
              <div className="flex items-center gap-3">
                {avatarImageUrl ? (
                  <img src={avatarImageUrl} alt={name} className="w-10 h-10 rounded-full object-cover border border-white/20" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center text-white font-bold">
                    {name.charAt(0)}
                  </div>
                )}
                <div>
                  <div className="text-white font-semibold text-sm">{name}</div>
                  <div className="text-amber-300 text-xs">{role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  const { t, isRTL } = useLang();

  return (
    <section className="py-20 bg-white">
      <div className="container">
        <div className="relative rounded-3xl overflow-hidden" style={{ background: "linear-gradient(135deg, #780000 0%, #a00000 100%)" }}>
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-amber-400 -translate-y-1/2 translate-x-1/2" />
            <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-amber-400 translate-y-1/2 -translate-x-1/2" />
          </div>
          <div className="relative z-10 text-center py-16 px-8">
            <p className="text-amber-300 text-sm tracking-widest uppercase mb-4">{t("عرض خاص", "Special Offer")}</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
              {t("احجز الآن واستمتع بإقامة استثنائية", "Book Now and Enjoy an Exceptional Stay")}
            </h2>
            <p className="text-white/80 mb-8 max-w-lg mx-auto">
              {t(
                "احجز إقامتك في فندق جولدن دلة الآن واستمتع بعروض حصرية وخدمة راقية",
                "Book your stay at Golden Dalah Hotel now and enjoy exclusive offers with premium service"
              )}
            </p>
            <Link href="/booking">
              <Button className="bg-amber-500 hover:bg-amber-400 text-white border-0 px-10 py-3 text-base font-semibold rounded-full shadow-lg shadow-black/20 transition-all duration-300 hover:scale-105">
                {t("احجز الآن", "Book Now")}
                {isRTL ? <ArrowLeft className="w-4 h-4 ms-2" /> : <ArrowRight className="w-4 h-4 ms-2" />}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

export default function Home() {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <StatsSection />
      <FeaturedRoomsSection />
      <AmenitiesSection />
      <FacilitiesSection />
      <TestimonialsSection />
      <CTASection />
    </div>
  );
}
