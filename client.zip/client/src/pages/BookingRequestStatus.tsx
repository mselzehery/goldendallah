import { Link } from "wouter";
import { CheckCircle, Home, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";
import BookingPaymentCard from "@/components/BookingPaymentCard";
import { useEffect, useMemo } from "react";

export default function BookingRequestStatus() {
  const { t, lang } = useLang();
  const search = typeof window !== "undefined" ? window.location.search : "";
  const { ref, accessToken } = useMemo(() => {
    const params = new URLSearchParams(search);
    const ref = params.get("ref") || "";
    const urlAccessToken = params.get("access") || undefined;
    const storedAccessToken =
      typeof window !== "undefined" && ref
        ? window.sessionStorage.getItem(`booking_access_${ref}`) || undefined
        : undefined;

    return {
      ref,
      accessToken: urlAccessToken ?? storedAccessToken,
    };
  }, [search]);

  const storeAccessToken = trpc.bookings.storeAccessToken.useMutation();

  useEffect(() => {
    if (!ref || !accessToken) return;

    storeAccessToken.mutate({ ref, accessToken });

    const params = new URLSearchParams(window.location.search);
    params.delete("access");
    const nextQuery = params.toString();
    window.sessionStorage.removeItem(`booking_access_${ref}`);
    window.history.replaceState({}, "", `${window.location.pathname}${nextQuery ? `?${nextQuery}` : ""}`);
  }, [accessToken, ref]);

  const { data: booking } = trpc.bookings.getByRef.useQuery(
    { ref },
    { enabled: !!ref && (!accessToken || storeAccessToken.isSuccess) }
  );

  const statusLabel = booking?.status === "confirmed"
    ? t("مؤكد", "Confirmed")
    : booking?.status === "cancelled"
      ? t("ملغي", "Cancelled")
      : booking?.status === "completed"
        ? t("مكتمل", "Completed")
        : t("قيد المراجعة", "Confirmed");

  return (
    <div className="min-h-screen bg-[#faf8f5] flex items-center justify-center pt-20 pb-16">
      <div className="container max-w-2xl">
        <div className="bg-white rounded-3xl shadow-lg border border-gray-100 p-10 text-center">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>

          <h1
            className="text-3xl font-bold text-[#780000] mb-3"
            style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}
          >
            {t("تم استلام طلب حجزك", "Booking Confirmed")}
          </h1>

          <p className="text-gray-500 mb-8">
            {t(
              "شكرًا لاختيارك فندق جولدن دلة. تم استلام طلب الحجز وحالته الآن قيد المراجعة، وسيتم التواصل معك لتأكيده قريبًا.",
              "Your booking has been confirmed immediately. Booking details will be shared with you through the available contact channels."
            )}
          </p>

          <div className="bg-[#780000]/5 border border-[#780000]/20 rounded-2xl p-6 mb-8">
            <p className="text-sm text-gray-500 mb-2">{t("رقم الحجز", "Booking Reference")}</p>
            <p className="text-3xl font-bold text-[#780000] tracking-widest" dir="ltr">{ref}</p>
          </div>

          {booking ? (
            <div className="bg-gray-50 rounded-2xl p-6 mb-8 text-start">
              <h3 className="font-semibold text-gray-700 mb-4">{t("تفاصيل الحجز", "Booking Details")}</h3>
              <div className="grid grid-cols-2 gap-3 text-sm text-gray-600">
                <div>
                  <span className="text-gray-400 block">{t("الاسم", "Name")}</span>
                  <span className="font-medium">{booking.guestName}</span>
                </div>
                <div>
                  <span className="text-gray-400 block">{t("البريد", "Email")}</span>
                  <span className="font-medium" dir="ltr">{booking.guestEmail}</span>
                </div>
                <div>
                  <span className="text-gray-400 block">{t("تاريخ الوصول", "Check-in")}</span>
                  <span className="font-medium" dir="ltr">
                    {new Date(booking.checkIn).toLocaleDateString(lang === "ar" ? "ar-SA" : "en-US")}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block">{t("تاريخ المغادرة", "Check-out")}</span>
                  <span className="font-medium" dir="ltr">
                    {new Date(booking.checkOut).toLocaleDateString(lang === "ar" ? "ar-SA" : "en-US")}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block">{t("الإجمالي", "Total")}</span>
                  <span className="font-bold text-[#780000]">
                    {parseFloat(String(booking.totalPrice)).toLocaleString()} {t("ريال", "SAR")}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block">{t("الحالة", "Status")}</span>
                  <span className="font-medium text-amber-600">{statusLabel}</span>
                </div>
              </div>
            </div>
          ) : null}

          {ref ? (
            <BookingPaymentCard
              refCode={ref}
            />
          ) : null}

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button className="bg-[#780000] hover:bg-[#600000] text-white rounded-full px-8 flex items-center gap-2">
                <Home className="w-4 h-4" />
                {t("العودة للرئيسية", "Back to Home")}
              </Button>
            </Link>
            <Link href="/booking">
              <Button variant="outline" className="border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white rounded-full px-8 flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                {t("حجز جديد", "New Booking")}
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
