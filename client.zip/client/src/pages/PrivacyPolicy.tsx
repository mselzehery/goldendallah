﻿import { useLang } from "@/contexts/LanguageContext";

export default function PrivacyPolicy() {
  const { t, isRTL } = useLang();

  return (
    <div className="bg-[#faf8f5] py-16">
      <div className="container max-w-4xl">
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-8 md:p-10" dir={isRTL ? "rtl" : "ltr"}>
          <h1 className="text-3xl font-bold text-[#780000] mb-4">{t("سياسة الخصوصية", "Privacy Policy")}</h1>
          <p className="text-gray-600 leading-8 mb-6">
            {t(
              "نلتزم في فندق جولدن دلة بحماية بيانات النزلاء والزوار واستخدامها فقط لتقديم خدمات الحجز، التواصل، الدعم، وتحسين التجربة داخل الموقع.",
              "At Golden Dalah Hotel, we are committed to protecting the data of our guests and visitors, using it only to provide booking services, communication, support, and improve the experience on the site."
            )}
          </p>
          <div className="space-y-5 text-gray-700 leading-8">
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("البيانات التي نجمعها", "Data We Collect")}</h2>
              <p>{t("نجمع بيانات الحجز الأساسية مثل الاسم، البريد الإلكتروني، رقم الهاتف، بيانات الإقامة، وبيانات الدفع المرتبطة بعملية الحجز.", "We collect basic booking data such as name, email, phone number, stay information, and payment data related to the booking process.")}</p>
            </section>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("كيف نستخدم البيانات", "How We Use Data")}</h2>
              <p>{t("نستخدم البيانات لتأكيد الحجوزات، إرسال الإشعارات، متابعة الطلبات، إدارة الفواتير والمدفوعات، والامتثال للمتطلبات التشغيلية والتنظيمية.", "We use the data to confirm bookings, send notifications, follow up on requests, manage invoices and payments, and comply with operational and regulatory requirements.")}</p>
            </section>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("حماية البيانات", "Data Protection")}</h2>
              <p>{t("نطبق ضوابط وصول داخلية وربطًا آمنًا لصفحات الحجز، ولا نعرض روابط أو رموز حساسة للعميل في بيئات الإنتاج.", "We apply internal access controls and secure connections for booking pages, and do not expose sensitive links or codes to the client in production environments.")}</p>
            </section>
            <section>
              <h2 className="font-bold text-[#780000] mb-2">{t("مشاركة البيانات", "Data Sharing")}</h2>
              <p>{t("قد تتم مشاركة الحد الأدنى اللازم من البيانات مع مزودي الدفع أو التنبيهات أو البريد الإلكتروني بما يخدم تنفيذ الخدمة فقط.", "The minimum necessary data may be shared with payment providers, notifications, or email services only to serve the execution of the service.")}</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}
