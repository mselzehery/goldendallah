import { useState } from "react";
import { Link } from "wouter";
import { LayoutDashboard, BedDouble, CalendarCheck, MessageSquare, LogOut, Menu, Check, X, Clock, Eye, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";

function AdminNav({ active }: { active: string }) {
  const [open, setOpen] = useState(false);
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/settings", icon: Settings, label: "الإعدادات" },
  ];
  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center">
              <span className="text-amber-400 font-bold text-lg">G</span>
            </div>
            <div>
              <div className="font-bold text-white text-sm">جولدن دلة</div>
              <div className="text-amber-400 text-xs">لوحة الإدارة</div>
            </div>
          </div>
        </div>
        <nav className="p-4">
          {navItems.map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}>
              <div onClick={() => setOpen(false)} className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
                <Icon className="w-5 h-5" /><span className="text-sm font-medium">{label}</span>
              </div>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-white/10 absolute bottom-0 w-full">
          <Link href="/"><div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1"><LayoutDashboard className="w-5 h-5" /><span className="text-sm">عرض الموقع</span></div></Link>
          <button onClick={() => logout()} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors"><LogOut className="w-5 h-5" /><span className="text-sm">تسجيل الخروج</span></button>
        </div>
      </aside>
      <button onClick={() => setOpen(true)} className="fixed top-4 start-4 z-30 lg:hidden p-2 bg-[#780000] text-white rounded-lg shadow-lg"><Menu className="w-5 h-5" /></button>
    </>
  );
}

export default function AdminBookings() {
  const { user, isAuthenticated, loading } = useAuth();
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const utils = trpc.useUtils();

  const { data: bookings, isLoading } = trpc.bookings.listAdmin.useQuery();

  const updateStatus = trpc.bookings.updateStatus.useMutation({
    onSuccess: () => {
      utils.bookings.listAdmin.invalidate();
      toast.success("تم تحديث حالة الحجز");
    },
    onError: () => toast.error("حدث خطأ في التحديث"),
  });

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" /></div>;
  if (!isAuthenticated || user?.role !== "admin") return <div className="min-h-screen flex items-center justify-center"><p>غير مصرح</p></div>;

  const filtered = statusFilter === "all" ? bookings : bookings?.filter((b) => b.status === statusFilter);

  const statusColors: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    confirmed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    completed: "bg-blue-100 text-blue-700",
  };
  const statusLabels: Record<string, string> = {
    pending: "قيد الانتظار",
    confirmed: "مؤكد",
    cancelled: "ملغي",
    completed: "مكتمل",
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/bookings" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 flex items-center gap-4 sticky top-0 z-30">
          <div className="w-8 lg:hidden" />
          <h1 className="text-xl font-bold text-[#780000]">إدارة الحجوزات</h1>
        </header>
        <div className="p-6">
          {/* Filters */}
          <div className="flex items-center gap-3 mb-6">
            {["all", "pending", "confirmed", "cancelled", "completed"].map((s) => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${statusFilter === s ? "bg-[#780000] text-white" : "bg-white text-gray-600 border border-gray-200 hover:border-[#780000]"}`}
              >
                {s === "all" ? "الكل" : statusLabels[s]}
                {s !== "all" && <span className="ms-1 text-xs">({bookings?.filter((b) => b.status === s).length ?? 0})</span>}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">رقم الحجز</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الضيف</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">البريد</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الوصول</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">المغادرة</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الليالي</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">المبلغ</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الحالة</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr><td colSpan={9} className="px-5 py-10 text-center"><div className="w-8 h-8 border-2 border-[#780000] border-t-transparent rounded-full animate-spin mx-auto" /></td></tr>
                  ) : filtered && filtered.length > 0 ? (
                    filtered.map((b) => (
                      <tr key={b.id} className="border-t border-gray-50 hover:bg-gray-50 transition-colors">
                        <td className="px-5 py-3 font-mono text-[#780000] font-medium text-xs" dir="ltr">{b.bookingRef}</td>
                        <td className="px-5 py-3 font-medium">{b.guestName}</td>
                        <td className="px-5 py-3 text-gray-500 text-xs" dir="ltr">{b.guestEmail}</td>
                        <td className="px-5 py-3 text-gray-500" dir="ltr">{new Date(b.checkIn).toLocaleDateString("ar-SA")}</td>
                        <td className="px-5 py-3 text-gray-500" dir="ltr">{new Date(b.checkOut).toLocaleDateString("ar-SA")}</td>
                        <td className="px-5 py-3 text-center">{b.totalNights}</td>
                        <td className="px-5 py-3 font-medium">{parseFloat(String(b.totalPrice)).toLocaleString()}</td>
                        <td className="px-5 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[b.status]}`}>{statusLabels[b.status]}</span>
                        </td>
                        <td className="px-5 py-3">
                          <div className="flex gap-1">
                            {b.status === "pending" && (
                              <>
                                <button
                                  onClick={() => updateStatus.mutate({ id: b.id, status: "confirmed" })}
                                  className="w-7 h-7 bg-green-100 hover:bg-green-200 text-green-700 rounded-full flex items-center justify-center transition-colors"
                                  title="تأكيد"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => updateStatus.mutate({ id: b.id, status: "cancelled" })}
                                  className="w-7 h-7 bg-red-100 hover:bg-red-200 text-red-700 rounded-full flex items-center justify-center transition-colors"
                                  title="إلغاء"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                            {b.status === "confirmed" && (
                              <button
                                onClick={() => updateStatus.mutate({ id: b.id, status: "completed" })}
                                className="w-7 h-7 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-full flex items-center justify-center transition-colors"
                                title="مكتمل"
                              >
                                <Clock className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr><td colSpan={9} className="px-5 py-10 text-center text-gray-400">لا توجد حجوزات</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
