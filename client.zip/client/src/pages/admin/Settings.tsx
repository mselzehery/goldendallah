import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { BedDouble, CalendarCheck, LayoutDashboard, LogOut, MessageSquare, Settings as SettingsIcon, Shield, Bell, Hotel, KeyRound, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

function AdminNav({ active }: { active: string }) {
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/settings", icon: SettingsIcon, label: "الإعدادات" },
  ];

  return (
    <aside className="fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 hidden lg:flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center">
            <span className="text-amber-400 font-bold text-lg">G</span>
          </div>
          <div>
            <div className="font-bold text-white text-sm">جولدن دلة</div>
            <div className="text-amber-400 text-xs">لوحة الإدارة</div>
          </div>
        </div>
      </div>
      <nav className="p-4 flex-1">
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link key={href} href={href}>
            <div className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{label}</span>
            </div>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-white/10">
        <Link href="/">
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1">
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-sm">عرض الموقع</span>
          </div>
        </Link>
        <button onClick={() => logout()} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors">
          <LogOut className="w-5 h-5" />
          <span className="text-sm">تسجيل الخروج</span>
        </button>
      </div>
    </aside>
  );
}

const emptyAdminForm = {
  name: "",
  username: "",
  email: "",
  password: "",
};

export default function AdminSettings() {
  const { user, isAuthenticated, loading } = useAuth();
  const utils = trpc.useUtils();
  const isOwner = user?.openId === "Sc7yEPXmrhBAQxyLG5ck6Z";
  const [adminDialogOpen, setAdminDialogOpen] = useState(false);
  const [editingAdminId, setEditingAdminId] = useState<number | null>(null);
  const [adminForm, setAdminForm] = useState(emptyAdminForm);
  const [hotelForm, setHotelForm] = useState({
    hotelNameAr: "",
    hotelNameEn: "",
    supportEmail: "",
    supportPhone: "",
    whatsappNumber: "",
    addressAr: "",
    addressEn: "",
    checkInTime: "14:00",
    checkOutTime: "12:00",
    notificationEmail: "",
    notificationWhatsapp: "",
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const { data: adminUsers } = trpc.admin.users.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: hotelSettings } = trpc.hotel.useQuery();
  const { data: activityLogs } = trpc.admin.activity.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: alerts } = trpc.admin.alerts.useQuery(undefined, { enabled: !!isAuthenticated });

  const createAdmin = trpc.admin.createUser.useMutation({
    onSuccess: async () => {
      await utils.admin.users.invalidate();
      toast.success("تمت إضافة الأدمن");
      setAdminDialogOpen(false);
      setAdminForm(emptyAdminForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const updateAdmin = trpc.admin.updateUser.useMutation({
    onSuccess: async () => {
      await utils.admin.users.invalidate();
      toast.success("تم تحديث بيانات الأدمن");
      setAdminDialogOpen(false);
      setAdminForm(emptyAdminForm);
      setEditingAdminId(null);
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteAdmin = trpc.admin.deleteUser.useMutation({
    onSuccess: async () => {
      await utils.admin.users.invalidate();
      toast.success("تم حذف الأدمن");
    },
    onError: (error) => toast.error(error.message),
  });

  const resetAdminPassword = trpc.admin.resetPassword.useMutation({
    onSuccess: async () => {
      toast.success("تم تحديث كلمة المرور");
      setAdminDialogOpen(false);
      setAdminForm(emptyAdminForm);
      setEditingAdminId(null);
      await utils.admin.users.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateHotel = trpc.admin.updateHotel.useMutation({
    onSuccess: async () => {
      await utils.hotel.invalidate();
      toast.success("تم حفظ بيانات الفندق");
    },
    onError: (error) => toast.error(error.message),
  });

  const changeMyPassword = trpc.auth.changePassword.useMutation({
    onSuccess: () => {
      toast.success("تم تغيير كلمة المرور");
      setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (hotelSettings) {
      setHotelForm({
        hotelNameAr: hotelSettings.hotelNameAr ?? "",
        hotelNameEn: hotelSettings.hotelNameEn ?? "",
        supportEmail: hotelSettings.supportEmail ?? "",
        supportPhone: hotelSettings.supportPhone ?? "",
        whatsappNumber: hotelSettings.whatsappNumber ?? "",
        addressAr: hotelSettings.addressAr ?? "",
        addressEn: hotelSettings.addressEn ?? "",
        checkInTime: hotelSettings.checkInTime ?? "14:00",
        checkOutTime: hotelSettings.checkOutTime ?? "12:00",
        notificationEmail: hotelSettings.notificationEmail ?? "",
        notificationWhatsapp: hotelSettings.notificationWhatsapp ?? "",
      });
    }
  }, [hotelSettings]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" /></div>;
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return <div className="min-h-screen flex items-center justify-center"><p>غير مصرح</p></div>;
  }

  const openCreateAdmin = () => {
    if (!isOwner) {
      toast.error("إضافة الأدمنات متاحة للحساب الرئيسي فقط");
      return;
    }
    setEditingAdminId(null);
    setAdminForm(emptyAdminForm);
    setAdminDialogOpen(true);
  };

  const openEditAdmin = (admin: any) => {
    if (!isOwner) {
      toast.error("تعديل بيانات الأدمنات متاح للحساب الرئيسي فقط");
      return;
    }
    setEditingAdminId(admin.id);
    setAdminForm({
      name: admin.name ?? "",
      username: admin.username ?? "",
      email: admin.email ?? "",
      password: "",
    });
    setAdminDialogOpen(true);
  };

  const handleSaveAdmin = async () => {
    if (!adminForm.name || !adminForm.username) {
      toast.error("أكمل بيانات الأدمن");
      return;
    }

    if (editingAdminId) {
      await updateAdmin.mutateAsync({
        id: editingAdminId,
        name: adminForm.name,
        username: adminForm.username,
        email: adminForm.email,
        isActive: adminUsers?.find((item) => item.id === editingAdminId)?.isActive ?? true,
      });

      if (adminForm.password.trim()) {
        await resetAdminPassword.mutateAsync({
          id: editingAdminId,
          newPassword: adminForm.password,
        });
      }
      return;
    }

    if (adminForm.password.trim().length < 8) {
      toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }

    await createAdmin.mutateAsync(adminForm);
  };

  const toggleAdminStatus = async (admin: any) => {
    if (!isOwner) {
      toast.error("إيقاف أو تفعيل الأدمنات متاح للحساب الرئيسي فقط");
      return;
    }
    await updateAdmin.mutateAsync({
      id: admin.id,
      name: admin.name ?? "",
      username: admin.username ?? "",
      email: admin.email ?? "",
      isActive: !admin.isActive,
    });
  };

  const handleDeleteAdmin = async (admin: any) => {
    if (!isOwner) {
      toast.error("حذف الأدمنات متاح للحساب الرئيسي فقط");
      return;
    }

    if (!confirm(`هل تريد حذف حساب ${admin.name || admin.username} نهائيًا؟`)) {
      return;
    }

    await deleteAdmin.mutateAsync({ id: admin.id });
  };

  const handleSaveHotel = async () => {
    await updateHotel.mutateAsync(hotelForm);
  };

  const handleChangeMyPassword = async () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("تأكيد كلمة المرور غير مطابق");
      return;
    }

    await changeMyPassword.mutateAsync({
      currentPassword: passwordForm.currentPassword,
      newPassword: passwordForm.newPassword,
    });
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/settings" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-30">
          <h1 className="text-xl font-bold text-[#780000]">إعدادات الإدارة والفندق</h1>
        </header>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Bell className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">تنبيهات الحجوزات</h2>
              </div>
              <div className="space-y-2 text-sm text-gray-600">
                <p>حجوزات قيد الانتظار: <strong>{alerts?.pendingBookings.length ?? 0}</strong></p>
                <p>وصول اليوم: <strong>{alerts?.arrivalsToday.length ?? 0}</strong></p>
                <p>وصول الغد: <strong>{alerts?.arrivalsTomorrow.length ?? 0}</strong></p>
                <p>استفسارات جديدة: <strong>{alerts?.unreadInquiries.length ?? 0}</strong></p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">الأدمنات النشطون</h2>
              </div>
              <p className="text-3xl font-bold text-[#780000]">{adminUsers?.filter((item) => item.isActive).length ?? 0}</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Hotel className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">اسم الفندق</h2>
              </div>
              <p className="text-sm text-gray-600">{hotelForm.hotelNameAr || "جولدن دلة"}</p>
              <p className="text-xs text-gray-400 mt-1">{hotelForm.hotelNameEn || "Golden Dallah"}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-[#780000]" />
                  <h2 className="font-bold text-gray-800">إدارة الأدمنات</h2>
                </div>
                <Button onClick={openCreateAdmin} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">إضافة أدمن</Button>
              </div>

              <div className="space-y-3">
                {(adminUsers ?? []).map((admin) => (
                  <div key={admin.id} className="rounded-2xl border border-gray-100 p-4 flex items-center justify-between gap-4">
                    <div>
                      <p className="font-semibold text-gray-800">{admin.name}</p>
                      <p className="text-sm text-gray-500">@{admin.username}</p>
                      <p className="text-xs text-gray-400">{admin.email || "بدون بريد"}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${admin.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {admin.isActive ? "نشط" : "موقوف"}
                      </div>
                      <Button variant="outline" className="rounded-full" onClick={() => openEditAdmin(admin)}>تعديل</Button>
                      <div className="flex items-center gap-2">
                        <Switch checked={admin.isActive} onCheckedChange={() => void toggleAdminStatus(admin)} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-5">
                <KeyRound className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">تغيير كلمة مروري</h2>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="mb-1.5 block">كلمة المرور الحالية</Label>
                  <Input type="password" value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })} />
                </div>
                <div>
                  <Label className="mb-1.5 block">كلمة المرور الجديدة</Label>
                  <Input type="password" value={passwordForm.newPassword} onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })} />
                </div>
                <div>
                  <Label className="mb-1.5 block">تأكيد كلمة المرور</Label>
                  <Input type="password" value={passwordForm.confirmPassword} onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })} />
                </div>
                <Button onClick={() => void handleChangeMyPassword()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">حفظ كلمة المرور</Button>
              </div>
            </section>
          </div>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-5">
              <Hotel className="w-5 h-5 text-[#780000]" />
              <h2 className="font-bold text-gray-800">تفاصيل الفندق</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label className="mb-1.5 block">اسم الفندق بالعربية</Label><Input value={hotelForm.hotelNameAr} onChange={(e) => setHotelForm({ ...hotelForm, hotelNameAr: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">اسم الفندق بالإنجليزية</Label><Input value={hotelForm.hotelNameEn} onChange={(e) => setHotelForm({ ...hotelForm, hotelNameEn: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">إيميل الدعم</Label><Input value={hotelForm.supportEmail} onChange={(e) => setHotelForm({ ...hotelForm, supportEmail: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">رقم الدعم</Label><Input value={hotelForm.supportPhone} onChange={(e) => setHotelForm({ ...hotelForm, supportPhone: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">واتساب الفندق</Label><Input value={hotelForm.whatsappNumber} onChange={(e) => setHotelForm({ ...hotelForm, whatsappNumber: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">إيميل تنبيهات الحجوزات</Label><Input value={hotelForm.notificationEmail} onChange={(e) => setHotelForm({ ...hotelForm, notificationEmail: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">واتساب تنبيهات الحجوزات</Label><Input value={hotelForm.notificationWhatsapp} onChange={(e) => setHotelForm({ ...hotelForm, notificationWhatsapp: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label className="mb-1.5 block">وقت الدخول</Label><Input value={hotelForm.checkInTime} onChange={(e) => setHotelForm({ ...hotelForm, checkInTime: e.target.value })} /></div>
                <div><Label className="mb-1.5 block">وقت الخروج</Label><Input value={hotelForm.checkOutTime} onChange={(e) => setHotelForm({ ...hotelForm, checkOutTime: e.target.value })} /></div>
              </div>
              <div className="md:col-span-2"><Label className="mb-1.5 block">العنوان بالعربية</Label><Textarea rows={3} value={hotelForm.addressAr} onChange={(e) => setHotelForm({ ...hotelForm, addressAr: e.target.value })} /></div>
              <div className="md:col-span-2"><Label className="mb-1.5 block">العنوان بالإنجليزية</Label><Textarea rows={3} value={hotelForm.addressEn} onChange={(e) => setHotelForm({ ...hotelForm, addressEn: e.target.value })} /></div>
            </div>

            <div className="pt-5">
              <Button onClick={() => void handleSaveHotel()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">حفظ بيانات الفندق</Button>
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-5">
              <Bell className="w-5 h-5 text-[#780000]" />
              <h2 className="font-bold text-gray-800">سجل النشاط</h2>
            </div>

            <div className="space-y-3">
              {(activityLogs ?? []).map((log) => (
                <div key={log.id} className="rounded-2xl border border-gray-100 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="font-semibold text-gray-800">{log.actorName || "Unknown"}</p>
                      <p className="text-sm text-gray-500">{log.action} / {log.entityType}</p>
                      <p className="text-xs text-gray-400 mt-1">{log.details || "بدون تفاصيل"}</p>
                    </div>
                    <div className="text-xs text-gray-400">
                      {new Date(log.createdAt).toLocaleString("ar-SA")}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      <Dialog open={adminDialogOpen} onOpenChange={setAdminDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingAdminId ? "تعديل الأدمن" : "إضافة أدمن"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div><Label className="mb-1.5 block">الاسم</Label><Input value={adminForm.name} onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">اسم المستخدم</Label><Input value={adminForm.username} onChange={(e) => setAdminForm({ ...adminForm, username: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الإيميل</Label><Input value={adminForm.email} onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">{editingAdminId ? "كلمة مرور جديدة اختياريًا" : "كلمة المرور"}</Label><Input type="password" value={adminForm.password} onChange={(e) => setAdminForm({ ...adminForm, password: e.target.value })} /></div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" className="rounded-full" onClick={() => setAdminDialogOpen(false)}>إلغاء</Button>
              <Button className="bg-[#780000] hover:bg-[#600000] text-white rounded-full" onClick={() => void handleSaveAdmin()}>حفظ</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
