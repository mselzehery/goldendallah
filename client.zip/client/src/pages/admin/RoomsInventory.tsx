﻿import { useState } from "react";
import { Link } from "wouter";
import { BedDouble, CalendarCheck, Edit, ImageIcon, LayoutDashboard, LogOut, MessageSquare, Plus, Settings, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { amenitiesJsonToFormFields, formFieldsToAmenitiesJson } from "@/lib/roomAmenities";

const typeLabels: Record<string, string> = {
  "junior-suite": "جناح جونيور",
  studio: "استديو",
  "family-suite": "جناح عائلي",
  accessible: "غرفة لذوي الاحتياجات",
};

function AdminNav({ active }: { active: string }) {
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/content", icon: ImageIcon, label: "المحتوى" },
    { href: "/admin/settings", icon: Settings, label: "الإعدادات" },
  ];

  return (
    <aside className="fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 hidden lg:flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center"><span className="text-amber-400 font-bold text-lg">G</span></div>
          <div><div className="font-bold text-white text-sm">جولدن دلة</div><div className="text-amber-400 text-xs">إدارة الغرف</div></div>
        </div>
      </div>
      <nav className="p-4 flex-1">
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link key={href} href={href}>
            <div className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
              <Icon className="w-5 h-5" /><span className="text-sm font-medium">{label}</span>
            </div>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-white/10">
        <Link href="/"><div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1"><LayoutDashboard className="w-5 h-5" /><span className="text-sm">عرض الموقع</span></div></Link>
        <button onClick={() => logout()} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors"><LogOut className="w-5 h-5" /><span className="text-sm">تسجيل الخروج</span></button>
      </div>
    </aside>
  );
}

const emptyRoom = {
  nameAr: "",
  nameEn: "",
  descriptionAr: "",
  descriptionEn: "",
  type: "junior-suite" as const,
  pricePerNight: "",
  inventoryCount: 1,
  capacity: 2,
  size: undefined as number | undefined,
  floor: undefined as number | undefined,
  imageUrl: "",
  amenitiesAr: "",
  amenitiesEn: "",
  isAvailable: true,
  isFeatured: false,
};

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

export default function AdminRoomsInventory() {
  const { user, isAuthenticated, loading } = useAuth();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState(emptyRoom);
  const [stockToAdd, setStockToAdd] = useState(0);
  const [imageUploading, setImageUploading] = useState(false);
  const utils = trpc.useUtils();

  const { data: rooms, isLoading } = trpc.rooms.listAdmin.useQuery(undefined, { enabled: !!isAuthenticated });
  const uploadImage = trpc.media.uploadImage.useMutation({
    onError: (err) => toast.error(err.message || "حدث خطأ أثناء رفع الصورة"),
  });

  const createRoom = trpc.rooms.create.useMutation({
    onSuccess: async () => {
      await utils.rooms.listAdmin.invalidate();
      await utils.rooms.list.invalidate();
      setForm(emptyRoom);
      setStockToAdd(0);
      setDialogOpen(false);
      toast.success("تم حفظ نوع الغرفة");
    },
    onError: (err) => toast.error(err.message || "حدث خطأ أثناء الحفظ"),
  });

  const updateRoom = trpc.rooms.update.useMutation({
    onSuccess: async () => {
      await utils.rooms.listAdmin.invalidate();
      await utils.rooms.list.invalidate();
      setStockToAdd(0);
      setDialogOpen(false);
      toast.success("تم تحديث نوع الغرفة");
    },
    onError: (err) => toast.error(err.message || "حدث خطأ أثناء التحديث"),
  });

  const deleteRoom = trpc.rooms.delete.useMutation({
    onSuccess: async () => {
      await utils.rooms.listAdmin.invalidate();
      await utils.rooms.list.invalidate();
      toast.success("تم حذف نوع الغرفة");
    },
    onError: (err) => toast.error(err.message || "حدث خطأ أثناء الحذف"),
  });

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" /></div>;
  if (!isAuthenticated || user?.role !== "admin") return <div className="min-h-screen flex items-center justify-center"><p>غير مصرح</p></div>;

  const editingRoom = editingId ? (rooms || []).find((room) => room.id === editingId) : undefined;

  function openAdd() {
    setEditingId(null);
    setForm(emptyRoom);
    setStockToAdd(0);
    setDialogOpen(true);
  }

  function openEdit(room: any) {
    setEditingId(room.id);
    setStockToAdd(0);
    setForm({
      nameAr: room.nameAr,
      nameEn: room.nameEn,
      descriptionAr: room.descriptionAr || "",
      descriptionEn: room.descriptionEn || "",
      type: room.type,
      pricePerNight: String(room.pricePerNight),
      inventoryCount: room.inventoryCount ?? 1,
      capacity: room.capacity,
      size: room.size,
      floor: room.floor,
      imageUrl: room.imageUrl || "",
      amenitiesAr: amenitiesJsonToFormFields(room.amenities).ar,
      amenitiesEn: amenitiesJsonToFormFields(room.amenities).en,
      isAvailable: room.isAvailable,
      isFeatured: room.isFeatured,
    });
    setDialogOpen(true);
  }

  function handleSave() {
    if (!form.nameAr || !form.nameEn || !form.pricePerNight) {
      toast.error("أكمل الحقول المطلوبة");
      return;
    }

    const { amenitiesAr, amenitiesEn, ...rest } = form;
    const nextInventoryCount = editingId
      ? Math.max((parseInt(String(form.inventoryCount)) || 0) + Math.max(stockToAdd, 0), 0)
      : Math.max(parseInt(String(form.inventoryCount)) || 1, 1);

    const finalData = {
      ...rest,
      pricePerNight: String(parseFloat(String(form.pricePerNight)) || 0),
      inventoryCount: nextInventoryCount,
      capacity: parseInt(String(form.capacity)) || 2,
      size: form.size ? parseInt(String(form.size)) : 0,
      floor: form.floor ? parseInt(String(form.floor)) : 0,
      amenities: formFieldsToAmenitiesJson(amenitiesAr, amenitiesEn),
    };

    if (editingId) {
      updateRoom.mutate({ id: editingId, ...finalData });
      return;
    }

    createRoom.mutate(finalData as any);
  }

  async function handleImageUpload(file?: File | null) {
    if (!file) return;

    setImageUploading(true);
    try {
      const base64Data = await fileToBase64(file);
      const result = await uploadImage.mutateAsync({
        fileName: file.name,
        base64Data,
        folder: "rooms",
      });
      setForm((current) => ({ ...current, imageUrl: result.url }));
      toast.success("تم رفع صورة الغرفة");
    } finally {
      setImageUploading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/rooms" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
          <div>
            <h1 className="text-xl font-bold text-[#780000]">إدارة أنواع الغرف</h1>
            <p className="text-sm text-gray-500 mt-1">المتبقي الآن يُحسب من الحجوزات الحالية، وإذا وصل صفر يمكنك إضافة وحدات جديدة مباشرة من شاشة التعديل.</p>
          </div>
          <Button onClick={openAdd} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full flex items-center gap-2">
            <Plus className="w-4 h-4" />إضافة نوع غرفة
          </Button>
        </header>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {isLoading ? (
              [1, 2, 3].map((i) => <div key={i} className="rounded-2xl bg-gray-200 animate-pulse h-48" />)
            ) : (rooms || []).map((room) => (
              <div key={room.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="relative h-36">
                  {room.imageUrl ? (
                    <img src={room.imageUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gray-100 flex items-center justify-center"><BedDouble className="w-10 h-10 text-gray-300" /></div>
                  )}
                  <div className="absolute top-3 start-3 flex gap-2">
                    <span className="bg-[#780000] text-white text-xs px-2 py-0.5 rounded-full">{typeLabels[room.type] || room.type}</span>
                    {room.isFeatured ? <span className="bg-amber-500 text-white text-xs px-2 py-0.5 rounded-full">مميز</span> : null}
                    <span className={`text-xs px-2 py-0.5 rounded-full ${room.isAvailable ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                      {room.isAvailable ? "متاح" : "مخفي"}
                    </span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-1">{room.nameAr}</h3>
                  <p className="text-gray-500 text-xs mb-2">{room.nameEn}</p>
                  <div className="flex flex-wrap gap-3 text-xs text-gray-500 mb-3">
                    <span>إجمالي الوحدات: <strong className="text-[#780000]">{room.inventoryCount ?? 1}</strong></span>
                    <span>المحجوز الآن: <strong className="text-amber-600">{room.reservedToday ?? 0}</strong></span>
                    <span>المتبقي الآن: <strong className={(room.remainingToday ?? 0) > 0 ? "text-emerald-600" : "text-red-600"}>{room.remainingToday ?? room.inventoryCount ?? 0}</strong></span>
                    <span>السعة: <strong>{room.capacity}</strong></span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#780000] font-bold">{parseFloat(String(room.pricePerNight)).toLocaleString()} ريال/ليلة</span>
                    <div className="flex gap-2">
                      <button onClick={() => openEdit(room)} className="w-8 h-8 bg-blue-50 hover:bg-blue-100 text-blue-600 rounded-full flex items-center justify-center transition-colors">
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => { if (confirm("هل أنت متأكد من الحذف؟")) void deleteRoom.mutateAsync({ id: room.id }); }} className="w-8 h-8 bg-red-50 hover:bg-red-100 text-red-600 rounded-full flex items-center justify-center transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-[#780000]">{editingId ? "تعديل نوع الغرفة" : "إضافة نوع غرفة جديد"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="grid grid-cols-2 gap-4">
              <div><Label className="mb-1.5 block text-sm">الاسم بالعربية *</Label><Input value={form.nameAr} onChange={(e) => setForm({ ...form, nameAr: e.target.value })} /></div>
              <div><Label className="mb-1.5 block text-sm">الاسم بالإنجليزية *</Label><Input value={form.nameEn} onChange={(e) => setForm({ ...form, nameEn: e.target.value })} dir="ltr" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><Label className="mb-1.5 block text-sm">الوصف بالعربية</Label><Textarea value={form.descriptionAr} onChange={(e) => setForm({ ...form, descriptionAr: e.target.value })} rows={3} className="resize-none" /></div>
              <div><Label className="mb-1.5 block text-sm">الوصف بالإنجليزية</Label><Textarea value={form.descriptionEn} onChange={(e) => setForm({ ...form, descriptionEn: e.target.value })} rows={3} className="resize-none" dir="ltr" /></div>
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div>
                <Label className="mb-1.5 block text-sm">النوع *</Label>
                <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as any })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="junior-suite">جناح جونيور</SelectItem>
                    <SelectItem value="studio">استديو</SelectItem>
                    <SelectItem value="family-suite">جناح عائلي</SelectItem>
                    <SelectItem value="accessible">غرفة لذوي الاحتياجات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label className="mb-1.5 block text-sm">السعر/ليلة *</Label><Input type="number" value={form.pricePerNight} onChange={(e) => setForm({ ...form, pricePerNight: e.target.value })} dir="ltr" /></div>
              <div>
                <Label className="mb-1.5 block text-sm">{editingId ? "إجمالي الوحدات المسجلة" : "عدد الوحدات *"}</Label>
                <Input
                  type="number"
                  value={form.inventoryCount}
                  onChange={(e) => setForm({ ...form, inventoryCount: Math.max(parseInt(e.target.value) || 0, 0) })}
                  dir="ltr"
                  readOnly={!!editingId}
                  className={editingId ? "bg-gray-50" : ""}
                />
              </div>
              <div><Label className="mb-1.5 block text-sm">السعة</Label><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: parseInt(e.target.value) || 2 })} dir="ltr" /></div>
            </div>
            {editingId ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="mb-1.5 block text-sm">المتبقي الآن</Label>
                  <Input value={editingRoom?.remainingToday ?? 0} readOnly dir="ltr" className="bg-gray-50" />
                </div>
                <div>
                  <Label className="mb-1.5 block text-sm">المحجوز الآن</Label>
                  <Input value={editingRoom?.reservedToday ?? 0} readOnly dir="ltr" className="bg-gray-50" />
                </div>
                <div>
                  <Label className="mb-1.5 block text-sm">إضافة وحدات جديدة</Label>
                  <Input type="number" value={stockToAdd} onChange={(e) => setStockToAdd(Math.max(parseInt(e.target.value) || 0, 0))} dir="ltr" placeholder="0" />
                </div>
              </div>
            ) : null}
            <div className="grid grid-cols-2 gap-4">
              <div><Label className="mb-1.5 block text-sm">المساحة (م²)</Label><Input type="number" value={form.size || ""} onChange={(e) => setForm({ ...form, size: e.target.value ? parseInt(e.target.value) : undefined })} dir="ltr" /></div>
              <div><Label className="mb-1.5 block text-sm">الطابق</Label><Input type="number" value={form.floor || ""} onChange={(e) => setForm({ ...form, floor: e.target.value ? parseInt(e.target.value) : undefined })} dir="ltr" /></div>
            </div>
            <div className="space-y-3">
              <div>
                <Label className="mb-1.5 block text-sm">صورة الغرفة الرئيسية</Label>
                <Input type="file" accept="image/*" onChange={(e) => void handleImageUpload(e.target.files?.[0])} disabled={imageUploading || uploadImage.isPending} />
              </div>
              {form.imageUrl ? (
                <div className="rounded-2xl overflow-hidden border border-gray-200 bg-gray-50">
                  <img src={form.imageUrl} alt="" className="h-40 w-full object-cover" />
                </div>
              ) : null}
              <Input value={form.imageUrl} readOnly dir="ltr" className="bg-gray-50" placeholder="/uploads/rooms/..." />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="mb-1.5 block text-sm">المرافق (عربي)</Label>
                <Textarea value={form.amenitiesAr} onChange={(e) => setForm({ ...form, amenitiesAr: e.target.value })} placeholder="واي فاي، تلفاز، مكيّف..." rows={3} className="resize-none" />
                <p className="text-xs text-gray-400 mt-1">افصل بين المرافق بفاصلة عربية أو إنجليزية</p>
              </div>
              <div>
                <Label className="mb-1.5 block text-sm">المرافق (إنجليزي)</Label>
                <Textarea value={form.amenitiesEn} onChange={(e) => setForm({ ...form, amenitiesEn: e.target.value })} placeholder="WiFi, TV, air conditioning..." rows={3} className="resize-none" dir="ltr" />
                <p className="text-xs text-gray-400 mt-1">يفضل أن يكون بنفس ترتيب العربي</p>
              </div>
            </div>
            <div className="flex gap-6">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isAvailable} onChange={(e) => setForm({ ...form, isAvailable: e.target.checked })} className="w-4 h-4 accent-[#780000]" />
                <span className="text-sm">متاح للحجز</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={form.isFeatured} onChange={(e) => setForm({ ...form, isFeatured: e.target.checked })} className="w-4 h-4 accent-amber-500" />
                <span className="text-sm">نوع مميز</span>
              </label>
            </div>
            <div className="flex gap-3 justify-end pt-2">
              <Button variant="outline" onClick={() => setDialogOpen(false)} className="rounded-full px-6">إلغاء</Button>
              <Button onClick={handleSave} disabled={createRoom.isPending || updateRoom.isPending || imageUploading || uploadImage.isPending} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full px-8">
                {(createRoom.isPending || updateRoom.isPending || imageUploading || uploadImage.isPending) ? "جارٍ الحفظ..." : editingId ? "حفظ التعديلات" : "إضافة النوع"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
