import { useState } from "react";
import { Link } from "wouter";
import { LayoutDashboard, BedDouble, CalendarCheck, MessageSquare, LogOut, Mail, Phone, Check, Eye, Settings } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

function AdminNav({ active }: { active: string }) {
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/settings", icon: Settings, label: "الإعدادات" },
  ];
  return (
    <aside className="fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 hidden lg:flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center"><span className="text-amber-400 font-bold text-lg">G</span></div>
          <div><div className="font-bold text-white text-sm">جولدن دلة</div><div className="text-amber-400 text-xs">لوحة الإدارة</div></div>
        </div>
      </div>
      <nav className="p-4 flex-1">
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link key={href} href={href}>
            <div className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
              <Icon className="w-5 h-5" /><span className="text-sm font-medium">{label}</span>
            </div>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-white/10">
        <Link href="/"><div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1"><LayoutDashboard className="w-5 h-5" /><span className="text-sm">عرض الموقع</span></div></Link>
        <button onClick={() => logout()} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors"><LogOut className="w-5 h-5" /><span className="text-sm">تسجيل الخروج</span></button>
      </div>
    </aside>
  );
}

export default function AdminInquiries() {
  const { user, isAuthenticated, loading } = useAuth();
  const [selected, setSelected] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data: inquiries, isLoading } = trpc.inquiries.listAdmin.useQuery();

  const updateStatus = trpc.inquiries.updateStatus.useMutation({
    onSuccess: () => { utils.inquiries.listAdmin.invalidate(); toast.success("تم تحديث الحالة"); },
    onError: () => toast.error("حدث خطأ"),
  });

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" /></div>;
  if (!isAuthenticated || user?.role !== "admin") return <div className="min-h-screen flex items-center justify-center"><p>غير مصرح</p></div>;

  const statusColors: Record<string, string> = {
    new: "bg-blue-100 text-blue-700",
    read: "bg-gray-100 text-gray-600",
    replied: "bg-green-100 text-green-700",
  };
  const statusLabels: Record<string, string> = { new: "جديد", read: "مقروء", replied: "تم الرد" };

  const selectedInquiry = inquiries?.find(i => i.id === selected);

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/inquiries" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-30">
          <h1 className="text-xl font-bold text-[#780000]">الاستفسارات والرسائل</h1>
        </header>
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* List */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="p-4 border-b border-gray-100">
                <span className="text-sm text-gray-500">{inquiries?.length ?? 0} رسالة</span>
              </div>
              <div className="divide-y divide-gray-50">
                {isLoading ? (
                  <div className="p-8 text-center"><div className="w-8 h-8 border-2 border-[#780000] border-t-transparent rounded-full animate-spin mx-auto" /></div>
                ) : inquiries && inquiries.length > 0 ? (
                  inquiries.map((inq) => (
                    <div
                      key={inq.id}
                      onClick={() => { setSelected(inq.id); if (inq.status === "new") updateStatus.mutate({ id: inq.id, status: "read" }); }}
                      className={`p-4 cursor-pointer hover:bg-gray-50 transition-colors ${selected === inq.id ? "bg-[#780000]/5 border-s-2 border-[#780000]" : ""}`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-semibold text-gray-800 text-sm">{inq.name}</span>
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[inq.status]}`}>{statusLabels[inq.status]}</span>
                          </div>
                          {inq.subject && <p className="text-xs text-gray-500 mb-1">{inq.subject}</p>}
                          <p className="text-xs text-gray-400 truncate">{inq.message}</p>
                        </div>
                        <span className="text-xs text-gray-400 whitespace-nowrap">{new Date(inq.createdAt).toLocaleDateString("ar-SA")}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-8 text-center text-gray-400 text-sm">لا توجد رسائل</div>
                )}
              </div>
            </div>

            {/* Detail */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
              {selectedInquiry ? (
                <div className="p-6">
                  <div className="flex items-start justify-between mb-6">
                    <div>
                      <h3 className="text-lg font-bold text-gray-800">{selectedInquiry.name}</h3>
                      {selectedInquiry.subject && <p className="text-sm text-gray-500 mt-1">{selectedInquiry.subject}</p>}
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[selectedInquiry.status]}`}>{statusLabels[selectedInquiry.status]}</span>
                  </div>

                  <div className="space-y-3 mb-6 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <Mail className="w-4 h-4 text-[#780000]" />
                      <a href={`mailto:${selectedInquiry.email}`} className="hover:text-[#780000]" dir="ltr">{selectedInquiry.email}</a>
                    </div>
                    {selectedInquiry.phone && (
                      <div className="flex items-center gap-2 text-gray-600">
                        <Phone className="w-4 h-4 text-[#780000]" />
                        <span dir="ltr">{selectedInquiry.phone}</span>
                      </div>
                    )}
                  </div>

                  <div className="bg-gray-50 rounded-xl p-5 mb-6">
                    <p className="text-gray-700 text-sm leading-relaxed">{selectedInquiry.message}</p>
                  </div>

                  <div className="flex gap-3">
                    <a href={`mailto:${selectedInquiry.email}?subject=رد على استفسارك`}>
                      <Button className="bg-[#780000] hover:bg-[#600000] text-white rounded-full flex items-center gap-2">
                        <Mail className="w-4 h-4" />الرد بالبريد
                      </Button>
                    </a>
                    {selectedInquiry.status !== "replied" && (
                      <Button
                        variant="outline"
                        onClick={() => updateStatus.mutate({ id: selectedInquiry.id, status: "replied" })}
                        className="border-green-500 text-green-600 hover:bg-green-50 rounded-full flex items-center gap-2"
                      >
                        <Check className="w-4 h-4" />تم الرد
                      </Button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 p-8 min-h-[300px]">
                  <MessageSquare className="w-12 h-12 mb-3 opacity-30" />
                  <p className="text-sm">اختر رسالة لعرض تفاصيلها</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
