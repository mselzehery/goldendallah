﻿import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  BedDouble,
  CalendarCheck,
  ImageIcon,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  Plus,
  Settings as SettingsIcon,
  Sparkles,
  Star,
  Trash2,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";
import { facilityIconOptions, resolveFacilityIcon } from "@/lib/facilityIcons";

const facilityCategoryLabels: Record<string, string> = {
  dining: "المطاعم",
  wellness: "الاسترخاء والسبا",
  recreation: "الترفيه",
  business: "الأعمال",
  services: "الخدمات",
};

const galleryCategoryLabels: Record<string, string> = {
  lobby: "اللوبي",
  rooms: "الغرف",
  dining: "المطاعم",
  pool: "المسبح",
  spa: "السبا",
  exterior: "الواجهة الخارجية",
  events: "الفعاليات",
};

type FacilityCategory = "dining" | "wellness" | "recreation" | "business" | "services";
type GalleryCategory = "lobby" | "rooms" | "dining" | "pool" | "spa" | "exterior" | "events";

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsDataURL(file);
  });
}

function AdminNav({ active }: { active: string }) {
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/content", icon: Sparkles, label: "المحتوى" },
    { href: "/admin/settings", icon: SettingsIcon, label: "الإعدادات" },
  ];

  return (
    <aside className="fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 hidden lg:flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center">
            <span className="text-amber-400 font-bold text-lg">G</span>
          </div>
          <div>
            <div className="font-bold text-white text-sm">جولدن دلة</div>
            <div className="text-amber-400 text-xs">إدارة المحتوى</div>
          </div>
        </div>
      </div>
      <nav className="p-4 flex-1">
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link key={href} href={href}>
            <div className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}>
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{label}</span>
            </div>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-white/10">
        <Link href="/">
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1">
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-sm">عرض الموقع</span>
          </div>
        </Link>
        <button onClick={() => logout()} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors">
          <LogOut className="w-5 h-5" />
          <span className="text-sm">تسجيل الخروج</span>
        </button>
      </div>
    </aside>
  );
}

const emptyFacilityForm = {
  nameAr: "",
  nameEn: "",
  descriptionAr: "",
  descriptionEn: "",
  category: "services" as FacilityCategory,
  icon: "",
  imageUrl: "",
  sortOrder: 0,
  isActive: true,
};

const emptyGalleryForm = {
  titleAr: "",
  titleEn: "",
  imageUrl: "",
  category: "lobby" as GalleryCategory,
  sortOrder: 0,
  isActive: true,
};

const emptyReviewForm = {
  guestName: "",
  guestRoleAr: "",
  guestRoleEn: "",
  reviewTextAr: "",
  reviewTextEn: "",
  rating: 5,
  avatarImageUrl: "",
  sortOrder: 0,
  isActive: true,
};

export default function ContentManager() {
  const { user, loading, isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const [facilityDialogOpen, setFacilityDialogOpen] = useState(false);
  const [galleryDialogOpen, setGalleryDialogOpen] = useState(false);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [editingFacilityId, setEditingFacilityId] = useState<number | null>(null);
  const [editingGalleryId, setEditingGalleryId] = useState<number | null>(null);
  const [editingReviewId, setEditingReviewId] = useState<number | null>(null);
  const [facilityForm, setFacilityForm] = useState(emptyFacilityForm);
  const [galleryForm, setGalleryForm] = useState(emptyGalleryForm);
  const [reviewForm, setReviewForm] = useState(emptyReviewForm);
  const [facilityImageUploading, setFacilityImageUploading] = useState(false);
  const [galleryImageUploading, setGalleryImageUploading] = useState(false);
  const [reviewImageUploading, setReviewImageUploading] = useState(false);

  const { data: facilities } = trpc.facilities.listAdmin.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: galleryImages } = trpc.gallery.listAdmin.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: reviews } = trpc.reviews.listAdmin.useQuery(undefined, { enabled: !!isAuthenticated });

  const uploadImage = trpc.media.uploadImage.useMutation({
    onError: (error) => toast.error(error.message),
  });

  const createFacility = trpc.facilities.create.useMutation({
    onSuccess: async () => {
      await utils.facilities.listAdmin.invalidate();
      await utils.facilities.list.invalidate();
      toast.success("تمت إضافة المرفق");
      setFacilityDialogOpen(false);
      setFacilityForm(emptyFacilityForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const updateFacility = trpc.facilities.update.useMutation({
    onSuccess: async () => {
      await utils.facilities.listAdmin.invalidate();
      await utils.facilities.list.invalidate();
      toast.success("تم تحديث المرفق");
      setFacilityDialogOpen(false);
      setEditingFacilityId(null);
      setFacilityForm(emptyFacilityForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteFacility = trpc.facilities.delete.useMutation({
    onSuccess: async () => {
      await utils.facilities.listAdmin.invalidate();
      await utils.facilities.list.invalidate();
      toast.success("تم حذف المرفق");
    },
    onError: (error) => toast.error(error.message),
  });

  const createGallery = trpc.gallery.create.useMutation({
    onSuccess: async () => {
      await utils.gallery.listAdmin.invalidate();
      await utils.gallery.list.invalidate();
      toast.success("تمت إضافة صورة المعرض");
      setGalleryDialogOpen(false);
      setGalleryForm(emptyGalleryForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const updateGallery = trpc.gallery.update.useMutation({
    onSuccess: async () => {
      await utils.gallery.listAdmin.invalidate();
      await utils.gallery.list.invalidate();
      toast.success("تم تحديث صورة المعرض");
      setGalleryDialogOpen(false);
      setEditingGalleryId(null);
      setGalleryForm(emptyGalleryForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteGallery = trpc.gallery.delete.useMutation({
    onSuccess: async () => {
      await utils.gallery.listAdmin.invalidate();
      await utils.gallery.list.invalidate();
      toast.success("تم حذف صورة المعرض");
    },
    onError: (error) => toast.error(error.message),
  });

  const createReview = trpc.reviews.create.useMutation({
    onSuccess: async () => {
      await utils.reviews.listAdmin.invalidate();
      await utils.reviews.list.invalidate();
      toast.success("تمت إضافة التقييم");
      setReviewDialogOpen(false);
      setReviewForm(emptyReviewForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const updateReview = trpc.reviews.update.useMutation({
    onSuccess: async () => {
      await utils.reviews.listAdmin.invalidate();
      await utils.reviews.list.invalidate();
      toast.success("تم تحديث التقييم");
      setReviewDialogOpen(false);
      setEditingReviewId(null);
      setReviewForm(emptyReviewForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteReview = trpc.reviews.delete.useMutation({
    onSuccess: async () => {
      await utils.reviews.listAdmin.invalidate();
      await utils.reviews.list.invalidate();
      toast.success("تم حذف التقييم");
    },
    onError: (error) => toast.error(error.message),
  });

  const facilityCounts = useMemo(() => ({
    total: (facilities ?? []).length,
    active: (facilities ?? []).filter((item) => item.isActive).length,
  }), [facilities]);

  const galleryCounts = useMemo(() => ({
    total: (galleryImages ?? []).length,
    active: (galleryImages ?? []).filter((item) => item.isActive).length,
  }), [galleryImages]);

  const reviewCounts = useMemo(() => ({
    total: (reviews ?? []).length,
    active: (reviews ?? []).filter((item) => item.isActive).length,
  }), [reviews]);
  const FacilityIconPreview = resolveFacilityIcon(facilityForm.icon, facilityForm.category);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" /></div>;
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return <div className="min-h-screen flex items-center justify-center"><p>غير مصرح</p></div>;
  }

  const openCreateFacility = () => { setEditingFacilityId(null); setFacilityForm(emptyFacilityForm); setFacilityDialogOpen(true); };
  const openCreateGallery = () => { setEditingGalleryId(null); setGalleryForm(emptyGalleryForm); setGalleryDialogOpen(true); };
  const openCreateReview = () => { setEditingReviewId(null); setReviewForm(emptyReviewForm); setReviewDialogOpen(true); };

  const openEditFacility = (item: any) => {
    setEditingFacilityId(item.id);
    setFacilityForm({
      nameAr: item.nameAr ?? "",
      nameEn: item.nameEn ?? "",
      descriptionAr: item.descriptionAr ?? "",
      descriptionEn: item.descriptionEn ?? "",
      category: item.category,
      icon: item.icon ?? "",
      imageUrl: item.imageUrl ?? "",
      sortOrder: item.sortOrder ?? 0,
      isActive: item.isActive ?? true,
    });
    setFacilityDialogOpen(true);
  };

  const openEditGallery = (item: any) => {
    setEditingGalleryId(item.id);
    setGalleryForm({
      titleAr: item.titleAr ?? "",
      titleEn: item.titleEn ?? "",
      imageUrl: item.imageUrl ?? "",
      category: item.category,
      sortOrder: item.sortOrder ?? 0,
      isActive: item.isActive ?? true,
    });
    setGalleryDialogOpen(true);
  };

  const openEditReview = (item: any) => {
    setEditingReviewId(item.id);
    setReviewForm({
      guestName: item.guestName ?? "",
      guestRoleAr: item.guestRoleAr ?? "",
      guestRoleEn: item.guestRoleEn ?? "",
      reviewTextAr: item.reviewTextAr ?? "",
      reviewTextEn: item.reviewTextEn ?? "",
      rating: item.rating ?? 5,
      avatarImageUrl: item.avatarImageUrl ?? "",
      sortOrder: item.sortOrder ?? 0,
      isActive: item.isActive ?? true,
    });
    setReviewDialogOpen(true);
  };

  async function handleUpload(file: File, folder: "gallery" | "facilities" | "reviews", onUrl: (url: string) => void, setLoading: (value: boolean) => void) {
    setLoading(true);
    try {
      const base64Data = await fileToBase64(file);
      const result = await uploadImage.mutateAsync({ fileName: file.name, base64Data, folder });
      onUrl(result.url);
      toast.success("تم رفع الصورة");
    } finally {
      setLoading(false);
    }
  }

  async function handleSaveFacility() {
    if (!facilityForm.nameAr || !facilityForm.nameEn) {
      toast.error("أكمل بيانات المرفق");
      return;
    }
    if (editingFacilityId) {
      await updateFacility.mutateAsync({ id: editingFacilityId, ...facilityForm });
      return;
    }
    await createFacility.mutateAsync(facilityForm);
  }

  async function handleSaveGallery() {
    if (!galleryForm.imageUrl) {
      toast.error("أضف صورة للمعرض");
      return;
    }
    if (editingGalleryId) {
      await updateGallery.mutateAsync({ id: editingGalleryId, ...galleryForm });
      return;
    }
    await createGallery.mutateAsync(galleryForm);
  }

  async function handleSaveReview() {
    if (!reviewForm.guestName || !reviewForm.reviewTextAr || !reviewForm.reviewTextEn) {
      toast.error("أكمل بيانات التقييم");
      return;
    }
    if (editingReviewId) {
      await updateReview.mutateAsync({ id: editingReviewId, ...reviewForm });
      return;
    }
    await createReview.mutateAsync(reviewForm);
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/content" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-30">
          <h1 className="text-xl font-bold text-[#780000]">إدارة المحتوى</h1>
          <p className="text-sm text-gray-500 mt-1">أدر المرافق وصور المعرض وتقييمات العملاء من مكان واحد.</p>
        </header>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2"><Sparkles className="w-5 h-5 text-[#780000]" /><h2 className="font-bold text-gray-800">المرافق</h2></div>
              <p className="text-3xl font-bold text-[#780000]">{facilityCounts.total}</p>
              <p className="text-sm text-gray-500 mt-1">النشطة: {facilityCounts.active}</p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2"><ImageIcon className="w-5 h-5 text-[#780000]" /><h2 className="font-bold text-gray-800">صور المعرض</h2></div>
              <p className="text-3xl font-bold text-[#780000]">{galleryCounts.total}</p>
              <p className="text-sm text-gray-500 mt-1">النشطة: {galleryCounts.active}</p>
            </div>
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2"><Star className="w-5 h-5 text-[#780000]" /><h2 className="font-bold text-gray-800">تقييمات العملاء</h2></div>
              <p className="text-3xl font-bold text-[#780000]">{reviewCounts.total}</p>
              <p className="text-sm text-gray-500 mt-1">النشطة: {reviewCounts.active}</p>
            </div>
          </div>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3"><Sparkles className="w-5 h-5 text-[#780000]" /><h2 className="font-bold text-gray-800">المرافق</h2></div>
              <Button onClick={openCreateFacility} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full"><Plus className="w-4 h-4 ms-2" />إضافة مرفق</Button>
            </div>
            <div className="space-y-3">
              {(facilities ?? []).map((item) => (
                <div key={item.id} className="rounded-2xl border border-gray-100 p-4 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <p className="font-semibold text-gray-800">{item.nameAr}</p>
                    <p className="text-sm text-gray-500">{item.nameEn}</p>
                    <p className="text-xs text-gray-400 mt-1">{facilityCategoryLabels[item.category] || item.category} | الترتيب: {item.sortOrder}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${item.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{item.isActive ? "نشط" : "مخفي"}</span>
                    <Button variant="outline" className="rounded-full" onClick={() => openEditFacility(item)}>تعديل</Button>
                    <Button variant="outline" className="rounded-full text-red-600 border-red-200 hover:bg-red-50" onClick={() => void deleteFacility.mutateAsync({ id: item.id })}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3"><ImageIcon className="w-5 h-5 text-[#780000]" /><h2 className="font-bold text-gray-800">قسم المعرض</h2></div>
              <Button onClick={openCreateGallery} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full"><Plus className="w-4 h-4 ms-2" />إضافة صورة</Button>
            </div>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
              {(galleryImages ?? []).map((item) => (
                <div key={item.id} className="rounded-2xl border border-gray-100 overflow-hidden bg-white">
                  <div className="h-48 bg-gray-100"><img src={item.imageUrl} alt={item.titleAr ?? ""} className="w-full h-full object-cover" /></div>
                  <div className="p-4 space-y-3">
                    <div>
                      <p className="font-semibold text-gray-800">{item.titleAr || "صورة بدون عنوان"}</p>
                      <p className="text-sm text-gray-500">{item.titleEn || "Untitled image"}</p>
                    </div>
                    <div className="text-xs text-gray-400">{galleryCategoryLabels[item.category] || item.category} | الترتيب: {item.sortOrder}</div>
                    <div className="flex items-center justify-between gap-3">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${item.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{item.isActive ? "نشطة" : "مخفية"}</span>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" className="rounded-full" onClick={() => openEditGallery(item)}>تعديل</Button>
                        <Button variant="outline" className="rounded-full text-red-600 border-red-200 hover:bg-red-50" onClick={() => void deleteGallery.mutateAsync({ id: item.id })}><Trash2 className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3"><Star className="w-5 h-5 text-[#780000]" /><h2 className="font-bold text-gray-800">تقييمات العملاء</h2></div>
              <Button onClick={openCreateReview} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full"><Plus className="w-4 h-4 ms-2" />إضافة تقييم</Button>
            </div>
            <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
              {(reviews ?? []).map((item) => (
                <div key={item.id} className="rounded-2xl border border-gray-100 p-4 bg-white">
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3">
                      {item.avatarImageUrl ? <img src={item.avatarImageUrl} alt={item.guestName} className="w-12 h-12 rounded-full object-cover" /> : <div className="w-12 h-12 rounded-full bg-[#780000] text-white flex items-center justify-center font-bold">{item.guestName.charAt(0)}</div>}
                      <div>
                        <p className="font-semibold text-gray-800">{item.guestName}</p>
                        <p className="text-xs text-gray-500">{item.guestRoleAr || item.guestRoleEn || "ضيف الفندق"}</p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${item.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>{item.isActive ? "نشط" : "مخفي"}</span>
                  </div>
                  <div className="flex gap-1 mb-3">{[...Array(item.rating ?? 5)].map((_, index) => (<Star key={index} className="w-4 h-4 fill-amber-400 text-amber-400" />))}</div>
                  <p className="text-sm text-gray-600 line-clamp-4 mb-4">{item.reviewTextAr || item.reviewTextEn}</p>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" className="rounded-full" onClick={() => openEditReview(item)}>تعديل</Button>
                    <Button variant="outline" className="rounded-full text-red-600 border-red-200 hover:bg-red-50" onClick={() => void deleteReview.mutateAsync({ id: item.id })}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>

      <Dialog open={facilityDialogOpen} onOpenChange={setFacilityDialogOpen}>
        <DialogContent className="sm:max-w-2xl" dir="rtl">
          <DialogHeader><DialogTitle>{editingFacilityId ? "تعديل المرفق" : "إضافة مرفق"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label className="mb-1.5 block">الاسم بالعربية</Label><Input value={facilityForm.nameAr} onChange={(e) => setFacilityForm({ ...facilityForm, nameAr: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الاسم بالإنجليزية</Label><Input value={facilityForm.nameEn} onChange={(e) => setFacilityForm({ ...facilityForm, nameEn: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الفئة</Label><select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={facilityForm.category} onChange={(e) => setFacilityForm({ ...facilityForm, category: e.target.value as FacilityCategory })}>{Object.entries(facilityCategoryLabels).map(([value, label]) => (<option key={value} value={value}>{label}</option>))}</select></div>
            <div><Label className="mb-1.5 block">الترتيب</Label><Input type="number" value={facilityForm.sortOrder} onChange={(e) => setFacilityForm({ ...facilityForm, sortOrder: Number(e.target.value) || 0 })} /></div>
                <div className="space-y-2">
                  <Label className="mb-1.5 block">الأيقونة</Label>
                  <select
                    className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm"
                    value={facilityForm.icon}
                    onChange={(e) => setFacilityForm({ ...facilityForm, icon: e.target.value })}
                  >
                    <option value="">تلقائي حسب الفئة</option>
                    {facilityIconOptions.map((option) => (
                      <option key={option.key} value={option.key}>
                        {option.labelAr}
                      </option>
                    ))}
                  </select>
                  <div className="flex items-center gap-2 text-xs text-gray-500">
                    <div className="w-9 h-9 rounded-full bg-[#780000]/10 flex items-center justify-center text-[#780000]">
                      <FacilityIconPreview className="w-4 h-4" />
                    </div>
                    <span>هذه الأيقونة ستظهر في الصفحة الرئيسية وصفحة المرافق بنفس الشكل.</span>
                  </div>
                </div>
            <div><Label className="mb-1.5 block">رابط الصورة</Label><Input value={facilityForm.imageUrl} readOnly /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">رفع صورة من الجهاز</Label><Input type="file" accept="image/*" disabled={facilityImageUploading} onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; await handleUpload(file, "facilities", (url) => setFacilityForm((current) => ({ ...current, imageUrl: url })), setFacilityImageUploading); }} /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">الوصف بالعربية</Label><Textarea rows={3} value={facilityForm.descriptionAr} onChange={(e) => setFacilityForm({ ...facilityForm, descriptionAr: e.target.value })} /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">الوصف بالإنجليزية</Label><Textarea rows={3} value={facilityForm.descriptionEn} onChange={(e) => setFacilityForm({ ...facilityForm, descriptionEn: e.target.value })} /></div>
            <div className="md:col-span-2 flex items-center gap-3"><Switch checked={facilityForm.isActive} onCheckedChange={(checked) => setFacilityForm({ ...facilityForm, isActive: checked })} /><span className="text-sm text-gray-600">إظهار المرفق في الموقع</span></div>
          </div>
          <div className="flex justify-end"><Button onClick={() => void handleSaveFacility()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">حفظ</Button></div>
        </DialogContent>
      </Dialog>

      <Dialog open={galleryDialogOpen} onOpenChange={setGalleryDialogOpen}>
        <DialogContent className="sm:max-w-2xl" dir="rtl">
          <DialogHeader><DialogTitle>{editingGalleryId ? "تعديل الصورة" : "إضافة صورة"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label className="mb-1.5 block">العنوان بالعربية</Label><Input value={galleryForm.titleAr} onChange={(e) => setGalleryForm({ ...galleryForm, titleAr: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">العنوان بالإنجليزية</Label><Input value={galleryForm.titleEn} onChange={(e) => setGalleryForm({ ...galleryForm, titleEn: e.target.value })} /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">رابط الصورة</Label><Input value={galleryForm.imageUrl} readOnly /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">رفع صورة من الجهاز</Label><Input type="file" accept="image/*" disabled={galleryImageUploading} onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; await handleUpload(file, "gallery", (url) => setGalleryForm((current) => ({ ...current, imageUrl: url })), setGalleryImageUploading); }} /></div>
            <div><Label className="mb-1.5 block">القسم</Label><select className="w-full h-10 rounded-md border border-input bg-background px-3 text-sm" value={galleryForm.category} onChange={(e) => setGalleryForm({ ...galleryForm, category: e.target.value as GalleryCategory })}>{Object.entries(galleryCategoryLabels).map(([value, label]) => (<option key={value} value={value}>{label}</option>))}</select></div>
            <div><Label className="mb-1.5 block">الترتيب</Label><Input type="number" value={galleryForm.sortOrder} onChange={(e) => setGalleryForm({ ...galleryForm, sortOrder: Number(e.target.value) || 0 })} /></div>
            <div className="md:col-span-2 flex items-center gap-3"><Switch checked={galleryForm.isActive} onCheckedChange={(checked) => setGalleryForm({ ...galleryForm, isActive: checked })} /><span className="text-sm text-gray-600">إظهار الصورة في الموقع</span></div>
          </div>
          <div className="flex justify-end"><Button onClick={() => void handleSaveGallery()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">حفظ</Button></div>
        </DialogContent>
      </Dialog>

      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="sm:max-w-2xl" dir="rtl">
          <DialogHeader><DialogTitle>{editingReviewId ? "تعديل التقييم" : "إضافة تقييم"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label className="mb-1.5 block">اسم العميل</Label><Input value={reviewForm.guestName} onChange={(e) => setReviewForm({ ...reviewForm, guestName: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">التقييم</Label><Input type="number" min={1} max={5} value={reviewForm.rating} onChange={(e) => setReviewForm({ ...reviewForm, rating: Number(e.target.value) || 5 })} /></div>
            <div><Label className="mb-1.5 block">الصفة بالعربية</Label><Input value={reviewForm.guestRoleAr} onChange={(e) => setReviewForm({ ...reviewForm, guestRoleAr: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الصفة بالإنجليزية</Label><Input value={reviewForm.guestRoleEn} onChange={(e) => setReviewForm({ ...reviewForm, guestRoleEn: e.target.value })} /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">نص التقييم بالعربية</Label><Textarea rows={3} value={reviewForm.reviewTextAr} onChange={(e) => setReviewForm({ ...reviewForm, reviewTextAr: e.target.value })} /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">نص التقييم بالإنجليزية</Label><Textarea rows={3} value={reviewForm.reviewTextEn} onChange={(e) => setReviewForm({ ...reviewForm, reviewTextEn: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الترتيب</Label><Input type="number" value={reviewForm.sortOrder} onChange={(e) => setReviewForm({ ...reviewForm, sortOrder: Number(e.target.value) || 0 })} /></div>
            <div><Label className="mb-1.5 block">رابط الصورة الشخصية</Label><Input value={reviewForm.avatarImageUrl} readOnly /></div>
            <div className="md:col-span-2"><Label className="mb-1.5 block">رفع صورة من الجهاز</Label><Input type="file" accept="image/*" disabled={reviewImageUploading} onChange={async (e) => { const file = e.target.files?.[0]; if (!file) return; await handleUpload(file, "reviews", (url) => setReviewForm((current) => ({ ...current, avatarImageUrl: url })), setReviewImageUploading); }} /></div>
            <div className="md:col-span-2 flex items-center gap-3"><Switch checked={reviewForm.isActive} onCheckedChange={(checked) => setReviewForm({ ...reviewForm, isActive: checked })} /><span className="text-sm text-gray-600">إظهار التقييم في الموقع</span></div>
          </div>
          <div className="flex justify-end"><Button onClick={() => void handleSaveReview()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">حفظ</Button></div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
