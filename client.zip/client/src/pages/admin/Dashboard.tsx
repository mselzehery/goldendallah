import { Link, useLocation } from "wouter";
import {
  LayoutDashboard, BedDouble, CalendarCheck, MessageSquare,
  Users, DollarSign, Clock, LogOut, Menu, Phone, Settings, Bell
} from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState } from "react";
import { Button } from "@/components/ui/button";

// --- مكون القائمة الجانبية ---
function AdminSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [location] = useLocation();
  const { logout } = useAuth(); // استدعاء دالة الخروج من الـ Hook المعدل

  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/content", icon: Bell, label: "المحتوى" },
    { href: "/admin/settings", icon: Settings, label: "الإعدادات" },
  ];

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={onClose} />}

      <aside className={`fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center">
              <img 
    src="/logo.png.png" 
    alt="Logo" 
    className="w-full h-full object-contain brightness-0 invert" 
    style={{ padding: '6px' }} 
  />
            </div>
            <div>
              <div className="font-bold text-white text-sm">جولدن دلة</div>
              <div className="text-amber-400 text-xs">لوحة الإدارة</div>
            </div>
          </div>
        </div>

        <nav className="p-4 flex-1">
          {navItems.map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}>
              <div
                onClick={onClose}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${
                  location === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{label}</span>
              </div>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-white/10">
          <Link href="/">
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1">
              <LayoutDashboard className="w-5 h-5" />
              <span className="text-sm">عرض الموقع</span>
            </div>
          </Link>
          <button
            onClick={async () => {
              await logout(); // ينظف السيرفر والـ LocalStorage
              window.location.href = "/";
            }}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm">تسجيل الخروج</span>
          </button>
        </div>
      </aside>
    </>
  );
}

// --- المكون الرئيسي للوحة التحكم ---
export default function AdminDashboard() {
  const { user, loading, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // استدعاء البيانات من السيرفر
  const { data: stats } = trpc.bookings.stats.useQuery();
  const { data: recentBookings } = trpc.bookings.listAdmin.useQuery();
  const { data: alerts } = trpc.admin.alerts.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  const isAuthorized = user?.role === "admin";

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#faf8f5]">
        <div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#faf8f5] text-center p-8">
        <h2 className="text-2xl font-bold text-[#780000] mb-2">الوصول مقيد</h2>
        <p className="text-gray-500 mb-6">هذه الصفحة متاحة لمدير فندق جولدن دلة فقط</p>
        <div className="flex gap-4">
          <Link href="/">
            <Button variant="outline">العودة للرئيسية</Button>
          </Link>
          <Button 
            className="bg-[#780000] text-white" 
            onClick={async () => {
               await logout();
               window.location.href = "/";
            }}
          >
            تسجيل الخروج والمحاولة بحساب آخر
          </Button>
        </div>
      </div>
    );
  }

  const statCards = [
    { icon: CalendarCheck, label: "إجمالي الحجوزات", value: stats?.total ?? 0, color: "bg-blue-50 text-blue-600" },
    { icon: Clock, label: "قيد الانتظار", value: stats?.pending ?? 0, color: "bg-amber-50 text-amber-600" },
    { icon: Users, label: "مؤكدة", value: stats?.confirmed ?? 0, color: "bg-green-50 text-green-600" },
    { icon: DollarSign, label: "الإيرادات (ريال)", value: stats?.totalRevenue ? parseFloat(String(stats.totalRevenue)).toLocaleString() : "0", color: "bg-purple-50 text-purple-600" },
  ];

  const statusColors: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    confirmed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    completed: "bg-blue-100 text-blue-700",
  };
  
  const statusLabels: Record<string, string> = {
    pending: "قيد الانتظار",
    confirmed: "مؤكد",
    cancelled: "ملغي",
    completed: "مكتمل",
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 rounded-md hover:bg-gray-100">
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold text-[#780000]">لوحة التحكم</h1>
              <p className="text-xs text-gray-500">مرحباً، {user?.name || "المدير"}</p>
            </div>
          </div>
          <div className="text-sm text-gray-500">{new Date().toLocaleDateString("ar-SA", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</div>
        </header>

        <div className="p-6">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {statCards.map(({ icon: Icon, label, value, color }) => (
              <div key={label} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
                <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center mb-3`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="text-2xl font-bold text-gray-800 mb-1">{value}</div>
                <div className="text-xs text-gray-500">{label}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3 mb-3">
                <Bell className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">حجوزات تنتظر المراجعة</h2>
              </div>
              <div className="text-3xl font-bold text-[#780000]">{alerts?.pendingBookings.length ?? 0}</div>
              <p className="text-xs text-gray-500 mt-1">الحجوزات المعلقة تحتاج متابعة من الفريق</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3 mb-3">
                <CalendarCheck className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">وصول اليوم</h2>
              </div>
              <div className="text-3xl font-bold text-[#780000]">{alerts?.arrivalsToday.length ?? 0}</div>
              <p className="text-xs text-gray-500 mt-1">الضيوف المتوقع وصولهم اليوم</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className="flex items-center gap-3 mb-3">
                <MessageSquare className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">استفسارات جديدة</h2>
              </div>
              <div className="text-3xl font-bold text-[#780000]">{alerts?.unreadInquiries.length ?? 0}</div>
              <p className="text-xs text-gray-500 mt-1">رسائل تحتاج رد من موظفي الإدارة</p>
            </div>
            <div className="bg-white rounded-2xl p-5 shadow-sm border border-amber-100">
              <div className="flex items-center gap-3 mb-3">
                <Bell className="w-5 h-5 text-amber-600" />
                <h2 className="font-bold text-gray-800">تنبيه المحتوى</h2>
              </div>
              <div className="text-sm font-semibold text-amber-700">أقسام الصفحة الرئيسية</div>
              <p className="text-xs text-gray-500 mt-2">المرافق والمعرض وتقييمات العملاء تُدار الآن من صفحة المحتوى في الداشبورد.</p>
              <Link href="/admin/content">
                <Button size="sm" variant="outline" className="mt-4 rounded-full border-amber-300 text-amber-700 hover:bg-amber-50">
                  افتح إدارة المحتوى
                </Button>
              </Link>
            </div>
          </div>

          {/* جدول آخر الحجوزات */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-5 border-b border-gray-100 flex items-center justify-between">
              <h2 className="font-bold text-gray-800">آخر الحجوزات</h2>
              <Link href="/admin/bookings">
                <Button size="sm" variant="outline" className="border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white rounded-full text-xs">
                  عرض الكل
                </Button>
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">رقم الحجز</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الضيف</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الجوال</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الوصول</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">المبلغ</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {recentBookings?.slice(0, 8).map((b) => (
                    <tr key={b.id} className="border-t border-gray-50 hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-3 font-mono text-[#780000] font-medium" dir="ltr">{b.bookingRef}</td>
                      <td className="px-5 py-3 font-medium">{b.guestName}</td>
                      <td className="px-5 py-3">
                        {b.guestPhone ? (
                          <a 
                            href={`https://wa.me/${b.guestPhone.replace(/\D/g, '')}`} 
                            target="_blank" 
                            className="flex items-center gap-1 text-green-600 hover:text-green-700 transition-colors"
                          >
                            <Phone className="w-3 h-3" />
                            <span dir="ltr">{b.guestPhone}</span>
                          </a>
                        ) : (
                          <span className="text-gray-400">---</span>
                        )}
                      </td>
                      <td className="px-5 py-3 text-gray-500" dir="ltr">{new Date(b.checkIn).toLocaleDateString("ar-SA")}</td>
                      <td className="px-5 py-3 font-medium">{parseFloat(String(b.totalPrice)).toLocaleString()} ريال</td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[b.status]}`}>
                          {statusLabels[b.status]}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
