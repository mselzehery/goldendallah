import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  BedDouble,
  CalendarCheck,
  Check,
  Clock,
  Eye,
  ImageIcon,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquare,
  Phone,
  Search,
  Settings,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

type BookingStatus = "pending" | "confirmed" | "cancelled" | "completed";

function AdminNav({ active }: { active: string }) {
  const [open, setOpen] = useState(false);
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/content", icon: ImageIcon, label: "المحتوى" },
    { href: "/admin/settings", icon: Settings, label: "الإعدادات" },
  ];

  return (
    <>
      {open ? <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setOpen(false)} /> : null}
      <aside className={`fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}`}>
        <div className="p-6 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center">
              <span className="text-amber-400 font-bold text-lg">G</span>
            </div>
            <div>
              <div className="font-bold text-white text-sm">جولدن دلة</div>
              <div className="text-amber-400 text-xs">لوحة الإدارة</div>
            </div>
          </div>
        </div>
        <nav className="p-4">
          {navItems.map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}>
              <div
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"}`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{label}</span>
              </div>
            </Link>
          ))}
        </nav>
        <div className="p-4 border-t border-white/10 absolute bottom-0 w-full">
          <Link href="/">
            <div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1">
              <LayoutDashboard className="w-5 h-5" />
              <span className="text-sm">عرض الموقع</span>
            </div>
          </Link>
          <button
            onClick={() => logout()}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="text-sm">تسجيل الخروج</span>
          </button>
        </div>
      </aside>
      <button onClick={() => setOpen(true)} className="fixed top-4 start-4 z-30 lg:hidden p-2 bg-[#780000] text-white rounded-lg shadow-lg">
        <Menu className="w-5 h-5" />
      </button>
    </>
  );
}

export default function BookingsOperations() {
  const { user, isAuthenticated, loading } = useAuth();
  const [statusFilter, setStatusFilter] = useState<BookingStatus | "all">("all");
  const [selectedBookingId, setSelectedBookingId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [arrivalDateFilter, setArrivalDateFilter] = useState("");
  const [departureDateFilter, setDepartureDateFilter] = useState("");
  const [internalNotesDraft, setInternalNotesDraft] = useState("");
  const utils = trpc.useUtils();

  const { data: bookings, isLoading } = trpc.bookings.listAdmin.useQuery(undefined, {
    enabled: !!isAuthenticated,
  });
  const { data: rooms } = trpc.rooms.listAdmin.useQuery(undefined, {
    enabled: !!isAuthenticated,
  });
  const { data: activityLogs } = trpc.admin.activity.useQuery(undefined, {
    enabled: !!isAuthenticated,
  });

  const updateStatus = trpc.bookings.updateStatus.useMutation({
    onSuccess: async () => {
      await utils.bookings.listAdmin.invalidate();
      await utils.admin.activity.invalidate();
      await utils.bookings.notifications.invalidate();
      toast.success("تم تحديث حالة الحجز");
    },
    onError: (error) => toast.error(error.message || "حدث خطأ في تحديث الحجز"),
  });

  const updateNotes = trpc.bookings.updateNotes.useMutation({
    onSuccess: async () => {
      await utils.bookings.listAdmin.invalidate();
      await utils.admin.activity.invalidate();
      toast.success("تم حفظ الملاحظات الداخلية");
    },
    onError: (error) => toast.error(error.message || "حدث خطأ في حفظ الملاحظات"),
  });

  const roomMap = useMemo(() => {
    const map = new Map<number, string>();
    (rooms ?? []).forEach((room) => {
      map.set(room.id, room.nameAr || room.nameEn || `Room #${room.id}`);
    });
    return map;
  }, [rooms]);

  const filteredBookings = useMemo(() => {
    return (bookings ?? []).filter((booking) => {
      if (statusFilter !== "all" && booking.status !== statusFilter) return false;

      const query = searchTerm.trim().toLowerCase();
      if (query) {
        const haystack = [
          booking.bookingRef,
          booking.guestName,
          booking.guestEmail,
          booking.guestPhone ?? "",
          roomMap.get(booking.roomId) ?? "",
        ]
          .join(" ")
          .toLowerCase();

        if (!haystack.includes(query)) return false;
      }

      const arrivalDate = new Date(booking.checkIn).toISOString().slice(0, 10);
      const departureDate = new Date(booking.checkOut).toISOString().slice(0, 10);

      if (arrivalDateFilter && arrivalDate !== arrivalDateFilter) return false;
      if (departureDateFilter && departureDate !== departureDateFilter) return false;

      return true;
    });
  }, [arrivalDateFilter, bookings, departureDateFilter, roomMap, searchTerm, statusFilter]);

  const selectedBooking = (bookings ?? []).find((booking) => booking.id === selectedBookingId) ?? null;
  const bookingTimeline = (activityLogs ?? []).filter(
    (log) => log.entityType === "booking" && log.entityId === String(selectedBookingId)
  );

  useEffect(() => {
    if (selectedBooking) {
      setInternalNotesDraft(selectedBooking.internalNotes || "");
    }
  }, [selectedBooking]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>غير مصرح</p>
      </div>
    );
  }

  const statusColors: Record<BookingStatus, string> = {
    pending: "bg-amber-100 text-amber-700",
    confirmed: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    completed: "bg-blue-100 text-blue-700",
  };

  const statusLabels: Record<BookingStatus, string> = {
    pending: "قيد المراجعة",
    confirmed: "مؤكد",
    cancelled: "ملغي",
    completed: "مكتمل",
  };

  async function handleStatusUpdate(id: number, status: BookingStatus) {
    await updateStatus.mutateAsync({ id, status });
  }

  async function handleSaveNotes() {
    if (!selectedBooking) return;
    await updateNotes.mutateAsync({
      id: selectedBooking.id,
      internalNotes: internalNotesDraft,
    });
  }

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/bookings" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 flex items-center gap-4 sticky top-0 z-30">
          <div className="w-8 lg:hidden" />
          <div>
            <h1 className="text-xl font-bold text-[#780000]">إدارة الحجوزات</h1>
            <p className="text-xs text-gray-500 mt-1">ابحث حسب الاسم أو الرقم، وفلتر الوصول والمغادرة، واحفظ ملاحظات الموظفين داخل كل حجز.</p>
          </div>
        </header>

        <div className="p-6 space-y-6">
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <div className="grid grid-cols-1 lg:grid-cols-[1.5fr,1fr,1fr] gap-4">
              <div>
                <Label className="mb-1.5 block">بحث</Label>
                <div className="relative">
                  <Search className="w-4 h-4 absolute end-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <Input
                    className="pe-9"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="رقم الحجز / اسم العميل / الجوال / البريد"
                  />
                </div>
              </div>
              <div>
                <Label className="mb-1.5 block">تاريخ الوصول</Label>
                <Input type="date" value={arrivalDateFilter} onChange={(e) => setArrivalDateFilter(e.target.value)} />
              </div>
              <div>
                <Label className="mb-1.5 block">تاريخ المغادرة</Label>
                <Input type="date" value={departureDateFilter} onChange={(e) => setDepartureDateFilter(e.target.value)} />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 mt-4">
              <Button
                variant="outline"
                className="rounded-full"
                onClick={() => {
                  setSearchTerm("");
                  setArrivalDateFilter("");
                  setDepartureDateFilter("");
                  setStatusFilter("all");
                }}
              >
                إعادة ضبط الفلاتر
              </Button>
              <span className="text-sm text-gray-500">النتائج: {filteredBookings.length}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {(["all", "pending", "confirmed", "cancelled", "completed"] as const).map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${statusFilter === status ? "bg-[#780000] text-white" : "bg-white text-gray-600 border border-gray-200 hover:border-[#780000]"}`}
              >
                {status === "all" ? "الكل" : statusLabels[status]}
                {status !== "all" ? (
                  <span className="ms-1 text-xs">
                    ({(bookings ?? []).filter((booking) => booking.status === status).length})
                  </span>
                ) : null}
              </button>
            ))}
          </div>

          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">رقم الحجز</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الضيف</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الغرفة</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الوصول</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">المغادرة</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">المبلغ</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الحالة</th>
                    <th className="text-start px-5 py-3 text-gray-500 font-medium">الإجراءات</th>
                  </tr>
                </thead>
                <tbody>
                  {isLoading ? (
                    <tr>
                      <td colSpan={8} className="px-5 py-10 text-center">
                        <div className="w-8 h-8 border-2 border-[#780000] border-t-transparent rounded-full animate-spin mx-auto" />
                      </td>
                    </tr>
                  ) : filteredBookings.length > 0 ? (
                    filteredBookings.map((booking) => (
                      <tr key={booking.id} className="border-t border-gray-50 hover:bg-gray-50 transition-colors">
                        <td className="px-5 py-3 font-mono text-[#780000] font-medium text-xs" dir="ltr">{booking.bookingRef}</td>
                        <td className="px-5 py-3 font-medium">{booking.guestName}</td>
                        <td className="px-5 py-3 text-gray-600">{roomMap.get(booking.roomId) ?? `غرفة #${booking.roomId}`}</td>
                        <td className="px-5 py-3 text-gray-500" dir="ltr">{new Date(booking.checkIn).toLocaleDateString("ar-SA")}</td>
                        <td className="px-5 py-3 text-gray-500" dir="ltr">{new Date(booking.checkOut).toLocaleDateString("ar-SA")}</td>
                        <td className="px-5 py-3 font-medium">{parseFloat(String(booking.totalPrice)).toLocaleString()} ريال</td>
                        <td className="px-5 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${statusColors[booking.status]}`}>{statusLabels[booking.status]}</span>
                        </td>
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              className="rounded-full"
                              onClick={() => setSelectedBookingId(booking.id)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            {booking.status === "pending" ? (
                              <>
                                <Button
                                  className="rounded-full bg-green-600 hover:bg-green-700 text-white"
                                  onClick={() => void handleStatusUpdate(booking.id, "confirmed")}
                                >
                                  <Check className="w-4 h-4" />
                                </Button>
                                <Button
                                  className="rounded-full bg-red-600 hover:bg-red-700 text-white"
                                  onClick={() => void handleStatusUpdate(booking.id, "cancelled")}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </>
                            ) : null}
                            {booking.status === "confirmed" ? (
                              <Button
                                className="rounded-full bg-blue-600 hover:bg-blue-700 text-white"
                                onClick={() => void handleStatusUpdate(booking.id, "completed")}
                              >
                                <Clock className="w-4 h-4" />
                              </Button>
                            ) : null}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={8} className="px-5 py-10 text-center text-gray-400">لا توجد حجوزات مطابقة</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={!!selectedBooking} onOpenChange={(open) => setSelectedBookingId(open ? selectedBookingId : null)}>
        <DialogContent dir="rtl" className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>تفاصيل الحجز</DialogTitle>
          </DialogHeader>

          {selectedBooking ? (
            <div className="space-y-6">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <p className="text-xs text-gray-500 mb-1">رقم الحجز</p>
                  <p className="font-mono text-[#780000]" dir="ltr">{selectedBooking.bookingRef}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[selectedBooking.status]}`}>
                  {statusLabels[selectedBooking.status]}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">اسم الضيف</p>
                  <p className="font-semibold">{selectedBooking.guestName}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">الغرفة</p>
                  <p className="font-semibold">{roomMap.get(selectedBooking.roomId) ?? `غرفة #${selectedBooking.roomId}`}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">البريد الإلكتروني</p>
                  <p dir="ltr">{selectedBooking.guestEmail}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">رقم الجوال</p>
                  {selectedBooking.guestPhone ? (
                    <a
                      href={`https://wa.me/${selectedBooking.guestPhone.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 text-green-700"
                    >
                      <Phone className="w-4 h-4" />
                      <span dir="ltr">{selectedBooking.guestPhone}</span>
                    </a>
                  ) : (
                    <p className="text-gray-400">غير متوفر</p>
                  )}
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">الوصول</p>
                  <p dir="ltr">{new Date(selectedBooking.checkIn).toLocaleString("ar-SA")}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">المغادرة</p>
                  <p dir="ltr">{new Date(selectedBooking.checkOut).toLocaleString("ar-SA")}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">الضيوف</p>
                  <p>{selectedBooking.adults} بالغ / {selectedBooking.children} طفل</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">عدد الليالي</p>
                  <p>{selectedBooking.totalNights} ليلة</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">الجنسية</p>
                  <p>{selectedBooking.guestNationality || "غير محددة"}</p>
                </div>
                <div className="rounded-2xl border border-gray-100 p-4">
                  <p className="text-xs text-gray-500 mb-1">إجمالي السعر</p>
                  <p>{parseFloat(String(selectedBooking.totalPrice)).toLocaleString()} ريال</p>
                </div>
              </div>

              <div className="rounded-2xl border border-gray-100 p-4">
                <p className="text-xs text-gray-500 mb-2">طلبات خاصة</p>
                <p className="text-sm leading-7 text-gray-700">{selectedBooking.specialRequests || "لا توجد طلبات خاصة"}</p>
              </div>

              <div className="rounded-2xl border border-gray-100 p-4">
                <div className="flex items-center justify-between gap-4 mb-3">
                  <h3 className="font-bold text-gray-800">ملاحظات داخلية</h3>
                  <Button
                    onClick={() => void handleSaveNotes()}
                    className="bg-[#780000] hover:bg-[#600000] text-white rounded-full"
                    disabled={updateNotes.isPending}
                  >
                    حفظ الملاحظات
                  </Button>
                </div>
                <Textarea
                  rows={4}
                  value={internalNotesDraft}
                  onChange={(e) => setInternalNotesDraft(e.target.value)}
                  placeholder="مثلاً: العميل طلب سرير إضافي / تم التواصل معه / وصول متأخر..."
                />
              </div>

              <div className="rounded-2xl border border-gray-100 p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-gray-800">إجراءات سريعة</h3>
                </div>
                <div className="flex flex-wrap gap-3">
                  {selectedBooking.status === "pending" ? (
                    <>
                      <Button className="bg-green-600 hover:bg-green-700 text-white rounded-full" onClick={() => void handleStatusUpdate(selectedBooking.id, "confirmed")}>
                        تأكيد الحجز
                      </Button>
                      <Button className="bg-red-600 hover:bg-red-700 text-white rounded-full" onClick={() => void handleStatusUpdate(selectedBooking.id, "cancelled")}>
                        إلغاء الحجز
                      </Button>
                    </>
                  ) : null}
                  {selectedBooking.status === "confirmed" ? (
                    <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full" onClick={() => void handleStatusUpdate(selectedBooking.id, "completed")}>
                      إنهاء الإقامة
                    </Button>
                  ) : null}
                </div>
              </div>

              <div className="rounded-2xl border border-gray-100 p-4">
                <h3 className="font-bold text-gray-800 mb-3">من تعامل مع الحجز</h3>
                <div className="space-y-3">
                  {bookingTimeline.length > 0 ? (
                    bookingTimeline.map((log) => (
                      <div key={log.id} className="flex items-start justify-between gap-3 border-b border-gray-50 pb-3 last:border-0 last:pb-0">
                        <div>
                          <p className="font-medium text-gray-800">{log.actorName || "موظف غير معروف"}</p>
                          <p className="text-sm text-gray-500">{log.details || log.action}</p>
                        </div>
                        <p className="text-xs text-gray-400 whitespace-nowrap">{new Date(log.createdAt).toLocaleString("ar-SA")}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-400">لا توجد إجراءات مسجلة على هذا الحجز بعد.</p>
                  )}
                </div>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
