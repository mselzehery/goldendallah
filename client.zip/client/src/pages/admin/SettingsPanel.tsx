import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  BedDouble,
  Bell,
  CheckCircle2,
  CalendarCheck,
  CreditCard,
  Eye,
  FileText,
  Hotel,
  ImageIcon,
  ImagePlus,
  Info,
  KeyRound,
  LayoutDashboard,
  LogOut,
  MessageSquare,
  PencilLine,
  Settings as SettingsIcon,
  Shield,
  ShieldAlert,
  Trash2,
  UserCog,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";

const OWNER_OPEN_ID = "Sc7yEPXmrhBAQxyLG5ck6Z";

type AdminUser = {
  id: number;
  openId: string;
  name: string | null;
  email: string | null;
  username: string | null;
  role: "user" | "admin";
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
  lastSignedIn: Date;
};

function AdminNav({ active }: { active: string }) {
  const { logout } = useAuth();
  const navItems = [
    { href: "/admin", icon: LayoutDashboard, label: "لوحة التحكم" },
    { href: "/admin/bookings", icon: CalendarCheck, label: "الحجوزات" },
    { href: "/admin/rooms", icon: BedDouble, label: "الغرف" },
    { href: "/admin/inquiries", icon: MessageSquare, label: "الاستفسارات" },
    { href: "/admin/content", icon: ImageIcon, label: "المحتوى" },
    { href: "/admin/settings", icon: SettingsIcon, label: "الإعدادات" },
  ];

  return (
    <aside className="fixed top-0 start-0 h-full w-64 bg-[#1a0000] text-white z-50 hidden lg:flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-[#780000] flex items-center justify-center overflow-hidden">
  <img 
    src="/logo.png.png" 
    alt="Logo" 
    className="w-full h-full object-contain brightness-0 invert" 
    style={{ padding: '6px' }} 
  />
</div>
          <div>
            <div className="font-bold text-white text-sm">جولدن دلة</div>
            <div className="text-amber-400 text-xs">لوحة الإدارة</div>
          </div>
        </div>
      </div>
      <nav className="p-4 flex-1">
        {navItems.map(({ href, icon: Icon, label }) => (
          <Link key={href} href={href}>
            <div
              className={`flex items-center gap-3 px-4 py-3 rounded-xl mb-1 cursor-pointer transition-colors ${
                active === href ? "bg-[#780000] text-white" : "text-white/70 hover:bg-white/10 hover:text-white"
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-sm font-medium">{label}</span>
            </div>
          </Link>
        ))}
      </nav>
      <div className="p-4 border-t border-white/10">
        <Link href="/">
          <div className="flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-white/10 hover:text-white cursor-pointer transition-colors mb-1">
            <LayoutDashboard className="w-5 h-5" />
            <span className="text-sm">عرض الموقع</span>
          </div>
        </Link>
        <button
          onClick={() => logout()}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:bg-red-900/30 hover:text-red-300 cursor-pointer transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm">تسجيل الخروج</span>
        </button>
      </div>
    </aside>
  );
}

const emptyAdminForm = {
  name: "",
  username: "",
  email: "",
  password: "",
};

export default function SettingsPanel() {
  const { user, isAuthenticated, loading } = useAuth();
  const utils = trpc.useUtils();
  const isOwner = user?.openId === OWNER_OPEN_ID;
  const [adminDialogOpen, setAdminDialogOpen] = useState(false);
  const [activityDetailsOpen, setActivityDetailsOpen] = useState(false);
  const [editingAdminId, setEditingAdminId] = useState<number | null>(null);
  const [selectedActivityLog, setSelectedActivityLog] = useState<any | null>(null);
  const [adminForm, setAdminForm] = useState(emptyAdminForm);
  const [hotelForm, setHotelForm] = useState({
    hotelNameAr: "",
    hotelNameEn: "",
    supportEmail: "",
    supportPhone: "",
    whatsappNumber: "",
    addressAr: "",
    addressEn: "",
    checkInTime: "14:00",
    checkOutTime: "12:00",
    notificationEmail: "",
    notificationWhatsapp: "",
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [paymentForm, setPaymentForm] = useState({
    provider: "paymob" as const,
    paymobApiKey: "",
    paymobPublicKey: "",
    paymobIntegrationId: "",
    paymobIframeId: "",
    paymobHmacSecret: "",
    paymobBaseUrl: "https://accept.paymob.com/api",
    callbackUrl: "",
    returnUrl: "",
    isActive: false,
  });

  const { data: adminUsers } = trpc.admin.users.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: hotelSettings } = trpc.hotel.useQuery();
  const { data: paymentSettings } = trpc.payments.settings.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: activityLogs } = trpc.admin.activity.useQuery(undefined, { enabled: !!isAuthenticated });
  const { data: alerts } = trpc.admin.alerts.useQuery(undefined, { enabled: !!isAuthenticated });

  const createAdmin = trpc.admin.createUser.useMutation({
    onSuccess: async () => {
      await utils.admin.users.invalidate();
      await utils.auth.me.invalidate();
      toast.success("تمت إضافة الأدمن");
      setAdminDialogOpen(false);
      setAdminForm(emptyAdminForm);
    },
    onError: (error) => toast.error(error.message),
  });

  const updateAdmin = trpc.admin.updateUser.useMutation({
    onSuccess: async () => {
      await utils.admin.users.invalidate();
      await utils.auth.me.invalidate();
      toast.success("تم تحديث بيانات الأدمن");
      setAdminDialogOpen(false);
      setAdminForm(emptyAdminForm);
      setEditingAdminId(null);
    },
    onError: (error) => toast.error(error.message),
  });

  const deleteAdmin = trpc.admin.deleteUser.useMutation({
    onSuccess: async () => {
      await utils.admin.users.invalidate();
      toast.success("تم حذف الأدمن");
    },
    onError: (error) => toast.error(error.message),
  });

  const resetAdminPassword = trpc.admin.resetPassword.useMutation({
    onSuccess: async () => {
      toast.success("تم تحديث كلمة المرور");
      setAdminDialogOpen(false);
      setAdminForm(emptyAdminForm);
      setEditingAdminId(null);
      await utils.admin.users.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  const updateHotel = trpc.admin.updateHotel.useMutation({
    onSuccess: async () => {
      await utils.hotel.invalidate();
      toast.success("تم حفظ بيانات الفندق");
    },
    onError: (error) => toast.error(error.message),
  });

  const updatePaymentSettings = trpc.payments.updateSettings.useMutation({
    onSuccess: async () => {
      await utils.payments.settings.invalidate();
      toast.success("تم حفظ إعدادات Paymob");
    },
    onError: (error) => toast.error(error.message),
  });

  const changeMyPassword = trpc.auth.changePassword.useMutation({
    onSuccess: async () => {
      toast.success("تم تغيير كلمة المرور");
      setPasswordForm({ currentPassword: "", newPassword: "", confirmPassword: "" });
      await utils.auth.me.invalidate();
    },
    onError: (error) => toast.error(error.message),
  });

  useEffect(() => {
    if (!hotelSettings) return;

    setHotelForm({
      hotelNameAr: hotelSettings.hotelNameAr ?? "",
      hotelNameEn: hotelSettings.hotelNameEn ?? "",
      supportEmail: hotelSettings.supportEmail ?? "",
      supportPhone: hotelSettings.supportPhone ?? "",
      whatsappNumber: hotelSettings.whatsappNumber ?? "",
      addressAr: hotelSettings.addressAr ?? "",
      addressEn: hotelSettings.addressEn ?? "",
      checkInTime: hotelSettings.checkInTime ?? "14:00",
      checkOutTime: hotelSettings.checkOutTime ?? "12:00",
      notificationEmail: hotelSettings.notificationEmail ?? "",
      notificationWhatsapp: hotelSettings.notificationWhatsapp ?? "",
    });
  }, [hotelSettings]);

  useEffect(() => {
    if (!paymentSettings) return;

    setPaymentForm({
      provider: "paymob",
      paymobApiKey: paymentSettings.paymobApiKey ?? "",
      paymobPublicKey: paymentSettings.paymobPublicKey ?? "",
      paymobIntegrationId: paymentSettings.paymobIntegrationId ?? "",
      paymobIframeId: paymentSettings.paymobIframeId ?? "",
      paymobHmacSecret: paymentSettings.paymobHmacSecret ?? "",
      paymobBaseUrl: paymentSettings.paymobBaseUrl ?? "https://accept.paymob.com/api",
      callbackUrl: paymentSettings.callbackUrl ?? "",
      returnUrl: paymentSettings.returnUrl ?? "",
      isActive: paymentSettings.isActive ?? false,
    });
  }, [paymentSettings]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#780000] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated || user?.role !== "admin") {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>غير مصرح</p>
      </div>
    );
  }

  const openCreateAdmin = () => {
    if (!isOwner) {
      toast.error("إضافة الأدمنات متاحة للحساب الرئيسي فقط");
      return;
    }

    setEditingAdminId(null);
    setAdminForm(emptyAdminForm);
    setAdminDialogOpen(true);
  };

  const openEditAdmin = (admin: AdminUser) => {
    if (!isOwner) {
      toast.error("تعديل بيانات الأدمنات متاح للحساب الرئيسي فقط");
      return;
    }

    setEditingAdminId(admin.id);
    setAdminForm({
      name: admin.name ?? "",
      username: admin.username ?? "",
      email: admin.email ?? "",
      password: "",
    });
    setAdminDialogOpen(true);
  };

  const handleSaveAdmin = async () => {
    if (!adminForm.name || !adminForm.username) {
      toast.error("أكمل بيانات الأدمن");
      return;
    }

    if (editingAdminId) {
      await updateAdmin.mutateAsync({
        id: editingAdminId,
        name: adminForm.name,
        username: adminForm.username,
        email: adminForm.email,
        isActive: adminUsers?.find((item) => item.id === editingAdminId)?.isActive ?? true,
      });

      if (adminForm.password.trim()) {
        await resetAdminPassword.mutateAsync({
          id: editingAdminId,
          newPassword: adminForm.password,
        });
      }
      return;
    }

    if (adminForm.password.trim().length < 8) {
      toast.error("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }

    await createAdmin.mutateAsync(adminForm);
  };

  const handleDeleteAdmin = async (admin: AdminUser) => {
    if (!isOwner) {
      toast.error("حذف الأدمنات متاح للحساب الرئيسي فقط");
      return;
    }

    if (!confirm(`هل تريد حذف حساب ${admin.name || admin.username} نهائيًا؟`)) {
      return;
    }

    await deleteAdmin.mutateAsync({ id: admin.id });
  };

  const toggleAdminStatus = async (admin: AdminUser) => {
    if (!isOwner) {
      toast.error("إيقاف أو تفعيل الأدمنات متاح للحساب الرئيسي فقط");
      return;
    }

    await updateAdmin.mutateAsync({
      id: admin.id,
      name: admin.name ?? "",
      username: admin.username ?? "",
      email: admin.email ?? "",
      isActive: !admin.isActive,
    });
  };

  const handleSaveHotel = async () => {
    await updateHotel.mutateAsync(hotelForm);
  };

  const handleSavePaymentSettings = async () => {
    await updatePaymentSettings.mutateAsync(paymentForm);
  };

  const handleChangeMyPassword = async () => {
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error("تأكيد كلمة المرور غير مطابق");
      return;
    }

    await changeMyPassword.mutateAsync({
      currentPassword: passwordForm.currentPassword,
      newPassword: passwordForm.newPassword,
    });
  };

  const paymentMethodBadges = [
    { key: "mada", label: "مدى", tone: "bg-emerald-50 text-emerald-700 border-emerald-200" },
    { key: "visa", label: "Visa", tone: "bg-blue-50 text-blue-700 border-blue-200" },
    { key: "mastercard", label: "Mastercard", tone: "bg-orange-50 text-orange-700 border-orange-200" },
    { key: "stc_pay", label: "stc pay", tone: "bg-purple-50 text-purple-700 border-purple-200" },
  ];

  const activityPresentation = useMemo(() => {
    const mapAction = (action: string) => {
      if (action.includes("payment")) {
        return {
          icon: CreditCard,
          tone: "bg-emerald-50 text-emerald-700 border-emerald-200",
          label: "عملية دفع",
        };
      }
      if (action.includes("create")) {
        return {
          icon: CheckCircle2,
          tone: "bg-green-50 text-green-700 border-green-200",
          label: "إضافة جديدة",
        };
      }
      if (action.includes("update") || action.includes("reset")) {
        return {
          icon: PencilLine,
          tone: "bg-amber-50 text-amber-700 border-amber-200",
          label: "تعديل",
        };
      }
      if (action.includes("delete")) {
        return {
          icon: Trash2,
          tone: "bg-red-50 text-red-700 border-red-200",
          label: "حذف",
        };
      }
      if (action.includes("login")) {
        return {
          icon: ShieldAlert,
          tone: "bg-sky-50 text-sky-700 border-sky-200",
          label: "دخول للنظام",
        };
      }
      if (action.includes("upload")) {
        return {
          icon: ImagePlus,
          tone: "bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200",
          label: "رفع ملف",
        };
      }
      return {
        icon: FileText,
        tone: "bg-gray-50 text-gray-700 border-gray-200",
        label: "نشاط عام",
      };
    };

    const mapEntity = (entityType: string) => {
      if (entityType.includes("admin")) return "إدارة المستخدمين";
      if (entityType.includes("payment")) return "المدفوعات";
      if (entityType.includes("booking")) return "الحجوزات";
      if (entityType.includes("facility")) return "المرافق";
      if (entityType.includes("gallery")) return "المعرض";
      if (entityType.includes("review")) return "تقييمات العملاء";
      if (entityType.includes("inquiry")) return "الاستفسارات";
      if (entityType.includes("hotel")) return "بيانات الفندق";
      if (entityType.includes("media")) return "الوسائط";
      if (entityType.includes("auth")) return "الدخول والصلاحيات";
      return entityType;
    };

    return (activityLogs ?? []).map((log) => ({
      ...log,
      ...mapAction(log.action),
      entityLabel: mapEntity(log.entityType),
      actorLabel: log.actorName || "موظف النظام",
      detailsLabel: log.details || "لا توجد تفاصيل إضافية لهذا النشاط.",
    }));
  }, [activityLogs]);

  const openActivityDetails = (log: any) => {
    setSelectedActivityLog(log);
    setActivityDetailsOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#faf8f5] flex" dir="rtl">
      <AdminNav active="/admin/settings" />
      <div className="flex-1 lg:ms-64">
        <header className="bg-white border-b border-gray-100 px-6 py-4 sticky top-0 z-30">
          <h1 className="text-xl font-bold text-[#780000]">إعدادات الإدارة والفندق</h1>
        </header>

        <div className="p-6 space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Bell className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">تنبيهات الحجوزات</h2>
              </div>
              <div className="space-y-2 text-sm text-gray-600">
                <p>حجوزات قيد الانتظار: <strong>{alerts?.pendingBookings.length ?? 0}</strong></p>
                <p>وصول اليوم: <strong>{alerts?.arrivalsToday.length ?? 0}</strong></p>
                <p>وصول الغد: <strong>{alerts?.arrivalsTomorrow.length ?? 0}</strong></p>
                <p>استفسارات جديدة: <strong>{alerts?.unreadInquiries.length ?? 0}</strong></p>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">الأدمنات النشطون</h2>
              </div>
              <p className="text-3xl font-bold text-[#780000]">{adminUsers?.filter((item) => item.isActive).length ?? 0}</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-2">
                <Hotel className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">اسم الفندق</h2>
              </div>
              <p className="text-sm text-gray-600">{hotelForm.hotelNameAr || "جولدن دلة"}</p>
              <p className="text-xs text-gray-400 mt-1">{hotelForm.hotelNameEn || "Golden Dallah"}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-3">
                  <Shield className="w-5 h-5 text-[#780000]" />
                  <h2 className="font-bold text-gray-800">إدارة الأدمنات</h2>
                </div>
                <Button
                  onClick={openCreateAdmin}
                  disabled={!isOwner}
                  className="bg-[#780000] hover:bg-[#600000] text-white rounded-full disabled:opacity-50"
                >
                  إضافة أدمن
                </Button>
              </div>

              {!isOwner ? (
                <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3 mb-4">
                  الإدارة الكاملة للأدمنات متاحة للحساب الرئيسي فقط. يمكنك من هنا تغيير كلمة مرورك فقط.
                </p>
              ) : null}

              <div className="space-y-3">
                {(adminUsers ?? []).map((admin) => (
                  <div key={admin.id} className="rounded-2xl border border-gray-100 p-4 flex items-center justify-between gap-4">
                    <div>
                      <p className="font-semibold text-gray-800">{admin.name}</p>
                      <p className="text-sm text-gray-500">@{admin.username}</p>
                      <p className="text-xs text-gray-400">{admin.email || "بدون بريد"}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className={`px-3 py-1 rounded-full text-xs font-medium ${admin.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}`}>
                        {admin.isActive ? "نشط" : "موقوف"}
                      </div>
                      <Button variant="outline" className="rounded-full" onClick={() => openEditAdmin(admin)} disabled={!isOwner}>
                        تعديل
                      </Button>
                      <Button
                        variant="outline"
                        className="rounded-full text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => void handleDeleteAdmin(admin)}
                        disabled={!isOwner || user?.id === admin.id || deleteAdmin.isPending}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={admin.isActive}
                          disabled={!isOwner || user?.id === admin.id}
                          onCheckedChange={() => void toggleAdminStatus(admin)}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
              <div className="flex items-center gap-3 mb-5">
                <KeyRound className="w-5 h-5 text-[#780000]" />
                <h2 className="font-bold text-gray-800">تغيير كلمة مروري</h2>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="mb-1.5 block">كلمة المرور الحالية</Label>
                  <Input type="password" value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })} />
                </div>
                <div>
                  <Label className="mb-1.5 block">كلمة المرور الجديدة</Label>
                  <Input type="password" value={passwordForm.newPassword} onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })} />
                </div>
                <div>
                  <Label className="mb-1.5 block">تأكيد كلمة المرور</Label>
                  <Input type="password" value={passwordForm.confirmPassword} onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })} />
                </div>
                <Button onClick={() => void handleChangeMyPassword()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">
                  حفظ كلمة المرور
                </Button>
              </div>
            </section>
          </div>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-5">
              <Hotel className="w-5 h-5 text-[#780000]" />
              <h2 className="font-bold text-gray-800">تفاصيل الفندق</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label className="mb-1.5 block">اسم الفندق بالعربية</Label><Input value={hotelForm.hotelNameAr} onChange={(e) => setHotelForm({ ...hotelForm, hotelNameAr: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">اسم الفندق بالإنجليزية</Label><Input value={hotelForm.hotelNameEn} onChange={(e) => setHotelForm({ ...hotelForm, hotelNameEn: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">إيميل الدعم</Label><Input value={hotelForm.supportEmail} onChange={(e) => setHotelForm({ ...hotelForm, supportEmail: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">رقم الدعم</Label><Input value={hotelForm.supportPhone} onChange={(e) => setHotelForm({ ...hotelForm, supportPhone: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">واتساب الفندق</Label><Input value={hotelForm.whatsappNumber} onChange={(e) => setHotelForm({ ...hotelForm, whatsappNumber: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">إيميل تنبيهات الحجوزات</Label><Input value={hotelForm.notificationEmail} onChange={(e) => setHotelForm({ ...hotelForm, notificationEmail: e.target.value })} /></div>
              <div><Label className="mb-1.5 block">واتساب تنبيهات الحجوزات</Label><Input value={hotelForm.notificationWhatsapp} onChange={(e) => setHotelForm({ ...hotelForm, notificationWhatsapp: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label className="mb-1.5 block">وقت الدخول</Label><Input value={hotelForm.checkInTime} onChange={(e) => setHotelForm({ ...hotelForm, checkInTime: e.target.value })} /></div>
                <div><Label className="mb-1.5 block">وقت الخروج</Label><Input value={hotelForm.checkOutTime} onChange={(e) => setHotelForm({ ...hotelForm, checkOutTime: e.target.value })} /></div>
              </div>
              <div className="md:col-span-2"><Label className="mb-1.5 block">العنوان بالعربية</Label><Textarea rows={3} value={hotelForm.addressAr} onChange={(e) => setHotelForm({ ...hotelForm, addressAr: e.target.value })} /></div>
              <div className="md:col-span-2"><Label className="mb-1.5 block">العنوان بالإنجليزية</Label><Textarea rows={3} value={hotelForm.addressEn} onChange={(e) => setHotelForm({ ...hotelForm, addressEn: e.target.value })} /></div>
            </div>

            <div className="pt-5">
              <Button onClick={() => void handleSaveHotel()} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">
                حفظ بيانات الفندق
              </Button>
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center justify-between gap-4 mb-5">
              <div className="flex items-center gap-3">
                <CreditCard className="w-5 h-5 text-[#780000]" />
                <div>
                  <h2 className="font-bold text-gray-800">إعدادات Paymob</h2>
                  <p className="text-sm text-gray-500 mt-1">ربط بوابة الدفع وحفظ بيانات التكامل من لوحة الإدارة.</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-full bg-gray-50 px-4 py-2 border border-gray-200">
                <span className="text-sm text-gray-600">تفعيل الدفع</span>
                <Switch checked={paymentForm.isActive} onCheckedChange={(checked) => setPaymentForm({ ...paymentForm, isActive: checked })} />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="mb-1.5 block">مزود الدفع</Label>
                <Input value="Paymob" readOnly className="bg-gray-50" />
              </div>
              <div>
                <Label className="mb-1.5 block">Base URL</Label>
                <Input value={paymentForm.paymobBaseUrl} onChange={(e) => setPaymentForm({ ...paymentForm, paymobBaseUrl: e.target.value })} dir="ltr" />
              </div>
              <div>
                <Label className="mb-1.5 block">API Key</Label>
                <Input value={paymentForm.paymobApiKey} onChange={(e) => setPaymentForm({ ...paymentForm, paymobApiKey: e.target.value })} dir="ltr" />
              </div>
              <div>
                <Label className="mb-1.5 block">Public Key</Label>
                <Input value={paymentForm.paymobPublicKey} onChange={(e) => setPaymentForm({ ...paymentForm, paymobPublicKey: e.target.value })} dir="ltr" />
              </div>
              <div>
                <Label className="mb-1.5 block">Integration ID</Label>
                <Input value={paymentForm.paymobIntegrationId} onChange={(e) => setPaymentForm({ ...paymentForm, paymobIntegrationId: e.target.value })} dir="ltr" />
              </div>
              <div>
                <Label className="mb-1.5 block">Iframe ID</Label>
                <Input value={paymentForm.paymobIframeId} onChange={(e) => setPaymentForm({ ...paymentForm, paymobIframeId: e.target.value })} dir="ltr" />
              </div>
              <div className="md:col-span-2">
                <Label className="mb-1.5 block">HMAC Secret</Label>
                <Input value={paymentForm.paymobHmacSecret} onChange={(e) => setPaymentForm({ ...paymentForm, paymobHmacSecret: e.target.value })} dir="ltr" />
              </div>
              <div>
                <Label className="mb-1.5 block">Callback URL</Label>
                <Input value={paymentForm.callbackUrl} onChange={(e) => setPaymentForm({ ...paymentForm, callbackUrl: e.target.value })} dir="ltr" />
              </div>
              <div>
                <Label className="mb-1.5 block">Return URL</Label>
                <Input value={paymentForm.returnUrl} onChange={(e) => setPaymentForm({ ...paymentForm, returnUrl: e.target.value })} dir="ltr" />
              </div>
            </div>

            <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
              الحجز يتأكد فورًا عند إنشاء الطلب، لكن الإيراد لا يدخل الإحصائيات إلا بعد انتهاء الإقامة وتحويل حالة الحجز إلى <span className="font-semibold">completed</span>.
            </div>

            <div className="mt-4">
              <p className="text-sm font-medium text-gray-700 mb-3">طرق الدفع الشائعة في السعودية داخل النظام</p>
              <div className="flex flex-wrap gap-2">
                {paymentMethodBadges.map((method) => (
                  <span key={method.key} className={`inline-flex items-center rounded-full border px-3 py-1 text-xs font-medium ${method.tone}`}>
                    {method.label}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-5">
              <Button onClick={() => void handleSavePaymentSettings()} disabled={updatePaymentSettings.isPending} className="bg-[#780000] hover:bg-[#600000] text-white rounded-full">
                {updatePaymentSettings.isPending ? "جارٍ حفظ إعدادات Paymob..." : "حفظ إعدادات Paymob"}
              </Button>
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-5">
              <Bell className="w-5 h-5 text-[#780000]" />
              <h2 className="font-bold text-gray-800">سجل النشاط</h2>
            </div>

            <div className="space-y-3">
              {activityPresentation.map((log) => {
                const Icon = log.icon;
                return (
                  <div key={log.id} className="rounded-2xl border border-gray-100 p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 min-w-0">
                        <div className={`w-11 h-11 rounded-2xl border flex items-center justify-center ${log.tone}`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2 mb-2">
                            <p className="font-semibold text-gray-800">{log.label}</p>
                            <span className={`rounded-full border px-2.5 py-1 text-[11px] font-medium ${log.tone}`}>{log.entityLabel}</span>
                          </div>
                          <p className="text-sm text-gray-600">{log.actorLabel}</p>
                          <p className="text-xs text-gray-400 mt-1 line-clamp-2">{log.detailsLabel}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2 shrink-0">
                        <span className="text-xs text-gray-400">{new Date(log.createdAt).toLocaleString("ar-SA")}</span>
                        <Button variant="outline" size="sm" className="rounded-full" onClick={() => openActivityDetails(log)}>
                          <Eye className="w-4 h-4 ms-1" />
                          عرض التفاصيل
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
              {!activityPresentation.length ? (
                <div className="rounded-2xl border border-dashed border-gray-200 bg-gray-50 p-6 text-center text-sm text-gray-500">
                  لا يوجد نشاط مسجل حاليًا.
                </div>
              ) : null}
            </div>
          </section>

          <section className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <Info className="w-5 h-5 text-[#780000]" />
              <h2 className="font-bold text-gray-800">تنبيه محتوى الصفحة الرئيسية</h2>
            </div>
            <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4 text-sm text-amber-900">
              قسم المرافق الرئيسي في الصفحة الرئيسية مرتبط الآن بإدارة المحتوى. أي إضافة أو تعديل للعناصر التي تظهر في الصفحة الرئيسية تتم من صفحة
              {" "}
              <Link href="/admin/content"><span className="font-semibold underline cursor-pointer">المحتوى</span></Link>
              {" "}
              وليس من لوحة الإعدادات.
            </div>
          </section>
        </div>
      </div>

      <Dialog open={adminDialogOpen} onOpenChange={setAdminDialogOpen}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingAdminId ? "تعديل الأدمن" : "إضافة أدمن"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div><Label className="mb-1.5 block">الاسم</Label><Input value={adminForm.name} onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">اسم المستخدم</Label><Input value={adminForm.username} onChange={(e) => setAdminForm({ ...adminForm, username: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">الإيميل</Label><Input value={adminForm.email} onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })} /></div>
            <div><Label className="mb-1.5 block">{editingAdminId ? "كلمة مرور جديدة اختياريًا" : "كلمة المرور"}</Label><Input type="password" value={adminForm.password} onChange={(e) => setAdminForm({ ...adminForm, password: e.target.value })} /></div>
            <div className="flex justify-end gap-3">
              <Button variant="outline" className="rounded-full" onClick={() => setAdminDialogOpen(false)}>إلغاء</Button>
              <Button className="bg-[#780000] hover:bg-[#600000] text-white rounded-full" onClick={() => void handleSaveAdmin()}>حفظ</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={activityDetailsOpen} onOpenChange={setActivityDetailsOpen}>
        <DialogContent dir="rtl" className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>تفاصيل النشاط</DialogTitle>
          </DialogHeader>
          {selectedActivityLog ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><Label className="mb-1.5 block">نوع النشاط</Label><Input value={selectedActivityLog.label} readOnly /></div>
                <div><Label className="mb-1.5 block">القسم</Label><Input value={selectedActivityLog.entityLabel} readOnly /></div>
                <div><Label className="mb-1.5 block">نفّذه</Label><Input value={selectedActivityLog.actorLabel} readOnly /></div>
                <div><Label className="mb-1.5 block">وقت التنفيذ</Label><Input value={new Date(selectedActivityLog.createdAt).toLocaleString("ar-SA")} readOnly /></div>
                <div className="md:col-span-2"><Label className="mb-1.5 block">المعرف</Label><Input value={selectedActivityLog.entityId || "-"} readOnly /></div>
              </div>
              <div>
                <Label className="mb-1.5 block">الوصف الكامل</Label>
                <Textarea rows={5} value={selectedActivityLog.detailsLabel} readOnly />
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}
