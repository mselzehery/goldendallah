﻿import { useState } from "react";
import { Link } from "wouter";
import { Users, ArrowRight, ArrowLeft, BedDouble, Maximize2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLang } from "@/contexts/LanguageContext";

const DEFAULT_ROOM_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/default-room.jpg";
const PAGE_HEADER_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663428239284/a5cuxkvbTPsGzHmCpvgaCx/lobby_fb00104c.jpg";

export default function Rooms() {
  const { t, lang, isRTL } = useLang();
  const { data: rooms, isLoading } = trpc.rooms.list.useQuery();
  const [filter, setFilter] = useState("all");

  const typeLabels: Record<string, { ar: string; en: string }> = {
    all: { ar: "الكل", en: "All" },
    "junior-suite": { ar: "جناح جونيور", en: "Junior Suite" },
    studio: { ar: "إستديو", en: "Studio" },
    "family-suite": { ar: "جناح عائلي", en: "Family Suite" },
    accessible: { ar: "غرفة لذوي الاحتياجات", en: "Accessible Room" },
  };

  const filtered = filter === "all" ? rooms : rooms?.filter((room) => room.type === filter);

  return (
    <div className="min-h-screen">
      <div className="relative h-64 md:h-80 overflow-hidden">
        <img src={PAGE_HEADER_IMG} alt="" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 to-black/50" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center pt-16">
          <p className="text-amber-300 text-sm tracking-widest uppercase mb-2">{t("اكتشف", "Discover")}</p>
          <h1 className="text-3xl md:text-5xl font-bold" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
            {t("الغرف والأجنحة", "Rooms & Suites")}
          </h1>
          <div className="flex items-center gap-3 mt-3">
            <div className="h-px w-12 bg-amber-400" />
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            <div className="h-px w-12 bg-amber-400" />
          </div>
        </div>
      </div>

      <div className="bg-white border-b border-gray-100 sticky top-[88px] z-30 shadow-sm">
        <div className="container">
          <div className="flex gap-1 py-3 overflow-x-auto">
            {Object.entries(typeLabels).map(([key, labels]) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                  filter === key ? "bg-[#780000] text-white shadow-md" : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                {lang === "ar" ? labels.ar : labels.en}
              </button>
            ))}
          </div>
        </div>
      </div>

      <section className="py-16 bg-[#faf8f5]">
        <div className="container">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="rounded-2xl overflow-hidden bg-gray-200 animate-pulse h-80" />
              ))}
            </div>
          ) : filtered && filtered.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filtered.map((room) => {
                const remainingUnits = room.remainingToday ?? room.inventoryCount ?? 0;
                const isSoldOut = remainingUnits <= 0;

                return (
                  <div key={room.id} className="luxury-card bg-white rounded-2xl overflow-hidden shadow-md border border-gray-100 group">
                    <div className="relative h-56 overflow-hidden">
                      <img
                        src={room.imageUrl || DEFAULT_ROOM_IMG}
                        alt={lang === "ar" ? room.nameAr : room.nameEn}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                      <div className="absolute top-4 start-4 flex gap-2">
                        <span className="bg-[#780000] text-white text-xs px-3 py-1 rounded-full font-medium capitalize">
                          {lang === "ar" ? typeLabels[room.type]?.ar : typeLabels[room.type]?.en}
                        </span>
                        {isSoldOut ? (
                          <span className="bg-red-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                            {t("نفدت بالكامل", "Sold out")}
                          </span>
                        ) : null}
                      </div>
                      {room.isFeatured ? (
                        <div className="absolute top-4 end-4">
                          <span className="bg-amber-500 text-white text-xs px-3 py-1 rounded-full font-medium">
                            {t("مميز", "Featured")}
                          </span>
                        </div>
                      ) : null}
                    </div>

                    <div className="p-6">
                      <h3 className="text-xl font-bold text-[#780000] mb-2" style={{ fontFamily: "Playfair Display, 'Noto Kufi Arabic', serif" }}>
                        {lang === "ar" ? room.nameAr : room.nameEn}
                      </h3>
                      <p className="text-gray-500 text-sm mb-4 line-clamp-2">
                        {lang === "ar" ? room.descriptionAr : room.descriptionEn}
                      </p>

                      <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                        {/* <span className="flex items-center gap-1.5">
                          <BedDouble className="w-3.5 h-3.5 text-[#780000]" />
                          {remainingUnits} {t("متبقي", "remaining")}
                        </span> */}
                        <span className="flex items-center gap-1.5">
                          <Users className="w-3.5 h-3.5 text-[#780000]" />
                          {room.capacity} {t("أشخاص", "guests")}
                        </span>
                        {room.size ? (
                          <span className="flex items-center gap-1.5">
                            <Maximize2 className="w-3.5 h-3.5 text-[#780000]" />
                            {room.size} {t("م²", "sqm")}
                          </span>
                        ) : null}
                      </div>

                      {isSoldOut ? (
                        <div className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700 flex items-center gap-2 mb-4">
                          <AlertCircle className="w-4 h-4" />
                          {t("هذا النوع محجوز بالكامل حاليًا ويمكنك متابعة توفره لاحقًا.", "This room type is fully booked right now.")}
                        </div>
                      ) : null}

                      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <div>
                          <span className="text-2xl font-bold text-[#780000]">{parseFloat(String(room.pricePerNight)).toLocaleString()}</span>
                          <span className="text-gray-500 text-xs ms-1">{t("ريال/ليلة", "SAR/night")}</span>
                        </div>
                        <div className="flex gap-2">
                          <Link href={`/rooms/${room.id}`}>
                            <Button size="sm" variant="outline" className="border-[#780000] text-[#780000] hover:bg-[#780000] hover:text-white rounded-full text-xs px-4">
                              {t("التفاصيل", "Details")}
                            </Button>
                          </Link>
                          {isSoldOut ? (
                            <Button size="sm" variant="outline" disabled className="rounded-full text-xs px-4 text-red-600 border-red-600 opacity-100">
                              {t("نفدت بالكامل", "Sold out")}
                            </Button>
                          ) : (
                            <Link href={`/booking?roomId=${room.id}`}>
                              <Button size="sm" className="bg-[#780000] hover:bg-[#600000] text-white rounded-full text-xs px-4">
                                {t("احجز", "Book")}
                                {isRTL ? <ArrowLeft className="w-3 h-3 ms-1" /> : <ArrowRight className="w-3 h-3 ms-1" />}
                              </Button>
                            </Link>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-20 text-gray-500">{t("لا توجد غرف متاحة ضمن هذا التصنيف حاليًا", "No rooms available in this category right now")}</div>
          )}
        </div>
      </section>
    </div>
  );
}
