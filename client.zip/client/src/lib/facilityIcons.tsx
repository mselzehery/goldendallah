import type { LucideIcon } from "lucide-react";

import {
  Award,
  BedDouble,
  BellRing,
  Briefcase,
  Building2,
  Car,
  Coffee,
  Dumbbell,
  Sparkles,
  Star,
  UtensilsCrossed,
  WashingMachine,
  Waves,
  Wifi,
} from "lucide-react";

/**
 * خريطة الأيقونات (كل المفاتيح lowercase لتفادي مشاكل المطابقة)
 */
export const facilityIconMap: Record<string, LucideIcon> = {
  // Dining
  dining: UtensilsCrossed,
  restaurant: UtensilsCrossed,
  utensilscrossed: UtensilsCrossed,

  // Wellness
  wellness: Sparkles,
  spa: Sparkles,
  sparkles: Sparkles,

  // Recreation
  recreation: Waves,
  pool: Waves,
  waves: Waves,

  // Business
  business: Briefcase,
  briefcase: Briefcase,

  // Services / Building
  services: Building2,
  building: Building2,
  building2: Building2,

  // Basic facilities
  wifi: Wifi,
  car: Car,
  coffee: Coffee,
  dumbbell: Dumbbell,

  // Concierge
  bellring: BellRing,
  bell: BellRing,

  // Laundry
  laundry: WashingMachine,
  washingmachine: WashingMachine,

  // General
  star: Star,
  award: Award,
  beddouble: BedDouble,
};

/**
 * خيارات الأيقونات (للاستخدام في الداشبورد / الفورم)
 */
export const facilityIconOptions = [
  { key: "dining", labelAr: "مطعم", labelEn: "Dining", icon: UtensilsCrossed },
  { key: "wellness", labelAr: "سبا", labelEn: "Wellness", icon: Sparkles },
  { key: "recreation", labelAr: "مسبح", labelEn: "Recreation", icon: Waves },
  { key: "business", labelAr: "أعمال", labelEn: "Business", icon: Briefcase },
  { key: "services", labelAr: "خدمات", labelEn: "Services", icon: Building2 },
  { key: "wifi", labelAr: "واي فاي", labelEn: "WiFi", icon: Wifi },
  { key: "car", labelAr: "مواقف", labelEn: "Parking", icon: Car },
  { key: "coffee", labelAr: "مقهى", labelEn: "Coffee", icon: Coffee },
  { key: "dumbbell", labelAr: "نادي", labelEn: "Gym", icon: Dumbbell },
  { key: "bellring", labelAr: "كونسيرج", labelEn: "Concierge", icon: BellRing },
  { key: "laundry", labelAr: "غسيل ملابس", labelEn: "Laundry", icon: WashingMachine },
  { key: "award", labelAr: "مميز", labelEn: "Premium", icon: Award },
];

/**
 * دالة اختيار الأيقونة بشكل آمن
 */
export function resolveFacilityIcon(
  iconKey?: string | null,
  category?: string | null
): LucideIcon {
  const normalizedIcon = iconKey?.trim().toLowerCase();
  const normalizedCategory = category?.trim().toLowerCase();

  return (
    (normalizedIcon && facilityIconMap[normalizedIcon]) ||
    (normalizedCategory && facilityIconMap[normalizedCategory]) ||
    Award
  );
}