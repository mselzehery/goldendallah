/**
 * تخزين مرافق الغرفة في عمود واحد كـ JSON:
 * - الشكل الجديد: [{ "ar": "...", "en": "..." }, ...]
 * - الشكل القديم: ["نص1","نص2"] أو نص مفصول بفواصل (يُعرض بنفس اللغتين)
 */

export function getAmenityLabelsForLang(data: string | null | undefined, lang: "ar" | "en"): string[] {
  if (!data?.trim()) return [];
  try {
    const parsed = JSON.parse(data) as unknown;
    if (!Array.isArray(parsed) || parsed.length === 0) return [];
    const first = parsed[0];
    if (typeof first === "string") {
      return parsed as string[];
    }
    if (first && typeof first === "object" && ("ar" in first || "en" in first)) {
      return (parsed as { ar?: string; en?: string }[])
        .map((item) => {
          if (lang === "ar") return String(item.ar ?? item.en ?? "").trim();
          return String(item.en ?? item.ar ?? "").trim();
        })
        .filter(Boolean);
    }
  } catch {
    return data
      .split(/[،,]+/)
      .map((s) => s.trim())
      .filter(Boolean);
  }
  return [];
}

export function amenitiesJsonToFormFields(data: string | null | undefined): { ar: string; en: string } {
  if (!data?.trim()) return { ar: "", en: "" };
  try {
    const parsed = JSON.parse(data) as unknown;
    if (!Array.isArray(parsed) || parsed.length === 0) return { ar: "", en: "" };
    const first = parsed[0];
    if (typeof first === "string") {
      const joined = (parsed as string[]).join("، ");
      return { ar: joined, en: joined };
    }
    if (first && typeof first === "object" && ("ar" in first || "en" in first)) {
      const rows = parsed as { ar?: string; en?: string }[];
      return {
        ar: rows
          .map((r) => String(r.ar ?? r.en ?? "").trim())
          .filter(Boolean)
          .join("، "),
        en: rows
          .map((r) => String(r.en ?? r.ar ?? "").trim())
          .filter(Boolean)
          .join(", "),
      };
    }
  } catch {
    const parts = data.split(/[،,]+/).map((s) => s.trim()).filter(Boolean);
    const joinedAr = parts.join("، ");
    return { ar: joinedAr, en: joinedAr };
  }
  return { ar: "", en: "" };
}

/** يحوّل حقلين (فواصل عربية/إنجليزية) إلى JSON للحفظ في قاعدة البيانات */
export function formFieldsToAmenitiesJson(arRaw: string, enRaw: string): string {
  const arParts = arRaw.split(/[،,]+/).map((s) => s.trim()).filter(Boolean);
  const enParts = enRaw.split(/[،,]+/).map((s) => s.trim()).filter(Boolean);
  if (arParts.length === 0 && enParts.length === 0) return "";
  const n = Math.max(arParts.length, enParts.length);
  const items: { ar: string; en: string }[] = [];
  for (let i = 0; i < n; i++) {
    const ar = arParts[i] ?? enParts[i] ?? "";
    const en = enParts[i] ?? arParts[i] ?? "";
    if (ar || en) items.push({ ar, en });
  }
  return items.length ? JSON.stringify(items) : "";
}
